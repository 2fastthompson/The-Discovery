# V1.1.7 candidate

Denial receipts: executed_amount/destination/payment_identity must be null; reconciled_final_state N/A; commit_signature and issuer_key_id bound whenever a commit is supplied.

Types: executed, simulated_acceptance, external_execution must be bool (not 0/1). Required keys must be present. Extra keys rejected.

factory.build_runtime wires one coordinator; require_coordinated rejects missing/mismatched instances.

Table-driven allow+deny mutation matrix in tests/test_receipt_matrix.py.
