# V1.1.6 candidate

1. Signed execution event carries commit_envelope_hash of the exact ValidatedCommit. Verifier rejects event A presented with commit B.
2. Complete receipt schema: every field is event-bound, spec-bound, commit-bound, fixed, or untrusted metadata. Extra keys fail closed.
3. AcceptanceCoordinator RLock is required for registry writers, resource mutations, and consume. Linearization instant: successful try_consume persist.
4. Unit workers all joined; stray thread removed. Executor.identity = sri-executor-v1.1.6.

Simulated acceptance only. Native Linux corpus run included.
