#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from clock import Clock
from executor import Executor
from gate import CommitGuard
from models import AuthoritySpec, ExecutionRequest, ValidatedCommit
from store import ResourceStore
from hashutil import sha256_hex, GATE_VERSION
from keys import load_test_issuer
from revoke import RevocationRegistry
from ledger import ExecutionLedger
from verifier import verify_receipt
from dataclasses import asdict
from cryptography.hazmat.primitives import serialization

ROOT = Path(__file__).resolve().parents[1]
ISSUER = load_test_issuer(ROOT / "fixtures" / "test_ed25519.json")
TRUSTED = {ISSUER.key_id: (ISSUER.pub, ISSUER.fingerprint)}


def spec(now, order, principal="p1"):
    return AuthoritySpec(
        authority_id="a1",
        principal_id=principal,
        authorized_actor_id="agent.1",
        revocation_version=1,
        action_type="return",
        resource_id="#W1",
        authorized_amount_ceiling=50.0,
        authorized_destinations=["pm_orig"],
        authorized_payment_identity="pm_orig",
        authorized_mutation_set=["none"],
        issued_at=now,
        expires_at=now + 100,
        nonce="n0",
        one_shot=True,
        resource_version_hash=sha256_hex(order),
        evidence_hash="e1",
    )


def req(principal="p1", **kw):
    base = dict(
        principal_id=principal, actor_id="agent.1", action_type="return",
        resource_id="#W1", amount=50.0, destination="pm_orig",
        payment_identity="pm_orig", nonce="n1", authority_id="a1",
    )
    base.update(kw)
    return ExecutionRequest(**base)


def main():
    order = {"order_id": "#W1", "user_id": "p1", "status": "delivered", "items": []}
    clock = Clock(10.0)
    fails = []
    reg = RevocationRegistry()
    reg.register("a1", 1)
    led = ExecutionLedger()
    ex = Executor(TRUSTED, reg, led, ISSUER)
    st = ResourceStore({"#W1": order})
    rec = ex.execute(run_id="u", corpus="unit", commit=None, spec=spec(10, order), req=req(), store=st, clock=clock)
    if rec.executed:
        fails.append("bypass")
    g = CommitGuard(clock, ISSUER)
    out = g.commit(spec(10, order), req(principal="other"), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("principal_allowed")
    s = spec(10, order)
    s.expires_at = 1.0
    out = CommitGuard(clock, ISSUER).commit(s, req(), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("expired_allowed")
    out = CommitGuard(clock, ISSUER).commit(spec(10, order), req(amount=float("nan")), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("nan_allowed")
    # forged
    r = req(amount=99.0, destination="pm_forged")
    body = dict(
        commit_id="x", gate_version=GATE_VERSION, decision="ALLOW", reason="IN_SPEC",
        authority_hash=spec(10, order).hash(), request_hash=r.hash(),
        pre_state_hash=st.version_hash("#W1"), principal_id=r.principal_id,
        actor_id=r.actor_id, action_type=r.action_type, resource_id=r.resource_id,
        amount=r.amount, destination=r.destination, payment_identity=r.payment_identity,
        nonce=r.nonce, committed_at=10.0, revocation_version=1, issuer_key_id=ISSUER.key_id, signature="",
        commit_hash="00",
    )
    body["commit_hash"] = sha256_hex({k: body[k] for k in body if k != "signature"})
    rec = ex.execute(run_id="u", corpus="unit", commit=ValidatedCommit(**body), spec=spec(10, order), req=r, store=st, clock=clock)
    if rec.executed:
        fails.append("forged_executed")
    # outcome-tamper: flip executed and reseal hash — verifier must reject
    s_ok = spec(10, order)
    r_ok = req(nonce="n-ok")
    c_ok = CommitGuard(clock, ISSUER).commit(s_ok, r_ok, st.version_hash("#W1"))
    if isinstance(c_ok, tuple):
        fails.append("tamper_setup")
    else:
        rec_ok = ex.execute(run_id="u", corpus="unit", commit=c_ok, spec=s_ok, req=r_ok, store=st, clock=clock)
        rd = asdict(rec_ok)
        pubs = {ISSUER.key_id: (
            ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
            ISSUER.fingerprint,
        )}
        rd["executed"] = not rd["executed"]
        rd["receipt_hash"] = ""
        from hashutil import sha256_hex as h
        rd["receipt_hash"] = h({k: rd[k] if k != "receipt_hash" else "" for k in rd})
        spec_d = s_ok.public_dict() | {"consumed": s_ok.consumed}
        v = verify_receipt(rd, spec_d, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs)
        if v["ok"]:
            fails.append("tampered_receipt_accepted")
        # field mutations
        for field in ("actor_id", "commit_id", "executed_payment_identity", "reconciled_final_state",
                       "action_type", "resource_id", "nonce", "execution_ts",
                       "revocation_status_at_exec", "revocation_version_at_exec",
                       "pre_state_hash", "post_state_hash", "authority_hash", "request_hash",
                       "authority_id", "authorized_amount_or_ceiling", "authorized_destination",
                       "authorized_payment_identity", "spec_expires_at", "commit_signature", "issuer_key_id"):
            rd2 = asdict(rec_ok)
            rd2[field] = "MUTATED"
            rd2["receipt_hash"] = h({k: rd2[k] if k != "receipt_hash" else "" for k in rd2})
            v2 = verify_receipt(rd2, spec_d, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs)
            if v2["ok"]:
                fails.append(f"mutated_{field}_accepted")
        s_b = spec(10, order)
        r_b = req(nonce="n-B")
        c_b = CommitGuard(Clock(11.0), ISSUER).commit(s_b, r_b, st.version_hash("#W1"))
        if not isinstance(c_b, tuple):
            vb = verify_receipt(asdict(rec_ok), spec_d, asdict(r_ok), {k: getattr(c_b, k) for k in c_b.__dataclass_fields__}, pubs)
            if vb["ok"]:
                fails.append("event_for_distinct_commit")
        # fabricated success from a denial-shaped receipt without new event sig
        rd3 = asdict(rec_ok)
        rd3["executed"] = True
        rd3["execution_decision"] = "ALLOW"
        if rd3.get("execution_event"):
            rd3["execution_event"] = dict(rd3["execution_event"])
            rd3["execution_event"]["executed"] = True
            rd3["execution_event"]["decision"] = "ALLOW"
            # keep old signature
        rd3["receipt_hash"] = h({k: rd3[k] if k != "receipt_hash" else "" for k in rd3})
        v3 = verify_receipt(rd3, spec_d, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs)
        # rec_ok was already executed so this is messy; separate never-executed below

    # two clients same path
    import tempfile, threading
    from ledger import LedgerStorageError
    tmp = Path(tempfile.mkdtemp()) / "led.json"
    results = []
    errs = []
    def worker(tag):
        try:
            L = ExecutionLedger(tmp)
            results.append((tag, L.try_consume("CID-SHARED")[0]))
        except Exception as e:
            errs.append(repr(e))
    t1 = threading.Thread(target=worker, args=("a",))
    t2 = threading.Thread(target=worker, args=("b",))
    t1.start(); t2.start(); t1.join(); t2.join()
    if errs:
        fails.append(f"worker_errors {errs}")
    if len(results) != 2:
        fails.append(f"missing_worker_result {results}")
    wins = sum(1 for _, w in results if w is True)
    losses = sum(1 for _, w in results if w is False)
    if wins != 1 or losses != 1:
        fails.append(f"atomic_try_consume {results}")
    L1 = ExecutionLedger(tmp)
    L2 = ExecutionLedger(tmp)
    w1 = L1.try_consume("CID-2")[0]
    w2 = L2.try_consume("CID-2")[0]
    if not (w1 and not w2):
        fails.append(f"two_preexisting_clients {w1}{w2}")
    # in-memory two threads — join every worker
    mem = ExecutionLedger()
    mres, merr = [], []
    def mworker(tag):
        try:
            mres.append(mem.try_consume("MEM")[0])
        except Exception as e:
            merr.append(repr(e))
    th = [threading.Thread(target=mworker, args=(x,)) for x in ("a", "b")]
    for x in th:
        x.start()
    for x in th:
        x.join()
    if merr or len(mres) != 2 or sum(1 for x in mres if x) != 1:
        fails.append(f"mem_threads {mres} {merr}")
    # corruption fail-closed
    good = Path(tempfile.mkdtemp()) / "c.json"
    G = ExecutionLedger(good)
    assert G.try_consume("Z")[0]
    for payload in ("{not json", "", "{}"):
        good.write_text(payload)
        threw = False
        try:
            ExecutionLedger(good).try_consume("Z2")
        except LedgerStorageError:
            threw = True
        if not threw:
            fails.append(f"corrupt_accepted:{payload!r}")

    # never-executed valid commit is authorization only
    s_n = spec(10, order)
    r_n = req(nonce="n-never")
    c_n = CommitGuard(clock, ISSUER).commit(s_n, r_n, st.version_hash("#W1"))
    if not isinstance(c_n, tuple):
        fake = {
            "executed": True, "execution_decision": "ALLOW", "decision_reason": "IN_SPEC",
            "processor_mode": "SIMULATED", "processor_event_id": None,
            "external_execution": False, "external_reconciliation": "N/A",
            "simulated_acceptance": True, "execution_event": None,
            "receipt_hash": "00", "execution_ts": 10,
        }
        fake["receipt_hash"] = sha256_hex({k: fake[k] if k != "receipt_hash" else "" for k in fake})
        pubs = {ISSUER.key_id: (
            ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
            ISSUER.fingerprint,
        )}
        vn = verify_receipt(fake, s_n.public_dict()|{"consumed": s_n.consumed}, asdict(r_n), {k: getattr(c_n,k) for k in c_n.__dataclass_fields__}, pubs)
        if vn["ok"] or vn.get("execution_evidence_valid"):
            fails.append("never_executed_accepted_as_execution")
        # event A must not evidence commit B
        s_b = spec(10, order)
        r_b = req(nonce="n-B")
        c_b = CommitGuard(Clock(11.0), ISSUER).commit(s_b, r_b, st.version_hash("#W1"))
        if not isinstance(c_ok, tuple) and not isinstance(c_b, tuple):
            rdA = asdict(rec_ok)
            vb = verify_receipt(rdA, spec_d, asdict(r_ok), {k: getattr(c_b, k) for k in c_b.__dataclass_fields__}, pubs)
            if vb["ok"] or vb.get("execution_evidence_valid"):
                fails.append("event_for_distinct_commit")
        if not vn.get("authorization_valid") and False:
            pass

    print("UNIT_FAILS", fails)
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
