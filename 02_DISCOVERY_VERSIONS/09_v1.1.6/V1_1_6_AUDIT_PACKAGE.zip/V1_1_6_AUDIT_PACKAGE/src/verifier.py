"""authorization_valid is not execution_evidence_valid.

Event must bind the exact supplied commit envelope.
Every receipt field is classified. Unclassified keys fail closed.
"""
from __future__ import annotations
from hashutil import GATE_VERSION, sha256_hex
from keys import public_from_hex, signed_payload, verify_signature
from events import event_payload

UNTRUSTED_METADATA = frozenset({"receipt_version", "run_id", "corpus", "receipt_hash"})

EVENT_BOUND = {
    "execution_decision": "decision",
    "decision_reason": "reason",
    "executed": "executed",
    "principal_id": "principal_id",
    "actor_id": "actor_id",
    "action_type": "action_type",
    "resource_id": "resource_id",
    "nonce": "nonce",
    "execution_ts": "execution_ts",
    "revocation_status_at_exec": "revocation_status",
    "revocation_version_at_exec": "revocation_version",
    "pre_state_hash": "pre_state_hash",
    "post_state_hash": "post_state_hash",
    "simulated_acceptance": "simulated_acceptance",
    "external_execution": "external_execution",
    "external_reconciliation": "external_reconciliation",
    "commit_id": "commit_id",
    "authority_hash": "authority_hash",
    "request_hash": "request_hash",
}

# remaining material fields compared to spec/commit
SPEC_BOUND = (
    "authority_id",
    "authorized_amount_or_ceiling",
    "authorized_destination",
    "authorized_payment_identity",
    "spec_expires_at",
)
COMMIT_BOUND = (
    "commit_signature",
    "issuer_key_id",
)
FIXED = {
    "processor_mode": "SIMULATED",
    "processor_event_id": None,
    "external_execution": False,
    "external_reconciliation": "N/A",
}
KNOWN = UNTRUSTED_METADATA | set(EVENT_BOUND) | set(SPEC_BOUND) | set(COMMIT_BOUND) | set(FIXED) | {
    "executed_amount", "executed_destination", "executed_payment_identity",
    "reconciled_final_state", "issuer_pubkey_fingerprint", "execution_event",
    "processor_mode", "processor_event_id",
}


def _rehash_receipt(rec: dict) -> str:
    body = dict(rec)
    body["receipt_hash"] = ""
    return sha256_hex(body)


def authorization_valid(spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    if spec is None or commit is None:
        return {"ok": False, "why": "missing_spec_or_commit"}
    if not commit.get("signature"):
        return {"ok": False, "why": "unsigned"}
    kid = commit.get("issuer_key_id")
    if kid not in trusted_pubs:
        return {"ok": False, "why": "unknown_issuer"}
    pub_hex, _fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), signed_payload(commit), commit["signature"]):
        return {"ok": False, "why": "bad_commit_sig"}
    if commit.get("decision") != "ALLOW" or commit.get("gate_version") != GATE_VERSION:
        return {"ok": False, "why": "commit_not_allow"}
    if commit.get("request_hash") != sha256_hex(req):
        return {"ok": False, "why": "request_mismatch"}
    spec_pub = {k: spec[k] for k in spec if k != "consumed"}
    if commit.get("authority_hash") != sha256_hex(spec_pub):
        return {"ok": False, "why": "authority_mismatch"}
    if req.get("actor_id") != spec.get("authorized_actor_id") or commit.get("actor_id") != spec.get("authorized_actor_id"):
        return {"ok": False, "why": "actor"}
    return {"ok": True, "why": "authorization_valid"}


def _commit_envelope_hash(commit: dict) -> str:
    return sha256_hex(dict(commit))


def execution_evidence_valid(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    extra = [k for k in rec.keys() if k not in KNOWN]
    if extra:
        return {"ok": False, "why": "unclassified_fields", "mismatches": extra}
    ev = rec.get("execution_event")
    if not isinstance(ev, dict) or not ev.get("event_signature"):
        return {"ok": False, "why": "missing_execution_event", "mismatches": ["missing_event"]}
    kid = ev.get("event_issuer_key_id")
    if kid not in trusted_pubs:
        return {"ok": False, "why": "unknown_event_issuer", "mismatches": ["issuer"]}
    pub_hex, fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), event_payload(ev), ev["event_signature"]):
        return {"ok": False, "why": "bad_event_sig", "mismatches": ["sig"]}
    mismatches = []
    for rf, ef in EVENT_BOUND.items():
        if rec.get(rf) != ev.get(ef):
            mismatches.append(rf)
    if rec.get("processor_mode") != "SIMULATED":
        mismatches.append("processor_mode")
    if rec.get("processor_event_id") not in (None, "ABSENT"):
        mismatches.append("processor_event_id")
    if spec is not None:
        if rec.get("authority_id") != spec.get("authority_id"):
            mismatches.append("authority_id")
        if rec.get("authorized_amount_or_ceiling") != spec.get("authorized_amount_ceiling"):
            mismatches.append("authorized_amount_or_ceiling")
        if rec.get("authorized_destination") != spec.get("authorized_destinations"):
            mismatches.append("authorized_destination")
        if rec.get("authorized_payment_identity") != spec.get("authorized_payment_identity"):
            mismatches.append("authorized_payment_identity")
        if rec.get("spec_expires_at") != spec.get("expires_at"):
            mismatches.append("spec_expires_at")
    if commit is not None:
        if ev.get("commit_id") != commit.get("commit_id"):
            mismatches.append("event_commit_id")
        if rec.get("commit_id") != commit.get("commit_id"):
            mismatches.append("receipt_commit_id")
        env = _commit_envelope_hash(commit)
        if ev.get("commit_envelope_hash") not in (None, env) and ev.get("commit_envelope_hash") != env:
            mismatches.append("commit_envelope_hash")
        if ev.get("commit_envelope_hash") != env:
            mismatches.append("commit_envelope_mismatch")
        if rec.get("commit_signature") not in (None, commit.get("signature")) and rec.get("executed") is True:
            if rec.get("commit_signature") != commit.get("signature"):
                mismatches.append("commit_signature")
        if rec.get("executed") is True and rec.get("commit_signature") != commit.get("signature"):
            mismatches.append("commit_signature")
        if rec.get("executed") is True and rec.get("issuer_key_id") != commit.get("issuer_key_id"):
            mismatches.append("issuer_key_id")
        if ev.get("amount") != commit.get("amount"):
            mismatches.append("event_amount")
        if ev.get("destination") != commit.get("destination"):
            mismatches.append("event_destination")
        if ev.get("payment_identity") != commit.get("payment_identity"):
            mismatches.append("event_payment")
        if rec.get("executed") is True:
            if rec.get("executed_amount") != commit.get("amount"):
                mismatches.append("executed_amount")
            if rec.get("executed_destination") != commit.get("destination"):
                mismatches.append("executed_destination")
            if rec.get("executed_payment_identity") != commit.get("payment_identity"):
                mismatches.append("executed_payment_identity")
            if rec.get("reconciled_final_state") != "SIMULATED_APPLIED":
                mismatches.append("reconciled_final_state")
            if rec.get("issuer_pubkey_fingerprint") not in (fp, None) and rec.get("issuer_pubkey_fingerprint") != fp:
                mismatches.append("fingerprint")
        else:
            if rec.get("executed_amount") is not None:
                mismatches.append("deny_executed_amount")
            if rec.get("reconciled_final_state") not in ("N/A", None):
                mismatches.append("deny_reconciled")
    return {"ok": len(mismatches) == 0, "why": "event_ok" if not mismatches else "field_mismatch", "mismatches": mismatches}


def verify_receipt(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict, prior_executed_ids=None) -> dict:
    mismatches = []
    if rec.get("receipt_hash") != _rehash_receipt(rec):
        mismatches.append("receipt_hash")
    auth = authorization_valid(spec, req, commit, trusted_pubs)
    ev = execution_evidence_valid(rec, spec, req, commit, trusted_pubs)
    if not ev["ok"]:
        mismatches.append("execution_event:" + ev["why"])
        mismatches.extend(ev.get("mismatches") or [])
    if rec.get("executed") is True:
        if not ev["ok"]:
            mismatches.append("executed_without_authenticated_event")
        if commit is not None and ev["ok"]:
            if rec.get("execution_event", {}).get("commit_id") != commit.get("commit_id"):
                mismatches.append("executed_event_wrong_commit")
    overall = len(mismatches) == 0
    return {
        "ok": overall,
        "mismatches": mismatches,
        "authorization_valid": auth["ok"],
        "authorization_why": auth["why"],
        "execution_evidence_valid": ev["ok"],
        "execution_why": ev["why"],
        "receipt_hash": rec.get("receipt_hash"),
    }
