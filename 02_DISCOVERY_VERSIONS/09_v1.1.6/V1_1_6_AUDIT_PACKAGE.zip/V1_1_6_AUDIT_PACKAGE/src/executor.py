from __future__ import annotations
from dataclasses import asdict
from hashutil import GATE_VERSION
from store import ResourceStore
from models import AuthoritySpec, ExecutionBoundReceipt, ExecutionRequest, ValidatedCommit
from keys import signed_payload, verify_signature


class Executor:
    identity = "sri-executor-v1.1.6"

    def __init__(self, trusted: dict, registry=None, ledger=None, issuer=None, coordinator=None) -> None:
        self.trusted = trusted
        self.registry = registry
        self.ledger = ledger
        self.issuer = issuer
        self.coordinator = coordinator

    def execute(
        self,
        *,
        run_id: str,
        corpus: str,
        commit: ValidatedCommit | None,
        spec: AuthoritySpec | None,
        req: ExecutionRequest,
        store: ResourceStore,
        clock,
        allow_direct: bool = False,
    ) -> ExecutionBoundReceipt:
        executed = False
        post = None
        decision = "DENY"
        reason = "DIRECT_EXECUTOR_BYPASS"
        commit_id = None
        issuer_key_id = None
        commit_signature = None
        fp = None
        rev_status = None
        rev_ver = None
        if spec is not None and self.registry is not None:
            rev_status, rev_ver = self.registry.lookup(spec.authority_id)
        pre = store.version_hash(req.resource_id)

        if spec is None:
            decision, reason = "DENY", "MISSING_AUTHORITY_SPEC"
        elif commit is None:
            decision, reason = "DENY", "DIRECT_EXECUTOR_BYPASS"
        elif not getattr(commit, "signature", None):
            decision, reason = "DENY", "UNSIGNED_COMMIT"
        elif commit.issuer_key_id not in self.trusted:
            decision, reason = "DENY", "UNKNOWN_COMMIT_ISSUER"
        elif not verify_signature(self.trusted[commit.issuer_key_id][0], signed_payload(commit), commit.signature):
            decision, reason = "DENY", "INVALID_COMMIT_SIGNATURE"
        elif commit.decision != "ALLOW":
            decision, reason = "DENY", "COMMIT_NOT_ALLOW"
        elif commit.gate_version != GATE_VERSION:
            decision, reason = "DENY", "GATE_VERSION_MISMATCH"
        elif commit.request_hash != req.hash():
            decision, reason = "DENY", "POST_ALLOW_REQUEST_MUTATION"
        elif commit.authority_hash != spec.hash():
            decision, reason = "DENY", "AUTHORITY_HASH_MISMATCH"
        elif req.actor_id != spec.authorized_actor_id or commit.actor_id != spec.authorized_actor_id:
            decision, reason = "DENY", "ACTOR_MISMATCH"
        elif req.actor_id != commit.actor_id:
            decision, reason = "DENY", "POST_COMMIT_ACTOR_MUTATION"
        elif self.registry is None:
            decision, reason = "DENY", "MISSING_REVOCATION_STATE"
        elif self.ledger is None:
            decision, reason = "DENY", "MISSING_EXECUTION_LEDGER"
        else:
            fence = {"rev": (None, None), "live": None}

            def predicate():
                st, ver = self.registry.lookup(spec.authority_id)
                fence["rev"] = (st, ver)
                if clock.now() > spec.expires_at:
                    return False, "EXPIRED_AT_EXECUTION"
                if st is None:
                    return False, "UNKNOWN_AUTHORITY_STATUS"
                if st != "ACTIVE":
                    return False, "AUTHORITY_REVOKED"
                if ver != spec.revocation_version or ver != getattr(commit, "revocation_version", None):
                    return False, "STALE_REVOCATION_VERSION"
                live = store.version_hash(commit.resource_id)
                fence["live"] = live
                if live != commit.pre_state_hash:
                    return False, "STALE_RESOURCE_STATE"
                return True, "ALLOW"

            if self.coordinator is not None:
                won, why = self.coordinator.accept(self.ledger, commit.commit_id, predicate)
            else:
                won, why = self.ledger.try_consume(commit.commit_id, predicate)
            rev_status, rev_ver = fence["rev"]
            if won:
                decision, reason = "ALLOW", commit.reason
                executed = True
                post = fence["live"]
                commit_id = commit.commit_id
                issuer_key_id = commit.issuer_key_id
                commit_signature = commit.signature
                fp = self.trusted[commit.issuer_key_id][1]
            else:
                decision, reason = "DENY", why

        from events import sign_event
        ev = {
            "commit_id": None if commit is None else commit.commit_id,
            "commit_envelope_hash": None if commit is None else commit.envelope_hash(),
            "decision": decision,
            "reason": reason,
            "executed": executed,
            "principal_id": (spec.principal_id if spec is not None else (commit.principal_id if commit is not None else req.principal_id)),
            "actor_id": (spec.authorized_actor_id if spec is not None else (commit.actor_id if commit is not None else req.actor_id)),
            "action_type": (commit.action_type if commit is not None else req.action_type),
            "resource_id": (commit.resource_id if commit is not None else req.resource_id),
            "amount": None if commit is None else commit.amount,
            "destination": None if commit is None else commit.destination,
            "payment_identity": None if commit is None else commit.payment_identity,
            "nonce": (commit.nonce if commit is not None else req.nonce),
            "execution_ts": clock.now(),
            "revocation_status": rev_status,
            "revocation_version": rev_ver,
            "pre_state_hash": pre,
            "post_state_hash": post,
            "authority_hash": None if spec is None else spec.hash(),
            "request_hash": req.hash(),
            "simulated_acceptance": executed,
            "external_execution": False,
            "external_reconciliation": "N/A",
        }
        signed_ev = sign_event(self.issuer, ev) if self.issuer is not None else None

        rec = ExecutionBoundReceipt(
            receipt_version="sri-exec-receipt-v1.1",
            run_id=run_id,
            corpus=corpus,
            authority_id=None if spec is None else spec.authority_id,
            authority_hash=None if spec is None else spec.hash(),
            principal_id=(spec.principal_id if spec is not None else req.principal_id),
            actor_id=(spec.authorized_actor_id if spec is not None else req.actor_id),
            action_type=(commit.action_type if commit is not None else req.action_type),
            resource_id=(commit.resource_id if commit is not None else req.resource_id),
            authorized_amount_or_ceiling=None if spec is None else spec.authorized_amount_ceiling,
            executed_amount=commit.amount if executed and commit is not None else None,
            authorized_destination=None if spec is None else list(spec.authorized_destinations),
            executed_destination=commit.destination if executed and commit is not None else None,
            authorized_payment_identity=None if spec is None else spec.authorized_payment_identity,
            executed_payment_identity=commit.payment_identity if executed and commit is not None else None,
            nonce=(commit.nonce if commit is not None else req.nonce),
            request_hash=req.hash(),
            commit_id=(commit.commit_id if commit is not None else commit_id),
            pre_state_hash=pre,
            post_state_hash=post,
            execution_decision=decision,
            decision_reason=reason,
            executed=executed,
            processor_mode="SIMULATED",
            processor_event_id=None,
            reconciled_final_state="N/A" if not executed else "SIMULATED_APPLIED",
            execution_ts=clock.now(),
            issuer_key_id=issuer_key_id,
            commit_signature=commit_signature,
            issuer_pubkey_fingerprint=fp,
            spec_expires_at=None if spec is None else spec.expires_at,
            revocation_status_at_exec=rev_status,
            revocation_version_at_exec=rev_ver,
            simulated_acceptance=executed,
            external_execution=False,
            external_reconciliation="N/A",
            execution_event=signed_ev,
        ).seal()
        return rec
