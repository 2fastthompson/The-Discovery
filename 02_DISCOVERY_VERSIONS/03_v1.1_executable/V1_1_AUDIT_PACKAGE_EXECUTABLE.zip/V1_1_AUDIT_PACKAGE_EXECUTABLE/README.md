# V1.1 EXECUTABLE SECURITY PACKAGE

Claim under test (not a marketing claim):

An agent may propose a consequential retail action. Execution occurs only if CommitGuard issues a ValidatedCommit binding principal, action, resource, amount, destination, payment identity, expiry, nonce, and resource_version_hash. Executor rejects requests without that commit, post-ALLOW mutated requests, stale resource state, and replayed one-shot/nonce. Receipts are sealed from the actual run and independently rehashed. Processor mode is SIMULATED. Reconciliation is N/A.

Baseline: recovered V1 (`sri_taubench` / `V1_AUDIT_PACKAGE/04_SOURCE`). This package is a new tree. Frozen V1 files were not edited.

Corpora: content-pinned local `tau_retail` and `tau3_retail`.
PROVENANCE BREAK — UPSTREAM SHA UNRECOVERABLE.

Claude audits. No self-issued PASS.
