#!/usr/bin/env python3
"""Synthetic unit attacks through CommitGuard + Executor. Not empty pass."""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from clock import Clock
from executor import Executor
from gate import CommitGuard
from models import AuthoritySpec, ExecutionRequest
from store import ResourceStore
from hashutil import sha256_hex

def spec(now, order, principal="p1"):
    return AuthoritySpec(
        authority_id="a1",
        principal_id=principal,
        action_type="return",
        resource_id="#W1",
        authorized_amount_ceiling=50.0,
        authorized_destinations=["pm_orig"],
        authorized_payment_identity="pm_orig",
        authorized_mutation_set=["none"],
        issued_at=now,
        expires_at=now + 100,
        nonce="n0",
        one_shot=True,
        resource_version_hash=sha256_hex(order),
        evidence_hash="e1",
    )

def req(principal="p1", **kw):
    base = dict(principal_id=principal, actor_id="agent.1", action_type="return",
                resource_id="#W1", amount=50.0, destination="pm_orig",
                payment_identity="pm_orig", nonce="n1", authority_id="a1")
    base.update(kw)
    return ExecutionRequest(**base)

def main():
    order = {"order_id": "#W1", "user_id": "p1", "status": "delivered", "items": []}
    clock = Clock(10.0)
    fails = []
    def check(name, executed, expect_exec=False):
        if executed != expect_exec:
            fails.append(name)

    # direct bypass
    ex = Executor()
    st = ResourceStore({"#W1": order})
    rec = ex.execute(run_id="u", corpus="unit", commit=None, spec=spec(10, order), req=req(), store=st, clock=clock)
    check("bypass", rec.executed, False)

    # principal
    g = CommitGuard(clock)
    s = spec(10, order)
    r = req(principal="other")
    out = g.commit(s, r, st.version_hash("#W1"))
    check("principal", not isinstance(out, tuple) and False if isinstance(out, tuple) else False)
    if not isinstance(out, tuple):
        fails.append("principal_allowed")

    # expired
    g = CommitGuard(clock)
    s = spec(10, order)
    s.expires_at = 1.0
    out = g.commit(s, req(), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("expired_allowed")

    # nan
    g = CommitGuard(clock)
    out = g.commit(spec(10, order), req(amount=float("nan")), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("nan_allowed")

    print("UNIT_FAILS", fails)
    return 1 if fails else 0

if __name__ == "__main__":
    raise SystemExit(main())
