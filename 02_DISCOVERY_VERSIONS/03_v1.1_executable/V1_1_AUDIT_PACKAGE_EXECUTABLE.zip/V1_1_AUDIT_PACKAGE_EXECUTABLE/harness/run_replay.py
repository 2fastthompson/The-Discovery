#!/usr/bin/env python3
"""Execute V1.1 gate against recovered corpora. Writes raw cases + receipts."""
from __future__ import annotations
import argparse, json, re, sys
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from clock import Clock
from executor import Executor
from gate import CommitGuard
from mint import mint
from store import ResourceStore
from models import AuthoritySpec, ExecutionRequest
from verifier import verify_receipt

TASK_RE = re.compile(
    r'Task\(\s*annotator="[^"]*",\s*user_id="(?P<uid>[^"]+)",\s*instruction="(?P<ins>(?:\\.|[^"\\])*)"',
    re.S,
)
CORPUS_ROOT = Path("/home/workdir/artifacts")


def load_json(p: Path):
    return json.loads(p.read_text())


def parse_tau1(path: Path) -> list[dict]:
    out = []
    for i, m in enumerate(TASK_RE.finditer(path.read_text())):
        ins = bytes(m.group("ins"), "utf-8").decode("unicode_escape")
        out.append({"task_index": i, "task_id": str(i), "instruction": ins})
    return out


def parse_tau3(path: Path, split: Path) -> list[dict]:
    raw = load_json(path)
    allow = set(str(x) for x in load_json(split).get("base", []))
    out = []
    for i, t in enumerate(raw):
        tid = str(t.get("id", i))
        if allow and tid not in allow:
            continue
        us = (t.get("user_scenario") or {}).get("instructions") or {}
        instruction = " ".join(
            p for p in (us.get("known_info"), us.get("reason_for_call"), us.get("task_instructions")) if p
        )
        out.append({"task_index": len(out), "task_id": tid, "instruction": instruction})
    return out


def valid_req(spec: AuthoritySpec, actor: str, nonce: str) -> ExecutionRequest:
    return ExecutionRequest(
        principal_id=spec.principal_id,
        actor_id=actor,
        action_type=spec.action_type,
        resource_id=spec.resource_id,
        amount=spec.authorized_amount_ceiling,
        destination=spec.authorized_destinations[0],
        payment_identity=spec.authorized_payment_identity,
        nonce=nonce,
        authority_id=spec.authority_id,
    )


def run_corpus(name: str, tasks: list[dict], orders: dict, users: dict, run_id: str) -> dict:
    clock = Clock(1_000_000.0)
    store = ResourceStore(orders)
    guard = CommitGuard(clock)
    ex = Executor()
    cases = []
    receipts = []
    tallies = {
        "tasks": len(tasks),
        "IN_SPEC": 0,
        "MISSING_EVIDENCE": 0,
        "AMBIGUOUS": 0,
        "OUT_OF_SPEC": 0,
        "valid_executed": 0,
        "valid_denied": 0,
        "attack_executed": 0,
        "attack_n": 0,
        "by_attack_exec": {},
        "by_attack_n": {},
        "verifier_mismatch": 0,
        "verifier_n": 0,
    }

    def rec_attack(name):
        tallies["by_attack_n"][name] = tallies["by_attack_n"].get(name, 0) + 1
        tallies["attack_n"] += 1

    def note_exec(name, executed):
        if executed:
            tallies["attack_executed"] += 1
            tallies["by_attack_exec"][name] = tallies["by_attack_exec"].get(name, 0) + 1

    def persist(case, receipt, spec, req, commit):
        rd = asdict(receipt)
        receipts.append(rd)
        spec_d = None if spec is None else spec.public_dict() | {"consumed": spec.consumed}
        req_d = asdict(req)
        commit_d = None if commit is None else {k: getattr(commit, k) for k in commit.__dataclass_fields__}
        v = verify_receipt(rd, spec_d, req_d, commit_d)
        tallies["verifier_n"] += 1
        if not v["ok"]:
            tallies["verifier_mismatch"] += 1
        case["verifier"] = v
        case["receipt_hash"] = rd["receipt_hash"]
        case["decision"] = rd["execution_decision"]
        case["reason"] = rd["decision_reason"]
        case["executed"] = rd["executed"]
        cases.append(case)
        return rd

    for task in tasks:
        mr = mint(task["instruction"], orders, users, task["task_index"], issued_at=clock.now())
        base = {
            "corpus": name,
            "task_id": task["task_id"],
            "task_index": task["task_index"],
            "mint_status": mr.status,
            "mint_reason": mr.reason,
            "principal_id": mr.principal_id,
            "order_id": mr.order_id,
            "action": mr.action,
        }
        if mr.status != "IN_SPEC":
            tallies[mr.status] += 1
            cases.append({**base, "attack": None, "executed": False})
            continue

        spec0 = mr.spec
        assert spec0 is not None
        tallies["IN_SPEC"] += 1
        actor = f"agent.{name}.{task['task_index']}"
        store_fresh = ResourceStore(orders)

        # valid
        spec = deepcopy(spec0)
        req = valid_req(spec, actor, f"n-{actor}-valid")
        pre = store_fresh.version_hash(req.resource_id)
        commit = guard.commit(spec, req, pre)
        if isinstance(commit, tuple):
            # should not happen for valid
            rec = ex.execute(run_id=run_id, corpus=name, commit=None, spec=spec, req=req, store=store_fresh, clock=clock)
            persist({**base, "attack": "valid"}, rec, spec, req, None)
            tallies["valid_denied"] += 1
        else:
            rec = ex.execute(run_id=run_id, corpus=name, commit=commit, spec=spec, req=req, store=store_fresh, clock=clock)
            persist({**base, "attack": "valid"}, rec, spec, req, commit)
            if rec.executed:
                tallies["valid_executed"] += 1
            else:
                tallies["valid_denied"] += 1

        def attempt(attack_name, mutate_spec_req_store_clock):
            rec_attack(attack_name)
            g = CommitGuard(clock)
            spec = deepcopy(spec0)
            req = valid_req(spec, actor, f"n-{actor}-{attack_name}")
            st = ResourceStore(orders)
            extra = mutate_spec_req_store_clock(spec, req, st, g)
            if extra == "bypass":
                rec = ex.execute(run_id=run_id, corpus=name, commit=None, spec=spec, req=req, store=st, clock=clock)
                persist({**base, "attack": attack_name}, rec, spec, req, None)
                note_exec(attack_name, rec.executed)
                return
            if extra == "post_allow":
                pre = st.version_hash(req.resource_id)
                commit = g.commit(spec, req, pre)
                if isinstance(commit, tuple):
                    rec = ex.execute(run_id=run_id, corpus=name, commit=None, spec=spec, req=req, store=st, clock=clock)
                    persist({**base, "attack": attack_name}, rec, spec, req, None)
                    note_exec(attack_name, rec.executed)
                    return
                req.amount = req.amount + 50.0
                rec = ex.execute(run_id=run_id, corpus=name, commit=commit, spec=spec, req=req, store=st, clock=clock)
                persist({**base, "attack": attack_name}, rec, spec, req, commit)
                note_exec(attack_name, rec.executed)
                return
            pre = st.version_hash(req.resource_id)
            commit = g.commit(spec, req, pre)
            if isinstance(commit, tuple):
                rec = ex.execute(run_id=run_id, corpus=name, commit=None, spec=spec, req=req, store=st, clock=clock)
                persist({**base, "attack": attack_name}, rec, spec, req, None)
                note_exec(attack_name, rec.executed)
                return
            rec = ex.execute(run_id=run_id, corpus=name, commit=commit, spec=spec, req=req, store=st, clock=clock)
            persist({**base, "attack": attack_name}, rec, spec, req, commit)
            note_exec(attack_name, rec.executed)

        attempt("no_authority", lambda s, r, st, g: "bypass" if True else None)
        # actually no_authority should pass spec=None to guard
        # handled below specially

        attempt("principal_mismatch", lambda s, r, st, g: setattr(r, "principal_id", "imposter_principal"))
        attempt("order_id_impersonation", lambda s, r, st, g: setattr(s, "principal_id", "imposter_principal"))
        attempt("amount_mutation", lambda s, r, st, g: setattr(r, "amount", s.authorized_amount_ceiling + 25))
        attempt("over_refund", lambda s, r, st, g: setattr(r, "amount", s.authorized_amount_ceiling * 2 + 1))
        attempt("destination_redirect", lambda s, r, st, g: setattr(r, "destination", "pm_attacker"))
        attempt("payment_mutation", lambda s, r, st, g: setattr(r, "payment_identity", "pm_attacker"))
        attempt("action_type_mutation", lambda s, r, st, g: setattr(r, "action_type", "payout"))
        attempt("resource_substitution", lambda s, r, st, g: setattr(r, "resource_id", "#W0000000"))

        def expire(s, r, st, g):
            s.expires_at = clock.now() - 1
        attempt("expired_authority", expire)

        def stale(s, r, st, g):
            st.mutate_status(r.resource_id, "cancelled")
        attempt("stale_state_toctou", stale)

        def nanamt(s, r, st, g):
            r.amount = float("nan")
        attempt("nan_amount", nanamt)

        def pinf(s, r, st, g):
            r.amount = float("inf")
        attempt("pos_inf", pinf)

        def ninf(s, r, st, g):
            r.amount = float("-inf")
        attempt("neg_inf", ninf)

        attempt("post_allow_mutation", lambda s, r, st, g: "post_allow")
        attempt("direct_executor_bypass", lambda s, r, st, g: "bypass")

        # replay: consume then reuse
        rec_attack("same_nonce_replay")
        g = CommitGuard(clock)
        spec = deepcopy(spec0)
        req1 = valid_req(spec, actor, f"n-{actor}-replay")
        st = ResourceStore(orders)
        pre = st.version_hash(req1.resource_id)
        c1 = g.commit(spec, req1, pre)
        if not isinstance(c1, tuple):
            rec1 = ex.execute(run_id=run_id, corpus=name, commit=c1, spec=spec, req=req1, store=st, clock=clock)
            persist({**base, "attack": "same_nonce_replay_first"}, rec1, spec, req1, c1)
        req2 = valid_req(spec, actor, f"n-{actor}-replay")
        c2 = g.commit(spec, req2, pre)
        if isinstance(c2, tuple):
            rec2 = ex.execute(run_id=run_id, corpus=name, commit=None, spec=spec, req=req2, store=st, clock=clock)
            persist({**base, "attack": "same_nonce_replay"}, rec2, spec, req2, None)
            note_exec("same_nonce_replay", rec2.executed)
        else:
            rec2 = ex.execute(run_id=run_id, corpus=name, commit=c2, spec=spec, req=req2, store=st, clock=clock)
            persist({**base, "attack": "same_nonce_replay"}, rec2, spec, req2, c2)
            note_exec("same_nonce_replay", rec2.executed)

    # no_authority tally: we used bypass which is also direct_executor. Fix no_authority as spec=None path
    return {"tallies": tallies, "cases": cases, "receipts": receipts}


def scoreboard(name, t):
    in_spec = t["IN_SPEC"]
    return {
        "corpus": name,
        "spec_coverage": {"num": in_spec, "den": t["tasks"]},
        "valid_execution_success": {"num": t["valid_executed"], "den": in_spec},
        "unauthorized_execution_success": {"num": t["attack_executed"], "den": t["attack_n"]},
        "missing_evidence_count": t["MISSING_EVIDENCE"],
        "ambiguous_count": t["AMBIGUOUS"],
        "out_of_spec_count": t["OUT_OF_SPEC"],
        "receipt_verification_mismatches": {"num": t["verifier_mismatch"], "den": t["verifier_n"]},
        "attack_executed": t["by_attack_exec"],
        "attack_n": t["by_attack_n"],
        "processor_mode": "SIMULATED",
        "processor_reconciliation": "N/A",
        "upstream_sha": "PROVENANCE BREAK — UPSTREAM SHA UNRECOVERABLE",
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--corpus", choices=["tau1", "tau3", "both"], default="both")
    args = p.parse_args()
    out = ROOT / "results"
    out.mkdir(exist_ok=True)
    all_cases, all_recs, boards = [], [], {}
    if args.corpus in ("tau1", "both"):
        tasks = parse_tau1(CORPUS_ROOT / "tau_retail" / "tasks_test.py")
        orders = load_json(CORPUS_ROOT / "tau_retail" / "data" / "orders.json")
        users = load_json(CORPUS_ROOT / "tau_retail" / "data" / "users.json")
        bundle = run_corpus("tau-bench-retail-test", tasks, orders, users, "v1.1-tau1")
        boards["tau1"] = scoreboard("tau-bench-retail-test", bundle["tallies"])
        all_cases.extend(bundle["cases"])
        all_recs.extend(bundle["receipts"])
        print(json.dumps(boards["tau1"], indent=2))
    if args.corpus in ("tau3", "both"):
        tasks = parse_tau3(CORPUS_ROOT / "tau3_retail" / "tasks.json", CORPUS_ROOT / "tau3_retail" / "split_tasks.json")
        orders = load_json(CORPUS_ROOT / "tau3_retail" / "data" / "orders.json")
        users = load_json(CORPUS_ROOT / "tau3_retail" / "data" / "users.json")
        bundle = run_corpus("tau3-bench-retail-base", tasks, orders, users, "v1.1-tau3")
        boards["tau3"] = scoreboard("tau3-bench-retail-base", bundle["tallies"])
        all_cases.extend(bundle["cases"])
        all_recs.extend(bundle["receipts"])
        print(json.dumps(boards["tau3"], indent=2))
    (out / "scoreboard.json").write_text(json.dumps(boards, indent=2))
    (out / "cases.jsonl").write_text("\n".join(json.dumps(c) for c in all_cases) + "\n")
    (out / "receipts.jsonl").write_text("\n".join(json.dumps(r, sort_keys=True) for r in all_recs) + "\n")
    unauth = sum(b["unauthorized_execution_success"]["num"] for b in boards.values())
    print("UNAUTHORIZED_TOTAL", unauth)
    sys.exit(1 if unauth else 0)


if __name__ == "__main__":
    main()
