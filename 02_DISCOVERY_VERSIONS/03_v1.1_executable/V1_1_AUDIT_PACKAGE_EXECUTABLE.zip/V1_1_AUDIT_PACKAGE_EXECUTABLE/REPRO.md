# Reproduction

Runtime: CPython 3.12.3, stdlib only.

```
cd V1_1_AUDIT_PACKAGE_EXECUTABLE
python3 harness/run_replay.py --corpus both
python3 -c "from pathlib import Path; import sys; sys.path.insert(0,'src'); sys.path.insert(0,'harness'); import json; print(Path('results/scoreboard.json').read_text())"
python3 tests/test_attacks.py
```

Corpora read from `/home/workdir/artifacts/tau_retail` and `/home/workdir/artifacts/tau3_retail` (same bytes as V1 baseline recovery).
