from __future__ import annotations


class Clock:
    def __init__(self, now: float = 1_000_000.0) -> None:
        self._now = float(now)

    def now(self) -> float:
        return self._now

    def set(self, t: float) -> None:
        self._now = float(t)

    def advance(self, seconds: float) -> None:
        self._now += float(seconds)
