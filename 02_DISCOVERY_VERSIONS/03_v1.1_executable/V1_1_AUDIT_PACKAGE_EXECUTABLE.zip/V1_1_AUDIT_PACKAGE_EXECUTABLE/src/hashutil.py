from __future__ import annotations
import hashlib, json, math
from typing import Any

GATE_VERSION = "sri-v1.1-commitguard-0"


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def sha256_hex(obj: Any) -> str:
    if isinstance(obj, str):
        payload = obj.encode("utf-8")
    elif isinstance(obj, bytes):
        payload = obj
    else:
        payload = canonical_json(obj).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def reject_number(value: Any) -> str | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return "MALFORMED_AMOUNT"
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return "NONFINITE_AMOUNT"
    if value < 0:
        return "NEGATIVE_AMOUNT"
    return None
