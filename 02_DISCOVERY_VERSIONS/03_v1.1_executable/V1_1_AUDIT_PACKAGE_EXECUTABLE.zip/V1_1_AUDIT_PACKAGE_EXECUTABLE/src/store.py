from __future__ import annotations
from copy import deepcopy
from hashutil import sha256_hex


class ResourceStore:
    """Authoritative order snapshot for TOCTOU re-read."""

    def __init__(self, orders: dict) -> None:
        self._orders = dict(orders)

    def get(self, resource_id: str) -> dict | None:
        o = self._orders.get(resource_id)
        return deepcopy(o) if o else None

    def version_hash(self, resource_id: str) -> str | None:
        o = self._orders.get(resource_id)
        if o is None:
            return None
        return sha256_hex(o)

    def mutate_status(self, resource_id: str, status: str) -> None:
        if resource_id in self._orders:
            rec = deepcopy(self._orders[resource_id])
            rec["status"] = status
            self._orders[resource_id] = rec
