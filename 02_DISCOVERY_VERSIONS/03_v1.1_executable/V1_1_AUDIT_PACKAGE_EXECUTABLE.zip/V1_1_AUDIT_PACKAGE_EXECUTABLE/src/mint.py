"""V1.1 mint: instruction + SoR only. No gold actions. No order-id principal bootstrap."""
from __future__ import annotations
import re
from dataclasses import dataclass
from hashutil import sha256_hex
from models import AuthoritySpec

ORDER_RE = re.compile(r"#W\d+")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
USER_ID_RE = re.compile(
    r"you are\s+([a-z]+_[a-z]+_\d+)\s*(?:\((?:zip(?:\s+code)?)\s+(\d{5})\))?",
    re.I,
)
NAME_ZIP_RE = re.compile(
    r"you are\s+([A-Z][a-z]+)\s+([A-Z][a-z]+)\s+in(?:\s+zip(?:\s+code)?)?\s+(\d{5})",
    re.I,
)
NAME_LIVE_ZIP_RE = re.compile(
    r"you are\s+([A-Z][a-z]+)\s+([A-Z][a-z]+)\b[^.]{0,80}?\b(\d{5})",
    re.I,
)
NAME_ZIP_RE2 = re.compile(
    r"([A-Z][a-z]+)\s+([A-Z][a-z]+).*?\b(?:zip(?:\s+code)?)\s+(\d{5})",
    re.I,
)
NAME_ALT_RE = re.compile(
    r"(?:your name is|you(?:'| a)re|called)\s+([A-Z][a-z]+)\s+([A-Z][a-z]+)\b[^.]{0,120}?\b(\d{5})",
    re.I,
)
CONSEQUENTIAL = (
    ("return", "return"),
    ("exchange", "exchange"),
    ("cancel", "cancel"),
    ("refund", "return"),
    ("modify", "modify"),
)


def declared_action(instruction: str) -> str | None:
    low = instruction.lower()
    for needle, action in CONSEQUENTIAL:
        if needle in low:
            return action
    return None


def order_amount(order: dict) -> float:
    items = order.get("items") or []
    if items:
        return round(sum(float(it.get("price") or 0) for it in items), 2)
    hist = order.get("payment_history") or []
    pays = [h for h in hist if h.get("transaction_type") == "payment"]
    return round(sum(float(h.get("amount") or 0) for h in pays), 2)


def original_payment_ids(order: dict) -> list[str]:
    seen: list[str] = []
    for h in order.get("payment_history") or []:
        if h.get("transaction_type") == "payment" and h.get("payment_method_id"):
            pid = h["payment_method_id"]
            if pid not in seen:
                seen.append(pid)
    return seen


def gift_cards(user: dict) -> list[str]:
    ids = []
    for pid, meta in (user.get("payment_methods") or {}).items():
        src = (meta or {}).get("source") or ""
        if "gift" in src or pid.startswith("gift_card"):
            ids.append(pid)
    return ids


def destinations(order: dict, user: dict, instruction: str) -> list[str]:
    dest = list(original_payment_ids(order))
    if "gift" in instruction.lower():
        for g in gift_cards(user):
            if g not in dest:
                dest.append(g)
    return dest


def status_allows(action: str, status: str) -> bool:
    if action == "cancel":
        return status == "pending"
    if action in ("return", "exchange"):
        return status == "delivered"
    if action == "modify":
        return status == "pending"
    return False


def _name_zip_hits(users: dict, first: str, last: str, zipc: str) -> list[str]:
    hits = []
    for uid, u in users.items():
        name = u.get("name") or {}
        z = (u.get("address") or {}).get("zip")
        if (
            (name.get("first_name") or "").lower() == first.lower()
            and (name.get("last_name") or "").lower() == last.lower()
            and str(z) == zipc
        ):
            hits.append(uid)
    return hits


def lookup_principal(instruction: str, users: dict) -> tuple[str | None, str]:
    uid_m = USER_ID_RE.search(instruction)
    if uid_m:
        uid = uid_m.group(1)
        zipc = uid_m.group(2)
        if uid in users:
            if zipc:
                z = str((users[uid].get("address") or {}).get("zip") or "")
                if z and z != zipc:
                    return None, "user_id_zip_mismatch"
            return uid, "user_id_in_instruction"
        return None, "user_id_not_in_sor"
    email = EMAIL_RE.search(instruction)
    if email:
        addr = email.group(0).lower()
        hits = [uid for uid, u in users.items() if (u.get("email") or "").lower() == addr]
        if len(hits) == 1:
            return hits[0], "email_lookup"
        if len(hits) > 1:
            return None, "ambiguous_email_lookup"
    m = (
        NAME_ZIP_RE.search(instruction)
        or NAME_LIVE_ZIP_RE.search(instruction)
        or NAME_ALT_RE.search(instruction)
        or NAME_ZIP_RE2.search(instruction)
    )
    if not m:
        return None, "no_user_identity_in_instruction"
    hits = _name_zip_hits(users, m.group(1), m.group(2), m.group(3))
    if len(hits) == 1:
        return hits[0], "name_zip_lookup"
    if len(hits) > 1:
        return None, "ambiguous_name_zip_lookup"
    return None, "name_zip_not_in_sor"


def item_names(order: dict) -> list[str]:
    return [str(it.get("name") or "") for it in (order.get("items") or []) if it.get("name")]


def mentioned_item_orders(instruction: str, candidate_orders: list[dict]) -> list[dict]:
    low = instruction.lower()
    scored = []
    for order in candidate_orders:
        hits = 0
        for name in item_names(order):
            if len(name) >= 4 and name.lower() in low:
                hits += 1
        scored.append((hits, order))
    if any(h > 0 for h, _ in scored):
        return [o for h, o in scored if h > 0]
    return candidate_orders


@dataclass
class MintResult:
    status: str
    reason: str
    spec: AuthoritySpec | None
    action: str | None
    order_id: str | None
    principal_id: str | None
    evidence_path: list[str]


def mint(instruction: str, orders: dict, users: dict, task_index: int, issued_at: float, ttl: float = 3600.0) -> MintResult:
    path = ["instruction"]
    action = declared_action(instruction)
    if action is None:
        return MintResult("OUT_OF_SPEC", "no_consequential_verb", None, None, None, None, path)
    path.append(f"declared_action={action}")

    principal, how = lookup_principal(instruction, users)
    if principal is None:
        # order id must not bootstrap principal
        return MintResult("MISSING_EVIDENCE", f"no_principal:{how}", None, action, None, None, path + [how])
    path.append(f"principal:{how}:{principal}")
    user = users[principal]
    owned = list(user.get("orders") or [])
    path.append(f"inventory:{len(owned)}")

    named = ORDER_RE.findall(instruction)
    candidates: list[dict] = []
    if named:
        path.append(f"named:{named}")
        for oid in named:
            order = orders.get(oid)
            if not order:
                continue
            if order.get("user_id") != principal:
                path.append(f"reject_foreign:{oid}")
                continue
            candidates.append(order)
    else:
        for oid in owned:
            order = orders.get(oid)
            if order:
                candidates.append(order)

    if not candidates:
        return MintResult("MISSING_EVIDENCE", "no_candidate_orders", None, action, None, principal, path)

    status_ok = [o for o in candidates if status_allows(action, o.get("status") or "")]
    path.append(f"status_filter:{len(status_ok)}/{len(candidates)}")
    if not status_ok:
        return MintResult("MISSING_EVIDENCE", "no_order_status_authorizes_action", None, action, None, principal, path)

    narrowed = mentioned_item_orders(instruction, status_ok)
    path.append(f"item_filter:{len(narrowed)}/{len(status_ok)}")
    if len(narrowed) > 1:
        return MintResult("AMBIGUOUS", "multiple_orders_match_action_and_items", None, action, None, principal, path)

    order = narrowed[0]
    oid = order.get("order_id")
    dests = destinations(order, user, instruction)
    orig = original_payment_ids(order)
    if not dests or not orig:
        return MintResult("MISSING_EVIDENCE", "no_payment_identity_on_order", None, action, oid, principal, path)

    ev = sha256_hex({"ins": instruction, "p": principal, "o": oid, "a": action})
    spec = AuthoritySpec(
        authority_id=sha256_hex({"t": task_index, "o": oid, "a": action, "p": principal})[:24],
        principal_id=principal,
        action_type=action,
        resource_id=oid,
        authorized_amount_ceiling=order_amount(order),
        authorized_destinations=dests,
        authorized_payment_identity=orig[0],
        authorized_mutation_set=["none"],
        issued_at=issued_at,
        expires_at=issued_at + ttl,
        nonce=f"auth-{task_index}-{oid}",
        one_shot=True,
        resource_version_hash=sha256_hex(order),
        evidence_hash=ev,
    )
    path.append("authority_minted")
    return MintResult("IN_SPEC", "derived_from_lookup_and_sor", spec, action, oid, principal, path)
