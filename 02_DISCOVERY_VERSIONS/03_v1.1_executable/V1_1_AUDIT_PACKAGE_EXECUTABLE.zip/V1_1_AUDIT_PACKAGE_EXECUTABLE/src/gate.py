from __future__ import annotations
from hashutil import GATE_VERSION, reject_number, sha256_hex
from models import AuthoritySpec, ExecutionRequest, ValidatedCommit


class CommitGuard:
    def __init__(self, clock) -> None:
        self.clock = clock
        self._consumed_auth: set[str] = set()
        self._consumed_nonce: set[str] = set()

    def decide(self, spec: AuthoritySpec | None, req: ExecutionRequest, pre_state_hash: str | None) -> tuple[str, str]:
        bad = reject_number(req.amount)
        if bad:
            return "DENY", bad
        if spec is None:
            return "DENY", "NO_AUTHORITY"
        if spec.consumed or spec.authority_id in self._consumed_auth:
            return "DENY", "REPLAYED_ONE_SHOT_AUTHORITY"
        if req.nonce in self._consumed_nonce:
            return "DENY", "REPLAYED_NONCE"
        now = self.clock.now()
        if now > spec.expires_at:
            return "DENY", "EXPIRED_AUTHORITY"
        if now < spec.issued_at:
            return "DENY", "AUTHORITY_NOT_YET_VALID"
        if req.principal_id != spec.principal_id:
            return "DENY", "PRINCIPAL_MISMATCH"
        if req.authority_id and req.authority_id != spec.authority_id:
            return "DENY", "AUTHORITY_ID_MISMATCH"
        if req.resource_id != spec.resource_id:
            return "DENY", "MUTATED_RESOURCE_IDENTITY"
        if req.action_type != spec.action_type:
            return "DENY", "MUTATED_ACTION_TYPE"
        if req.amount - spec.authorized_amount_ceiling > 1e-9:
            return "DENY", "MUTATED_AMOUNT_OR_OVER_REFUND"
        if req.destination not in spec.authorized_destinations:
            return "DENY", "MUTATED_DESTINATION"
        if req.payment_identity != spec.authorized_payment_identity:
            return "DENY", "MUTATED_PAYMENT_IDENTITY"
        if pre_state_hash is None:
            return "DENY", "MISSING_PRE_STATE"
        if pre_state_hash != spec.resource_version_hash:
            return "DENY", "STALE_RESOURCE_STATE"
        return "ALLOW", "IN_SPEC"

    def commit(self, spec: AuthoritySpec, req: ExecutionRequest, pre_state_hash: str) -> ValidatedCommit | tuple[str, str]:
        decision, reason = self.decide(spec, req, pre_state_hash)
        if decision != "ALLOW":
            return decision, reason
        spec.consumed = True
        self._consumed_auth.add(spec.authority_id)
        self._consumed_nonce.add(req.nonce)
        vc = ValidatedCommit.mint(
            commit_id=sha256_hex({"a": spec.authority_id, "n": req.nonce, "t": self.clock.now()})[:24],
            gate_version=GATE_VERSION,
            decision="ALLOW",
            reason=reason,
            authority_hash=spec.hash(),
            request_hash=req.hash(),
            pre_state_hash=pre_state_hash,
            principal_id=req.principal_id,
            actor_id=req.actor_id,
            action_type=req.action_type,
            resource_id=req.resource_id,
            amount=req.amount,
            destination=req.destination,
            payment_identity=req.payment_identity,
            nonce=req.nonce,
            committed_at=self.clock.now(),
        )
        return vc
