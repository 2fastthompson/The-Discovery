from __future__ import annotations
from dataclasses import asdict, dataclass, field
from typing import Any
from hashutil import GATE_VERSION, sha256_hex


@dataclass
class AuthoritySpec:
    authority_id: str
    principal_id: str
    action_type: str
    resource_id: str
    authorized_amount_ceiling: float
    authorized_destinations: list[str]
    authorized_payment_identity: str
    authorized_mutation_set: list[str]
    issued_at: float
    expires_at: float
    nonce: str
    one_shot: bool
    resource_version_hash: str
    evidence_hash: str
    consumed: bool = False

    def public_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d.pop("consumed", None)
        return d

    def hash(self) -> str:
        return sha256_hex(self.public_dict())


@dataclass
class ExecutionRequest:
    principal_id: str
    actor_id: str
    action_type: str
    resource_id: str
    amount: float
    destination: str
    payment_identity: str
    nonce: str
    authority_id: str | None = None

    def hash(self) -> str:
        return sha256_hex(asdict(self))


@dataclass(frozen=True)
class ValidatedCommit:
    commit_id: str
    gate_version: str
    decision: str
    reason: str
    authority_hash: str
    request_hash: str
    pre_state_hash: str
    principal_id: str
    actor_id: str
    action_type: str
    resource_id: str
    amount: float
    destination: str
    payment_identity: str
    nonce: str
    committed_at: float
    commit_hash: str

    @staticmethod
    def mint(**kwargs) -> "ValidatedCommit":
        body = dict(kwargs)
        body.setdefault("gate_version", GATE_VERSION)
        body["commit_hash"] = ""
        digest = sha256_hex(body)
        body["commit_hash"] = digest
        return ValidatedCommit(**body)


@dataclass
class ExecutionBoundReceipt:
    receipt_version: str
    run_id: str
    corpus: str
    authority_id: str | None
    authority_hash: str | None
    principal_id: str
    actor_id: str
    action_type: str
    resource_id: str
    authorized_amount_or_ceiling: float | None
    executed_amount: float | None
    authorized_destination: list[str] | None
    executed_destination: str | None
    authorized_payment_identity: str | None
    executed_payment_identity: str | None
    nonce: str
    request_hash: str
    commit_id: str | None
    pre_state_hash: str | None
    post_state_hash: str | None
    execution_decision: str
    decision_reason: str
    executed: bool
    processor_mode: str
    processor_event_id: str | None
    reconciled_final_state: str
    execution_ts: float
    receipt_hash: str = ""

    def seal(self) -> "ExecutionBoundReceipt":
        body = asdict(self)
        body["receipt_hash"] = ""
        self.receipt_hash = sha256_hex(body)
        return self
