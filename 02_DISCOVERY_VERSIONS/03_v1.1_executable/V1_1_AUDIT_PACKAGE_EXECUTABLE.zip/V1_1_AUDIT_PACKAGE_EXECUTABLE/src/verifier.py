"""Independent receipt verifier. Does not import CommitGuard.decide or Executor.execute."""
from __future__ import annotations
import math
from hashutil import GATE_VERSION, sha256_hex


def _rehash_receipt(rec: dict) -> str:
    body = dict(rec)
    body["receipt_hash"] = ""
    return sha256_hex(body)


def _finite_amount(v) -> bool:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return False
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return False
    return True


def verify_receipt(rec: dict, spec: dict | None, req: dict, commit: dict | None) -> dict:
    """Recompute hashes and consistency from raw dicts. Returns mismatch list."""
    mismatches = []
    if rec.get("receipt_hash") != _rehash_receipt(rec):
        mismatches.append("receipt_hash")
    if rec.get("processor_mode") != "SIMULATED":
        mismatches.append("processor_mode")
    if rec.get("processor_event_id") not in (None, "ABSENT"):
        mismatches.append("fabricated_processor_event")

    req_hash = sha256_hex(req)
    if rec.get("request_hash") != req_hash:
        mismatches.append("request_hash")

    if spec is not None:
        spec_pub = {k: spec[k] for k in spec if k != "consumed"}
        if rec.get("authority_hash") != sha256_hex(spec_pub):
            mismatches.append("authority_hash")
        if rec.get("principal_id") != spec.get("principal_id") and rec.get("execution_decision") == "ALLOW":
            mismatches.append("principal_on_allow")

    if rec.get("executed") is True:
        if rec.get("execution_decision") != "ALLOW":
            mismatches.append("executed_without_allow")
        if commit is None:
            mismatches.append("executed_without_commit")
        else:
            body = {k: commit[k] for k in commit if k != "commit_hash"}
            body["commit_hash"] = ""
            if commit.get("commit_hash") != sha256_hex(body):
                mismatches.append("commit_hash")
            if commit.get("decision") != "ALLOW":
                mismatches.append("commit_not_allow")
            if commit.get("gate_version") != GATE_VERSION:
                mismatches.append("gate_version")
            if commit.get("request_hash") != req_hash:
                mismatches.append("commit_request_hash")
        if rec.get("executed_amount") is not None and not _finite_amount(rec["executed_amount"]):
            mismatches.append("nonfinite_executed_amount")

    if rec.get("execution_decision") == "ALLOW" and rec.get("executed") is not True:
        mismatches.append("allow_not_executed")

    return {"ok": len(mismatches) == 0, "mismatches": mismatches, "receipt_hash": rec.get("receipt_hash")}
