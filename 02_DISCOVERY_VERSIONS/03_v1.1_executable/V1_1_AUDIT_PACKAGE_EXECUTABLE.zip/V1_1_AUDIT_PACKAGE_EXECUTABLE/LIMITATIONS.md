# Known limitations

- PROVENANCE BREAK — UPSTREAM SHA UNRECOVERABLE for tau_retail and tau3_retail.
- Content-pinning is not upstream authenticity.
- Processor fields are SIMULATED / ABSENT / N/A. This package does not prove Stripe settlement.
- Gift-card destinations are added only when the instruction contains "gift"; wiki default auto-add from V1 was removed.
- Order ID alone cannot mint principal authority (V1.1). Coverage 42/115 and 43/114 vs V1 43/115 and 44/114.
- Missing-evidence and ambiguous mint outcomes do not create authority and do not execute.
- Independent verifier recomputes hashes and ALLOW/executed consistency; it does not re-implement a second full policy engine.
- No cryptographic signature beyond SHA-256 integrity hash.
- No live processor credentials in this package.
