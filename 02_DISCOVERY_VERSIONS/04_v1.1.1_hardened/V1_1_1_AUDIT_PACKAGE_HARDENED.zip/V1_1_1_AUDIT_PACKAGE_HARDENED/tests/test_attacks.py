#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from clock import Clock
from executor import Executor
from gate import CommitGuard
from models import AuthoritySpec, ExecutionRequest, ValidatedCommit
from store import ResourceStore
from hashutil import sha256_hex, GATE_VERSION
from keys import load_test_issuer

ROOT = Path(__file__).resolve().parents[1]
ISSUER = load_test_issuer(ROOT / "fixtures" / "test_ed25519.json")
TRUSTED = {ISSUER.key_id: (ISSUER.pub, ISSUER.fingerprint)}


def spec(now, order, principal="p1"):
    return AuthoritySpec(
        authority_id="a1",
        principal_id=principal,
        action_type="return",
        resource_id="#W1",
        authorized_amount_ceiling=50.0,
        authorized_destinations=["pm_orig"],
        authorized_payment_identity="pm_orig",
        authorized_mutation_set=["none"],
        issued_at=now,
        expires_at=now + 100,
        nonce="n0",
        one_shot=True,
        resource_version_hash=sha256_hex(order),
        evidence_hash="e1",
    )


def req(principal="p1", **kw):
    base = dict(
        principal_id=principal, actor_id="agent.1", action_type="return",
        resource_id="#W1", amount=50.0, destination="pm_orig",
        payment_identity="pm_orig", nonce="n1", authority_id="a1",
    )
    base.update(kw)
    return ExecutionRequest(**base)


def main():
    order = {"order_id": "#W1", "user_id": "p1", "status": "delivered", "items": []}
    clock = Clock(10.0)
    fails = []
    ex = Executor(TRUSTED)
    st = ResourceStore({"#W1": order})
    rec = ex.execute(run_id="u", corpus="unit", commit=None, spec=spec(10, order), req=req(), store=st, clock=clock)
    if rec.executed:
        fails.append("bypass")
    g = CommitGuard(clock, ISSUER)
    out = g.commit(spec(10, order), req(principal="other"), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("principal_allowed")
    s = spec(10, order)
    s.expires_at = 1.0
    out = CommitGuard(clock, ISSUER).commit(s, req(), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("expired_allowed")
    out = CommitGuard(clock, ISSUER).commit(spec(10, order), req(amount=float("nan")), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("nan_allowed")
    # forged
    r = req(amount=99.0, destination="pm_forged")
    body = dict(
        commit_id="x", gate_version=GATE_VERSION, decision="ALLOW", reason="IN_SPEC",
        authority_hash=spec(10, order).hash(), request_hash=r.hash(),
        pre_state_hash=st.version_hash("#W1"), principal_id=r.principal_id,
        actor_id=r.actor_id, action_type=r.action_type, resource_id=r.resource_id,
        amount=r.amount, destination=r.destination, payment_identity=r.payment_identity,
        nonce=r.nonce, committed_at=10.0, issuer_key_id=ISSUER.key_id, signature="",
        commit_hash="00",
    )
    body["commit_hash"] = sha256_hex({k: body[k] for k in body if k != "signature"})
    rec = ex.execute(run_id="u", corpus="unit", commit=ValidatedCommit(**body), spec=spec(10, order), req=r, store=st, clock=clock)
    if rec.executed:
        fails.append("forged_executed")
    print("UNIT_FAILS", fails)
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
