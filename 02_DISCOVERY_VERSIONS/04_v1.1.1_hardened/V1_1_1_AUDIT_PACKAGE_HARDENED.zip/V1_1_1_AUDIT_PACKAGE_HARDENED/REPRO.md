CPython 3.12.3 + cryptography (Ed25519).

cd V1_1_1_AUDIT_PACKAGE_HARDENED
python3 tests/test_attacks.py
python3 harness/run_replay.py --corpus both
