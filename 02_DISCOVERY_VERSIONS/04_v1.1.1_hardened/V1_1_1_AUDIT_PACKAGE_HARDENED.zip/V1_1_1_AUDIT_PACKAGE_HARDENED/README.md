# V1.1.1 HARDENED — commit provenance

Claim under test (not a marketing claim):

Executor executes only a ValidatedCommit whose Ed25519 signature verifies under a trusted issuer public key and whose signed payload matches the exact AuthoritySpec + ExecutionRequest + pre-state. SHA-256 commit_hash is integrity metadata only, not authority.

This proves commit authenticity against agent-controlled requests and forged tokens when the signing key remains inside the trusted signing boundary. It does not prove safety after private-key compromise or arbitrary compromise of the trusted signer.

V1.1 tree was copied, then modified here only. Frozen V1.1 package bytes were not edited.
