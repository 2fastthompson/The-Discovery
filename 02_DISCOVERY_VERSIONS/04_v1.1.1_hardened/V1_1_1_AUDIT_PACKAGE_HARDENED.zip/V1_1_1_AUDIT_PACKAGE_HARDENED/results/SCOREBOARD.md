# V1.1.1 scoreboard (harness-generated)

## tau1
- spec_coverage 42/115
- valid 42/42
- unauthorized 0/1008
- verifier mismatches 0/1050
- forged_commit n=42 exec=0
- signed_commit_missing_spec n=42 exec=0

## tau3
- spec_coverage 43/114
- valid 43/43
- unauthorized 0/1032
- verifier mismatches 0/1075
- forged_commit n=43 exec=0
- signed_commit_missing_spec n=43 exec=0
