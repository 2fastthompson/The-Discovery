from __future__ import annotations
from dataclasses import asdict
from hashutil import GATE_VERSION
from store import ResourceStore
from models import AuthoritySpec, ExecutionBoundReceipt, ExecutionRequest, ValidatedCommit
from keys import signed_payload, verify_signature


class Executor:
    identity = "sri-executor-v1.1.1"

    def __init__(self, trusted: dict) -> None:
        # key_id -> (public_key, fingerprint)
        self.trusted = trusted

    def execute(
        self,
        *,
        run_id: str,
        corpus: str,
        commit: ValidatedCommit | None,
        spec: AuthoritySpec | None,
        req: ExecutionRequest,
        store: ResourceStore,
        clock,
        allow_direct: bool = False,
    ) -> ExecutionBoundReceipt:
        executed = False
        post = None
        decision = "DENY"
        reason = "DIRECT_EXECUTOR_BYPASS"
        commit_id = None
        issuer_key_id = None
        commit_signature = None
        fp = None
        pre = store.version_hash(req.resource_id)

        if spec is None:
            decision, reason = "DENY", "MISSING_AUTHORITY_SPEC"
        elif commit is None:
            decision, reason = "DENY", "DIRECT_EXECUTOR_BYPASS"
        elif not getattr(commit, "signature", None):
            decision, reason = "DENY", "UNSIGNED_COMMIT"
        elif commit.issuer_key_id not in self.trusted:
            decision, reason = "DENY", "UNKNOWN_COMMIT_ISSUER"
        elif not verify_signature(self.trusted[commit.issuer_key_id][0], signed_payload(commit), commit.signature):
            decision, reason = "DENY", "INVALID_COMMIT_SIGNATURE"
        elif commit.decision != "ALLOW":
            decision, reason = "DENY", "COMMIT_NOT_ALLOW"
        elif commit.gate_version != GATE_VERSION:
            decision, reason = "DENY", "GATE_VERSION_MISMATCH"
        elif commit.request_hash != req.hash():
            decision, reason = "DENY", "POST_ALLOW_REQUEST_MUTATION"
        elif commit.authority_hash != spec.hash():
            decision, reason = "DENY", "AUTHORITY_HASH_MISMATCH"
        else:
            live = store.version_hash(req.resource_id)
            if live != commit.pre_state_hash:
                decision, reason = "DENY", "STALE_RESOURCE_STATE"
            else:
                decision, reason = "ALLOW", commit.reason
                executed = True
                post = live
                commit_id = commit.commit_id
                issuer_key_id = commit.issuer_key_id
                commit_signature = commit.signature
                fp = self.trusted[commit.issuer_key_id][1]

        rec = ExecutionBoundReceipt(
            receipt_version="sri-exec-receipt-v1.1",
            run_id=run_id,
            corpus=corpus,
            authority_id=None if spec is None else spec.authority_id,
            authority_hash=None if spec is None else spec.hash(),
            principal_id=req.principal_id,
            actor_id=req.actor_id,
            action_type=req.action_type,
            resource_id=req.resource_id,
            authorized_amount_or_ceiling=None if spec is None else spec.authorized_amount_ceiling,
            executed_amount=req.amount if executed else None,
            authorized_destination=None if spec is None else list(spec.authorized_destinations),
            executed_destination=req.destination if executed else None,
            authorized_payment_identity=None if spec is None else spec.authorized_payment_identity,
            executed_payment_identity=req.payment_identity if executed else None,
            nonce=req.nonce,
            request_hash=req.hash(),
            commit_id=commit_id,
            pre_state_hash=pre,
            post_state_hash=post,
            execution_decision=decision,
            decision_reason=reason,
            executed=executed,
            processor_mode="SIMULATED",
            processor_event_id=None,
            reconciled_final_state="N/A" if not executed else "SIMULATED_APPLIED",
            execution_ts=clock.now(),
            issuer_key_id=issuer_key_id,
            commit_signature=commit_signature,
            issuer_pubkey_fingerprint=fp,
        ).seal()
        return rec
