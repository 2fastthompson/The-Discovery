relative_path | sha256 | byte_size | role
---|---|---:|---
docs/RUN_COMMAND.txt | `a1f3d2e144408468b2abf5f4a178b81009c0904d608f8c896d37d102504de406` | 389 | docs
docs/UPSTREAM_SHA.txt | `39f59f643cbe255c451f964d61da6a2f116cce83632f71afe612400cd005a8d8` | 209 | docs
sri_taubench/evidence.py | `3f2392945df0de0ce8afdb32079ffd8805f7477844138d7371def277da0c4b8d` | 9638 | imported by entrypoint
sri_taubench/gate.py | `dc4dcf1a440c9df11ed56a5e75e06f9fed0c3ee19194f2dfdbdd3b01c7776444` | 5794 | imported by evidence/replay
sri_taubench/replay_v1.py | `46391e6cbf59cfb509b17fbf68157ceb03d9e4cff2d44b8baaa22d4227305dce` | 12163 | entrypoint
tau3_retail/data/orders.json | `70d6d5f4d247f9dae046d5a97c947bc79de2d4aff6b51093fb11970fef56ddce` | 965606 | consumed tau3
tau3_retail/data/products.json | `83eb2cf14d9c4ad60ed30d1fa040ec8a16076547b2c74b43f96a60458868f7c5` | 97963 | present in tree; NOT consumed by replay_v1.py
tau3_retail/data/users.json | `6b65fe4ea79f3630dcdcf1314656ecca55a396266ffee3ad5e9cb06e4fa40653` | 237984 | consumed tau3
tau3_retail/policy.md | `2c9652afbce57d6e087768d37cda64d31c53d50b3e3225cfdb791bac66466467` | 6699 | present in tree; NOT consumed by replay_v1.py
tau3_retail/split_tasks.json | `ed0580ec52575b63fbf76568af42490da6ee7783ecb4aa81af46961291358f20` | 3263 | consumed tau3
tau3_retail/tasks.json | `8e03ebce7901bd6218e7a7dc3105faa9324091a68058f7fe61c65262868812e8` | 345982 | consumed tau3
tau_retail/data/orders.json | `2598a12586d28f2d6bd16bc86f4c800029b6af18e0abb5c475ef5c869c11ced1` | 1810945 | consumed tau1
tau_retail/data/products.json | `a9eabcc1a9742c5f5288c2779acce52b9308423383ed24706bbaf0889f762a0f` | 172258 | present in tree; NOT consumed by replay_v1.py
tau_retail/data/users.json | `6f4fd104cc5e80b92166c4035315c31532c6cea52a90dcdf18425ee7f87c2b82` | 322932 | consumed tau1
tau_retail/tasks.py | `11f2da9e3f05998736f95cf4e9943724603d95a6929d7f95024d7b000afa8bc5` | 178995 | present in tree; NOT consumed by replay_v1.py
tau_retail/tasks_test.py | `6f09468923c6cfb6162e94fe659264d6aee70816c18d51278fb4a581db7765a4` | 169476 | consumed tau1
tau_retail/wiki.md | `d539fd2a46a8b8dd2e934ff9ed92f43e9f6b56bc7a718db8d2803ba8ad8f6bf7` | 5718 | present in tree; NOT consumed by replay_v1.py
unchanged_v1_run.log | `cf0425755d7bfd76c53008cdf8bac678c03602e825e5159d1a5a200189dbcf73` | 1939 | raw baseline stdout/stderr; not rewritten
