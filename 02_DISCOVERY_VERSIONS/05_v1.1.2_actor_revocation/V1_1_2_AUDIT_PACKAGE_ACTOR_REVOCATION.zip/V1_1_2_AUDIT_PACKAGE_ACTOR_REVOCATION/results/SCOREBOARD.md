# V1.1.2 scoreboard (harness-generated)

## tau1
- spec 42/115
- valid 42/42
- unauthorized 0/1386
- verifier 0/1470
- actor_mismatch exec=0 n=42
- cross_agent_commit_reuse exec=0
- revoked_before_commit exec=0
- revoked_after_commit_before_execute exec=0

## tau3
- spec 43/114
- valid 43/43
- unauthorized 0/1419
- verifier 0/1505
- actor_mismatch exec=0 n=43
- cross_agent_commit_reuse exec=0
- revoked_before_commit exec=0
- revoked_after_commit_before_execute exec=0
