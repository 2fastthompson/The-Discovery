# V1.1.2 — actor binding and revocation

Claim under test: an ExecutionRequest executes only if actor_id is the actor bound on AuthoritySpec, the Ed25519 commit binds that actor, and the trusted revocation registry still shows ACTIVE at Executor time. Revocation invalidates previously issued unexecuted commits.

principal_id and actor_id are distinct roles. Neither equality nor inequality is required.

Lineage: copied from PASSed V1.1.1 then modified only in this tree. Frozen V1 / V1.1 / V1.1.1 packages were not edited.
