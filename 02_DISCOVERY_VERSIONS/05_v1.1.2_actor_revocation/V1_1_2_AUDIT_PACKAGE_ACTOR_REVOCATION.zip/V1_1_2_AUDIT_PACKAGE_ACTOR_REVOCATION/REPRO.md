cd V1_1_2_AUDIT_PACKAGE_ACTOR_REVOCATION
python3 tests/test_attacks.py
python3 harness/run_replay.py --corpus both
CPython 3.12.3 + cryptography Ed25519
