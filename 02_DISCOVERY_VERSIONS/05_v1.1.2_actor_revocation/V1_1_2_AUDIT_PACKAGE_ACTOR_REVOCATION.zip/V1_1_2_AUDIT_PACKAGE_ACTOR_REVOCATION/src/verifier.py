"""Independent verifier. Recomputes receipt hash and Ed25519 commit signature."""
from __future__ import annotations
import math
from hashutil import GATE_VERSION, sha256_hex
from keys import public_from_hex, signed_payload, verify_signature


def _rehash_receipt(rec: dict) -> str:
    body = dict(rec)
    body["receipt_hash"] = ""
    return sha256_hex(body)


def _finite_amount(v) -> bool:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return False
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return False
    return True


def verify_receipt(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    mismatches = []
    if rec.get("receipt_hash") != _rehash_receipt(rec):
        mismatches.append("receipt_hash")
    if rec.get("processor_mode") != "SIMULATED":
        mismatches.append("processor_mode")
    if rec.get("processor_event_id") not in (None, "ABSENT"):
        mismatches.append("fabricated_processor_event")
    req_hash = sha256_hex(req)
    if rec.get("request_hash") != req_hash:
        mismatches.append("request_hash")
    if spec is not None:
        spec_pub = {k: spec[k] for k in spec if k != "consumed"}
        if rec.get("authority_hash") != sha256_hex(spec_pub):
            mismatches.append("authority_hash")
    if rec.get("executed") is True:
        if spec is None:
            mismatches.append("executed_without_spec")
        if rec.get("execution_decision") != "ALLOW":
            mismatches.append("executed_without_allow")
        if commit is None:
            mismatches.append("executed_without_commit")
        else:
            kid = commit.get("issuer_key_id")
            if kid not in trusted_pubs:
                mismatches.append("unknown_issuer")
            else:
                pub_hex, fp = trusted_pubs[kid]
                pub = public_from_hex(pub_hex)
                if not commit.get("signature"):
                    mismatches.append("unsigned_commit")
                elif not verify_signature(pub, signed_payload(commit), commit["signature"]):
                    mismatches.append("invalid_signature")
                if rec.get("issuer_pubkey_fingerprint") != fp:
                    mismatches.append("fingerprint")
            if commit.get("decision") != "ALLOW":
                mismatches.append("commit_not_allow")
            if commit.get("gate_version") != GATE_VERSION:
                mismatches.append("gate_version")
            if commit.get("request_hash") != req_hash:
                mismatches.append("commit_request_hash")
        if rec.get("executed_amount") is not None and not _finite_amount(rec["executed_amount"]):
            mismatches.append("nonfinite_executed_amount")
    if rec.get("execution_decision") == "ALLOW" and rec.get("executed") is not True:
        mismatches.append("allow_not_executed")
    return {"ok": len(mismatches) == 0, "mismatches": mismatches, "receipt_hash": rec.get("receipt_hash")}
