"""Ed25519 commit issuer keys.

TEST-ONLY fixture may be loaded from fixtures/test_ed25519.json.
Production/runtime must inject key material; this module does not mint production keys.
Private-key compromise is outside this proof.
"""
from __future__ import annotations
import json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from hashutil import sha256_hex

SIGNED_FIELDS = (
    "commit_id",
    "gate_version",
    "decision",
    "reason",
    "authority_hash",
    "request_hash",
    "pre_state_hash",
    "principal_id",
    "actor_id",
    "action_type",
    "resource_id",
    "amount",
    "destination",
    "payment_identity",
    "nonce",
    "committed_at",
    "revocation_version",
)


def signed_payload(obj) -> bytes:
    if isinstance(obj, dict):
        d = obj
    else:
        d = {k: getattr(obj, k) for k in SIGNED_FIELDS}
    # canonical JSON of signed fields only
    from hashutil import canonical_json
    body = {k: d[k] for k in SIGNED_FIELDS}
    return canonical_json(body).encode("utf-8")


class Issuer:
    def __init__(self, key_id: str, priv: Ed25519PrivateKey, pub: Ed25519PublicKey):
        self.key_id = key_id
        self._priv = priv
        self.pub = pub
        raw_pub = pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        self.fingerprint = sha256_hex(raw_pub)

    def sign(self, payload: bytes) -> str:
        return self._priv.sign(payload).hex()


def verify_signature(pub: Ed25519PublicKey, payload: bytes, sig_hex: str) -> bool:
    try:
        pub.verify(bytes.fromhex(sig_hex), payload)
        return True
    except Exception:
        return False


def load_test_issuer(path: Path) -> Issuer:
    data = json.loads(path.read_text())
    priv = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(data["private_key_hex"]))
    pub = priv.public_key()
    return Issuer(data["key_id"], priv, pub)


def public_from_hex(hexkey: str) -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(bytes.fromhex(hexkey))
