# V1.1.3 scoreboard (harness-generated)

simulated_acceptance only; external_execution=false; external_reconciliation=N/A

## tau1
- spec 42/115
- valid 42/42
- unauthorized 0/1512
- verifier 0/1638
- same_commit_replay exec=0 n=42
- same_commit_after_restart exec=0
- expired_at_execution exec=0

## tau3
- spec 43/114
- valid 43/43
- unauthorized 0/1548
- verifier 0/1677
- same_commit_replay exec=0 n=43
- same_commit_after_restart exec=0
- expired_at_execution exec=0
