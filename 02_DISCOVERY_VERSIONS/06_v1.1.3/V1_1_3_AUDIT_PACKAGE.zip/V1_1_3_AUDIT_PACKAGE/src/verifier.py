"""Independent verifier. Reconstructs expected outcome from spec/req/commit.

Does not trust rec.executed after a rehash. Does not call Executor.execute.
"""
from __future__ import annotations
import math
from hashutil import GATE_VERSION, sha256_hex
from keys import public_from_hex, signed_payload, verify_signature


def _rehash_receipt(rec: dict) -> str:
    body = dict(rec)
    body["receipt_hash"] = ""
    return sha256_hex(body)


def _finite_amount(v) -> bool:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return False
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return False
    return True


def reconstruct_expected(spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict, rec: dict, prior_executed_ids: set | None = None) -> dict:
    """Derive whether execution was authorized. Ignores rec.executed / rec.execution_decision."""
    if spec is None or commit is None:
        return {"expected_executed": False, "expected_decision": "DENY", "why": "missing_spec_or_commit"}
    if prior_executed_ids and commit.get("commit_id") in prior_executed_ids:
        return {"expected_executed": False, "expected_decision": "DENY", "why": "commit_already_executed"}
    if not commit.get("signature"):
        return {"expected_executed": False, "expected_decision": "DENY", "why": "unsigned"}
    kid = commit.get("issuer_key_id")
    if kid not in trusted_pubs:
        return {"expected_executed": False, "expected_decision": "DENY", "why": "unknown_issuer"}
    pub_hex, fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), signed_payload(commit), commit["signature"]):
        return {"expected_executed": False, "expected_decision": "DENY", "why": "bad_sig"}
    if commit.get("decision") != "ALLOW" or commit.get("gate_version") != GATE_VERSION:
        return {"expected_executed": False, "expected_decision": "DENY", "why": "commit_not_allow"}
    if commit.get("request_hash") != sha256_hex(req):
        return {"expected_executed": False, "expected_decision": "DENY", "why": "request_mismatch"}
    spec_pub = {k: spec[k] for k in spec if k != "consumed"}
    if commit.get("authority_hash") != sha256_hex(spec_pub):
        return {"expected_executed": False, "expected_decision": "DENY", "why": "authority_mismatch"}
    if req.get("actor_id") != spec.get("authorized_actor_id") or commit.get("actor_id") != spec.get("authorized_actor_id"):
        return {"expected_executed": False, "expected_decision": "DENY", "why": "actor"}
    if rec.get("revocation_status_at_exec") != "ACTIVE":
        return {"expected_executed": False, "expected_decision": "DENY", "why": "revoked"}
    if rec.get("revocation_version_at_exec") != spec.get("revocation_version"):
        return {"expected_executed": False, "expected_decision": "DENY", "why": "stale_rev"}
    exp = spec.get("expires_at")
    ts = rec.get("execution_ts")
    if exp is not None and ts is not None and ts > exp:
        return {"expected_executed": False, "expected_decision": "DENY", "why": "expired_at_execution"}
    return {
        "expected_executed": True,
        "expected_decision": "ALLOW",
        "why": "in_spec",
        "expected_amount": commit.get("amount"),
        "expected_destination": commit.get("destination"),
        "expected_fp": fp,
    }


def verify_receipt(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict, prior_executed_ids: set | None = None) -> dict:
    mismatches = []
    if rec.get("receipt_hash") != _rehash_receipt(rec):
        mismatches.append("receipt_hash")
    if rec.get("processor_mode") != "SIMULATED":
        mismatches.append("processor_mode")
    if rec.get("processor_event_id") not in (None, "ABSENT"):
        mismatches.append("fabricated_processor_event")
    if rec.get("external_execution") is True:
        mismatches.append("claimed_external_execution")
    if rec.get("external_reconciliation") not in ("N/A", None):
        mismatches.append("claimed_external_reconciliation")

    expected = reconstruct_expected(spec, req, commit, trusted_pubs, rec, prior_executed_ids)
    if rec.get("executed") is not expected["expected_executed"]:
        mismatches.append("executed_vs_reconstructed")
    if expected["expected_executed"]:
        if rec.get("execution_decision") != "ALLOW":
            mismatches.append("decision_vs_reconstructed")
        if rec.get("executed_amount") != expected.get("expected_amount"):
            mismatches.append("amount_vs_commit")
        if rec.get("executed_destination") != expected.get("expected_destination"):
            mismatches.append("destination_vs_commit")
        if rec.get("simulated_acceptance") is not True:
            mismatches.append("simulated_acceptance")
        if rec.get("issuer_pubkey_fingerprint") != expected.get("expected_fp"):
            mismatches.append("fingerprint")
        if rec.get("executed_amount") is not None and not _finite_amount(rec["executed_amount"]):
            mismatches.append("nonfinite_executed_amount")
    else:
        if rec.get("executed") is True:
            mismatches.append("executed_when_reconstructed_deny")
        if rec.get("execution_decision") == "ALLOW" and rec.get("executed") is True:
            mismatches.append("allow_executed_when_reconstructed_deny")

    return {
        "ok": len(mismatches) == 0,
        "mismatches": mismatches,
        "receipt_hash": rec.get("receipt_hash"),
        "reconstructed": expected,
    }
