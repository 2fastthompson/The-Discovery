"""Durable execution ledger. Consumes commit_id at execute time. Survives restart via JSON file."""
from __future__ import annotations
import json
from pathlib import Path


class ExecutionLedger:
    def __init__(self, path: Path | None = None) -> None:
        self.path = path
        self._consumed: set[str] = set()
        if path and path.exists():
            data = json.loads(path.read_text())
            self._consumed = set(data.get("consumed_commit_ids") or [])

    def contains(self, commit_id: str | None) -> bool:
        return bool(commit_id) and commit_id in self._consumed

    def record(self, commit_id: str) -> None:
        self._consumed.add(commit_id)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps({"consumed_commit_ids": sorted(self._consumed)}, indent=2))

    def snapshot(self) -> list[str]:
        return sorted(self._consumed)
