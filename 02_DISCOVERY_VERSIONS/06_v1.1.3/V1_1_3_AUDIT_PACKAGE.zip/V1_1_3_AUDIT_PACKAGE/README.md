# V1.1.3 candidate — commit consume / expiry / receipt reconstruction

Fixes vs independently audited V1.1.2:
1. Same signed commit cannot execute twice; durable ledger survives restart.
2. Executor checks spec.expires_at at execution time.
3. Verifier reconstructs expected outcome from spec/req/commit; resealing altered executed fields fails.
4. Execute applies signed commit fields; revocation and request-hash checked at execute; COMMIT is reservation, EXECUTE consumes commit_id.
5. Replay first-leg must execute before replay is scored.

simulated_acceptance is not external_execution. external_reconciliation remains N/A.

Lineage: copied V1.1.2 then modified only here. Frozen V1–V1.1.2 unchanged.
