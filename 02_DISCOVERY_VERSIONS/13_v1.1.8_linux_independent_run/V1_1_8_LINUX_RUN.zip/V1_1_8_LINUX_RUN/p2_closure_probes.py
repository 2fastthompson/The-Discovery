#!/usr/bin/env python3
"""Sidecar probes. Does not modify candidate source."""
from __future__ import annotations
import copy
import json
import sys
from dataclasses import asdict
from pathlib import Path

PKG = Path(__file__).resolve().parent / "package"
sys.path.insert(0, str(PKG / "src"))
sys.path.insert(0, str(PKG / "tests"))

from clock import Clock
from coordinator import AcceptanceCoordinator
from executor import Executor
from factory import build_runtime
from gate import CommitGuard
from hashutil import sha256_hex
from keys import load_test_issuer
from ledger import ExecutionLedger
from models import AuthoritySpec, ExecutionRequest
from revoke import RevocationRegistry
from store import ResourceStore
from verifier import verify_receipt
from cryptography.hazmat.primitives import serialization

ROOT = PKG
ISSUER = load_test_issuer(ROOT / "fixtures" / "test_ed25519.json")
TRUSTED = {ISSUER.key_id: (ISSUER.pub, ISSUER.fingerprint)}
PUBS = {ISSUER.key_id: (
    ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
    ISSUER.fingerprint,
)}


def spec(now, order, principal="p1"):
    return AuthoritySpec(
        authority_id="a1",
        principal_id=principal,
        authorized_actor_id="agent.1",
        revocation_version=1,
        action_type="return",
        resource_id="#W1",
        authorized_amount_ceiling=50.0,
        authorized_destinations=["pm_orig"],
        authorized_payment_identity="pm_orig",
        authorized_mutation_set=["none"],
        issued_at=now,
        expires_at=now + 100,
        nonce="n0",
        one_shot=True,
        resource_version_hash=sha256_hex(order),
        evidence_hash="e1",
    )


def req(**kw):
    base = dict(
        principal_id="p1", actor_id="agent.1", action_type="return",
        resource_id="#W1", amount=50.0, destination="pm_orig",
        payment_identity="pm_orig", nonce="n1", authority_id="a1",
    )
    base.update(kw)
    return ExecutionRequest(**base)


def rehash(rd):
    out = copy.deepcopy(rd)
    out["receipt_hash"] = ""
    out["receipt_hash"] = sha256_hex(out)
    return out


def main():
    report = {"p2_1": [], "p2_2": [], "ok": True}
    order = {"order_id": "#W1", "user_id": "p1", "status": "delivered", "items": []}
    clock = Clock(10.0)
    rt = build_runtime(trusted=TRUSTED, issuer=ISSUER, orders={"#W1": order})
    ex, reg, st, led = rt["executor"], rt["registry"], rt["store"], rt["ledger"]
    reg.register("a1", 1)

    # authentic no-commit denial
    rec = ex.execute(run_id="p", corpus="p", commit=None, spec=None, req=req(), store=st, clock=clock)
    rd = asdict(rec)
    v0 = verify_receipt(rd, None, asdict(req()), None, PUBS)
    report["p2_1"].append({"authentic_absent_ok": v0["ok"], "reason": rec.decision_reason, "executed": rec.executed})

    fabricated = [
        "authority_id", "authorized_amount_or_ceiling", "authorized_destination",
        "authorized_payment_identity", "spec_expires_at", "commit_signature",
        "issuer_key_id", "executed_destination", "executed_payment_identity",
    ]
    for field in fabricated:
        mut = rehash({**rd, field: "FABRICATED" if field != "authorized_amount_or_ceiling" else 99.0})
        vv = verify_receipt(mut, None, asdict(req()), None, PUBS)
        report["p2_1"].append({field: vv["ok"], "mismatches": vv.get("mismatches")})
        if vv["ok"]:
            report["ok"] = False

    # P2-2 wiring
    s = spec(10, order)
    r = req(nonce="n-coord")
    c = CommitGuard(clock, ISSUER).commit(s, r, st.version_hash("#W1"))
    assert not isinstance(c, tuple), c

    def try_exec(exx, stt, tag):
        recx = exx.execute(run_id="p", corpus="p", commit=c, spec=s, req=r, store=stt, clock=clock)
        return recx.executed, recx.decision_reason

    coord = AcceptanceCoordinator()
    configs = []
    # missing on each
    configs.append(("ex_none", Executor(TRUSTED, RevocationRegistry(coord), ExecutionLedger(), ISSUER, None), ResourceStore({"#W1": order}, coord)))
    configs.append(("reg_none", Executor(TRUSTED, RevocationRegistry(None), ExecutionLedger(), ISSUER, coord), ResourceStore({"#W1": order}, coord)))
    configs.append(("store_none", Executor(TRUSTED, RevocationRegistry(coord), ExecutionLedger(), ISSUER, coord), ResourceStore({"#W1": order}, None)))
    # mismatched
    c2 = AcceptanceCoordinator()
    configs.append(("ex_mismatch", Executor(TRUSTED, RevocationRegistry(coord), ExecutionLedger(), ISSUER, c2), ResourceStore({"#W1": order}, coord)))
    configs.append(("reg_mismatch", Executor(TRUSTED, RevocationRegistry(c2), ExecutionLedger(), ISSUER, coord), ResourceStore({"#W1": order}, coord)))
    configs.append(("store_mismatch", Executor(TRUSTED, RevocationRegistry(coord), ExecutionLedger(), ISSUER, coord), ResourceStore({"#W1": order}, c2)))

    for tag, exx, stt in configs:
        executed, reason = try_exec(exx, stt, tag)
        report["p2_2"].append({"config": tag, "executed": executed, "reason": reason})
        if executed:
            report["ok"] = False
        # repair: factory path new ledger so commit not consumed
        rt2 = build_runtime(trusted=TRUSTED, issuer=ISSUER, orders={"#W1": order})
        rt2["registry"].register("a1", 1)
        rec_ok = rt2["executor"].execute(run_id="p", corpus="p", commit=c, spec=s, req=r, store=rt2["store"], clock=clock)
        rec_rep = rt2["executor"].execute(run_id="p", corpus="p", commit=c, spec=s, req=r, store=rt2["store"], clock=clock)
        report["p2_2"].append({"config": tag + "_repaired", "executed": rec_ok.executed, "replay_executed": rec_rep.executed, "replay_reason": rec_rep.decision_reason})
        if not rec_ok.executed or rec_rep.executed:
            report["ok"] = False

    out = Path(__file__).resolve().parent / "p2_closure_probes.json"
    out.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2)[:4000])
    print("P2_OK" if report["ok"] else "P2_FAIL")
    return 0 if report["ok"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
