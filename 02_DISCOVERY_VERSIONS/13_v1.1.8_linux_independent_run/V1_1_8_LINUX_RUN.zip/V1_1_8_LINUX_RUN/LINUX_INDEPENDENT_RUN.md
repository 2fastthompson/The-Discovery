# V1.1.8 independent Linux execution (reviewer, not builder)

Candidate ZIP SHA-256: 4a9729ac92fa0542a41f4c528c9820d3e873cb96a51321ee0c62e837e95408a4
Evidence ZIP SHA-256: b83cf4d1c45852d26321c0e33e49e8713b5cca0e818e41d971c9e5b3f6ecdf29

Runtime: Linux 6.12.8+ x86_64, CPython 3.12.3, cryptography present.
Candidate source was not modified. All packaged .py files match the ZIP byte-for-byte after the run.

## Commands and exit codes
python3 tests/test_attacks.py          UNIT_FAILS []    exit 0
python3 harness/run_replay.py --corpus both            exit 0
python3 ../p2_closure_probes.py        P2_OK            exit 0

## Fresh corpus totals (this run)
tau1 spec 42/115 valid 42/42 unauthorized 0/1512 verifier 0/1638
tau3 spec 43/114 valid 43/43 unauthorized 0/1548 verifier 0/1677

Fresh results/{scoreboard,cases,receipts}.json(l) are byte-identical to the files inside the candidate ZIP.

## P2-1 absent-object fabricated summaries
9/9 rejected. Authentic absent-object denial verified (MISSING_AUTHORITY_SPEC, executed=false).

## P2-2 coordinator
6 missing/mismatched wirings denied (MISSING_COORDINATOR or MISMATCHED_COORDINATOR).
Same commit after factory repair executed once in all 6; replay denied COMMIT_ALREADY_EXECUTED.

## Claim boundary
Simulated acceptance only. No live rails, settlement, power-loss, distributed coordination, or upstream corpus SHA recovery. No canonical PASS. No vault promotion.
