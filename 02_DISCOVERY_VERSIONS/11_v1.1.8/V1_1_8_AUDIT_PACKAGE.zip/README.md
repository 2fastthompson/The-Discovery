# V1.1.8 candidate

Built by Claude directly on top of the independently-audited V1.1.7 candidate, applying exactly
the two bounded fixes requested after the V1.1.7 audit. No other behavior changed.

## Fix 1 — absent-object denial receipts now reject fabricated summary fields

Denial receipts: executed_amount/destination/payment_identity must be null; reconciled_final_state
N/A; commit_signature and issuer_key_id bound whenever a commit is supplied (unchanged from V1.1.7).

New in V1.1.8: when `spec` is absent, `authority_id`, `authorized_amount_or_ceiling`,
`authorized_destination`, `authorized_payment_identity`, and `spec_expires_at` are now required to
be null — the verifier rejects the receipt otherwise. When `commit` is absent, `commit_signature`,
`issuer_key_id`, and the receipt's `commit_id` are now required to be null, and the signed
execution event's own `commit_id`/`commit_envelope_hash` are also required null (consistent
absent-commit semantics, closing the V1.1.7 finding that these fields were fabricable on a genuine
denial without failing verification). See `src/verifier.py`, `execution_evidence_valid()`.

## Fix 2 — shared coordination mandatory at the execution boundary

`factory.build_runtime`/`require_coordinated` (unchanged) remain available as an integration
precondition. New in V1.1.8: `Executor.execute()` itself now refuses to proceed past the
revocation/ledger presence checks if `self.coordinator` is None, or if the registry's or the
store's `coordinator` is not the identical shared instance — DENY `MISSING_COORDINATOR` or DENY
`MISMATCHED_COORDINATOR`, respectively. This check runs strictly before any ledger interaction
(`coordinator.accept`/`ledger.try_consume`), so a rejected commit is never consumed and remains
available for a subsequent, correctly-coordinated execution attempt. The previous uncoordinated
fallback branch inside `execute()` (`else: self.ledger.try_consume(...)` when
`self.coordinator is None`) no longer exists — coordination is enforced inline, not opt-in.
See `src/executor.py`, `Executor.execute()`.

## Regression tests

`tests/test_attacks.py` extends the existing script-style regression suite (kept in the same style
as V1.1.7, no new test framework introduced) with:
- genuine missing-commit and missing-spec-and-commit denials, confirming the authentic denial still
  verifies, then confirming each of the nine previously-accepted fabrications is now rejected;
- missing-coordinator and mismatched-coordinator rejection, confirming `executed=False` and the
  correct new decision_reason for each;
- direct proof that both rejected wiring attempts leave the commit unconsumed: the identical
  commit is then run through a correctly coordinated executor and successfully executes, and a
  second attempt after that correctly fails as an ordinary replay (`COMMIT_ALREADY_EXECUTED`) —
  which also confirms the first successful execution really did consume it, so the two prior
  rejections are shown to have left it genuinely untouched rather than the ledger silently
  ignoring duplicates for an unrelated reason.

Everything else — types, required-key/extra-key rejection, the table-driven allow+deny mutation
matrix in `tests/test_receipt_matrix.py`, all V1.1–V1.1.7 attack classes in
`harness/run_replay.py` — is unchanged from V1.1.7.

No canonical PASS. No vault promotion. This package was built by Claude (not audited by Claude);
it has not been independently reviewed by anyone else and should not be treated as equivalent to
the independently-audited V1.1.7 candidate until it is.
