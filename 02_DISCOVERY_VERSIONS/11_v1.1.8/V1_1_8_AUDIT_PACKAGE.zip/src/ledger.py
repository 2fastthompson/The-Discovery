"""TEST-ONLY uniqueness store.

Supported: path + fcntl, or pathless in-process threading.Lock.
Unsupported path+no-fcntl raises. Corrupt existing state fails closed.
Lock file is separate and never replaced.
"""
from __future__ import annotations
import json
import threading
from pathlib import Path

try:
    import fcntl
except ImportError:
    fcntl = None


class LedgerStorageError(Exception):
    pass


class UnsupportedLedgerPlatform(Exception):
    pass


def _validate_payload(data) -> set[str]:
    if not isinstance(data, dict):
        raise LedgerStorageError("ledger payload is not an object")
    if "consumed_commit_ids" not in data:
        raise LedgerStorageError("missing consumed_commit_ids")
    ids = data["consumed_commit_ids"]
    if not isinstance(ids, list) or any(not isinstance(x, str) or not x for x in ids):
        raise LedgerStorageError("consumed_commit_ids schema invalid")
    return set(ids)


class ExecutionLedger:
    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path else None
        self._consumed: set[str] = set()
        self._mem_lock = threading.Lock()
        if self.path is not None and fcntl is None:
            raise UnsupportedLedgerPlatform("path-backed ledger requires fcntl")
        if self.path and self.path.exists():
            self._reload_unlocked()

    @property
    def lock_path(self) -> Path | None:
        if not self.path:
            return None
        return self.path.with_name(self.path.name + ".lock")

    def _reload_unlocked(self) -> None:
        if not self.path:
            return
        if not self.path.exists():
            self._consumed = set()
            return
        try:
            raw = self.path.read_text()
        except OSError as e:
            raise LedgerStorageError(str(e)) from e
        if not raw.strip():
            raise LedgerStorageError("existing ledger file is empty")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            raise LedgerStorageError(f"malformed ledger JSON: {e}") from e
        self._consumed = _validate_payload(data)

    def _persist_unlocked(self) -> None:
        if not self.path:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_name(self.path.name + ".tmp")
            tmp.write_text(json.dumps({"consumed_commit_ids": sorted(self._consumed)}, indent=2))
            tmp.replace(self.path)
        except OSError as e:
            raise LedgerStorageError(str(e)) from e

    def _locked(self, fn):
        if self.path is None:
            with self._mem_lock:
                return fn()
        lp = self.lock_path
        lp.parent.mkdir(parents=True, exist_ok=True)
        lp.touch(exist_ok=True)
        with lp.open("r+") as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            try:
                return fn()
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    def contains(self, commit_id: str | None) -> bool:
        if not commit_id:
            return False
        def _op():
            self._reload_unlocked()
            return commit_id in self._consumed
        return self._locked(_op)

    def try_consume(self, commit_id: str, predicate=None) -> tuple[bool, str]:
        """Linearization point. predicate() runs under the same lock after reload.

        Returns (won, reason). Persists before returning a win.
        """
        def _op():
            self._reload_unlocked()
            if commit_id in self._consumed:
                return False, "COMMIT_ALREADY_EXECUTED"
            if predicate is not None:
                ok, reason = predicate()
                if not ok:
                    return False, reason
            self._consumed.add(commit_id)
            self._persist_unlocked()
            return True, "ALLOW"

        return self._locked(_op)

    def snapshot(self) -> list[str]:
        def _op():
            self._reload_unlocked()
            return sorted(self._consumed)
        return self._locked(_op)
