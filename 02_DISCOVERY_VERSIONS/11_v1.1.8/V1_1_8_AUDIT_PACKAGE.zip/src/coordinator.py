"""In-process acceptance coordinator.

Lock order: coordinator.lock, then ledger lock (if any).
All registry and resource writers MUST take coordinator.lock.
Acceptance linearization instant: successful try_consume persist returning True.
"""
from __future__ import annotations
import threading


class AcceptanceCoordinator:
    def __init__(self) -> None:
        self.lock = threading.RLock()

    def accept(self, ledger, commit_id: str, predicate):
        with self.lock:
            return ledger.try_consume(commit_id, predicate)
