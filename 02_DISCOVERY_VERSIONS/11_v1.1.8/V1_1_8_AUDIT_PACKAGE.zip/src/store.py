from __future__ import annotations
from copy import deepcopy
from hashutil import sha256_hex
import threading


class ResourceStore:
    def __init__(self, orders: dict, coordinator=None) -> None:
        self._orders = dict(orders)
        self.coordinator = coordinator
        self._local = threading.RLock()

    def _lock(self):
        return self.coordinator.lock if self.coordinator is not None else self._local

    def get(self, resource_id: str) -> dict | None:
        with self._lock():
            o = self._orders.get(resource_id)
            return deepcopy(o) if o else None

    def version_hash(self, resource_id: str) -> str | None:
        with self._lock():
            o = self._orders.get(resource_id)
            if o is None:
                return None
            return sha256_hex(o)

    def mutate_status(self, resource_id: str, status: str) -> None:
        with self._lock():
            if resource_id in self._orders:
                rec = deepcopy(self._orders[resource_id])
                rec["status"] = status
                self._orders[resource_id] = rec
