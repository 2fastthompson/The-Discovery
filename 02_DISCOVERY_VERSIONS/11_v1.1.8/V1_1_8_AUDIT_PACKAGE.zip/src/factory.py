"""Wire one coordinator into executor, registry, store, ledger. Reject incomplete wiring."""
from __future__ import annotations
from coordinator import AcceptanceCoordinator
from executor import Executor
from ledger import ExecutionLedger
from revoke import RevocationRegistry
from store import ResourceStore


class WiringError(Exception):
    pass


def build_runtime(*, trusted, issuer, orders, ledger_path=None, clock=None):
    coord = AcceptanceCoordinator()
    registry = RevocationRegistry(coord)
    store = ResourceStore(orders, coord)
    ledger = ExecutionLedger(ledger_path)
    ex = Executor(trusted, registry, ledger, issuer, coord)
    if ex.coordinator is None or registry.coordinator is None or store.coordinator is None:
        raise WiringError("coordinator missing after factory build")
    if ex.coordinator is not registry.coordinator or ex.coordinator is not store.coordinator:
        raise WiringError("mismatched coordinators")
    return {"coordinator": coord, "registry": registry, "store": store, "ledger": ledger, "executor": ex}


def require_coordinated(executor, registry, store) -> None:
    if executor.coordinator is None or registry.coordinator is None or store.coordinator is None:
        raise WiringError("coordinated semantics require a shared coordinator")
    if not (executor.coordinator is registry.coordinator is store.coordinator):
        raise WiringError("executor/registry/store coordinators differ")
