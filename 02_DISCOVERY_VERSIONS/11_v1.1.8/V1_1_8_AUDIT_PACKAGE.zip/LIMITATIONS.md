- Simulated acceptance only. external_execution=false. external_reconciliation=N/A.
- In-process coordinator. Path-backed ledger requires fcntl.
- No fsync/power-loss or live-rail claim.
- PROVENANCE BREAK — UPSTREAM SHA UNRECOVERABLE.
- Coordination is now mandatory in-process (V1.1.8, Fix 2); this does not extend to multi-process
  or cross-host coordination, and no distributed-coordination or live-rail claim is made.
- Built by Claude, not independently audited by Claude or anyone else. No canonical PASS.
