#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from clock import Clock
from executor import Executor
from gate import CommitGuard
from models import AuthoritySpec, ExecutionRequest, ValidatedCommit
from store import ResourceStore
from hashutil import sha256_hex, GATE_VERSION
from keys import load_test_issuer
from revoke import RevocationRegistry
from ledger import ExecutionLedger
from coordinator import AcceptanceCoordinator
from verifier import verify_receipt
from dataclasses import asdict
from cryptography.hazmat.primitives import serialization

ROOT = Path(__file__).resolve().parents[1]
ISSUER = load_test_issuer(ROOT / "fixtures" / "test_ed25519.json")
TRUSTED = {ISSUER.key_id: (ISSUER.pub, ISSUER.fingerprint)}


def spec(now, order, principal="p1"):
    return AuthoritySpec(
        authority_id="a1",
        principal_id=principal,
        authorized_actor_id="agent.1",
        revocation_version=1,
        action_type="return",
        resource_id="#W1",
        authorized_amount_ceiling=50.0,
        authorized_destinations=["pm_orig"],
        authorized_payment_identity="pm_orig",
        authorized_mutation_set=["none"],
        issued_at=now,
        expires_at=now + 100,
        nonce="n0",
        one_shot=True,
        resource_version_hash=sha256_hex(order),
        evidence_hash="e1",
    )


def req(principal="p1", **kw):
    base = dict(
        principal_id=principal, actor_id="agent.1", action_type="return",
        resource_id="#W1", amount=50.0, destination="pm_orig",
        payment_identity="pm_orig", nonce="n1", authority_id="a1",
    )
    base.update(kw)
    return ExecutionRequest(**base)


def main():
    order = {"order_id": "#W1", "user_id": "p1", "status": "delivered", "items": []}
    clock = Clock(10.0)
    fails = []
    coord = AcceptanceCoordinator()
    reg = RevocationRegistry(coord)
    reg.register("a1", 1)
    led = ExecutionLedger()
    ex = Executor(TRUSTED, reg, led, ISSUER, coord)
    st = ResourceStore({"#W1": order}, coord)
    rec = ex.execute(run_id="u", corpus="unit", commit=None, spec=spec(10, order), req=req(), store=st, clock=clock)
    if rec.executed:
        fails.append("bypass")
    g = CommitGuard(clock, ISSUER)
    out = g.commit(spec(10, order), req(principal="other"), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("principal_allowed")
    s = spec(10, order)
    s.expires_at = 1.0
    out = CommitGuard(clock, ISSUER).commit(s, req(), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("expired_allowed")
    out = CommitGuard(clock, ISSUER).commit(spec(10, order), req(amount=float("nan")), st.version_hash("#W1"))
    if not isinstance(out, tuple):
        fails.append("nan_allowed")
    # forged
    r = req(amount=99.0, destination="pm_forged")
    body = dict(
        commit_id="x", gate_version=GATE_VERSION, decision="ALLOW", reason="IN_SPEC",
        authority_hash=spec(10, order).hash(), request_hash=r.hash(),
        pre_state_hash=st.version_hash("#W1"), principal_id=r.principal_id,
        actor_id=r.actor_id, action_type=r.action_type, resource_id=r.resource_id,
        amount=r.amount, destination=r.destination, payment_identity=r.payment_identity,
        nonce=r.nonce, committed_at=10.0, revocation_version=1, issuer_key_id=ISSUER.key_id, signature="",
        commit_hash="00",
    )
    body["commit_hash"] = sha256_hex({k: body[k] for k in body if k != "signature"})
    rec = ex.execute(run_id="u", corpus="unit", commit=ValidatedCommit(**body), spec=spec(10, order), req=r, store=st, clock=clock)
    if rec.executed:
        fails.append("forged_executed")
    # outcome-tamper: flip executed and reseal hash — verifier must reject
    s_ok = spec(10, order)
    r_ok = req(nonce="n-ok")
    c_ok = CommitGuard(clock, ISSUER).commit(s_ok, r_ok, st.version_hash("#W1"))
    if isinstance(c_ok, tuple):
        fails.append("tamper_setup")
    else:
        rec_ok = ex.execute(run_id="u", corpus="unit", commit=c_ok, spec=s_ok, req=r_ok, store=st, clock=clock)
        import sys as _sys
        _sys.path.insert(0, str(Path(__file__).resolve().parent))
        from test_receipt_matrix import run_matrix_one
        pubs_m = {ISSUER.key_id: (
            ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
            ISSUER.fingerprint,
        )}
        fails.extend(run_matrix_one(verify_receipt, rec_ok, s_ok.public_dict()|{"consumed": s_ok.consumed}, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs_m, "allow"))
        s_den = spec(10, order)
        r_den = req(nonce="n-den")
        c_den = CommitGuard(clock, ISSUER).commit(s_den, r_den, st.version_hash("#W1"))
        if not isinstance(c_den, tuple):
            clock.advance(max(0.0, s_den.expires_at - clock.now() + 1))
            rec_den = ex.execute(run_id="u", corpus="unit", commit=c_den, spec=s_den, req=r_den, store=st, clock=clock)
            fails.extend(run_matrix_one(verify_receipt, rec_den, s_den.public_dict()|{"consumed": s_den.consumed}, asdict(r_den), {k: getattr(c_den, k) for k in c_den.__dataclass_fields__}, pubs_m, "deny"))
        rd = asdict(rec_ok)
        pubs = {ISSUER.key_id: (
            ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
            ISSUER.fingerprint,
        )}
        rd["executed"] = not rd["executed"]
        rd["receipt_hash"] = ""
        from hashutil import sha256_hex as h
        rd["receipt_hash"] = h({k: rd[k] if k != "receipt_hash" else "" for k in rd})
        spec_d = s_ok.public_dict() | {"consumed": s_ok.consumed}
        v = verify_receipt(rd, spec_d, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs)
        if v["ok"]:
            fails.append("tampered_receipt_accepted")
        # field mutations
        for field in ("actor_id", "commit_id", "executed_payment_identity", "reconciled_final_state",
                       "action_type", "resource_id", "nonce", "execution_ts",
                       "revocation_status_at_exec", "revocation_version_at_exec",
                       "pre_state_hash", "post_state_hash", "authority_hash", "request_hash",
                       "authority_id", "authorized_amount_or_ceiling", "authorized_destination",
                       "authorized_payment_identity", "spec_expires_at", "commit_signature", "issuer_key_id"):
            rd2 = asdict(rec_ok)
            rd2[field] = "MUTATED"
            rd2["receipt_hash"] = h({k: rd2[k] if k != "receipt_hash" else "" for k in rd2})
            v2 = verify_receipt(rd2, spec_d, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs)
            if v2["ok"]:
                fails.append(f"mutated_{field}_accepted")
        s_b = spec(10, order)
        r_b = req(nonce="n-B")
        c_b = CommitGuard(Clock(11.0), ISSUER).commit(s_b, r_b, st.version_hash("#W1"))
        if not isinstance(c_b, tuple):
            vb = verify_receipt(asdict(rec_ok), spec_d, asdict(r_ok), {k: getattr(c_b, k) for k in c_b.__dataclass_fields__}, pubs)
            if vb["ok"]:
                fails.append("event_for_distinct_commit")
        # fabricated success from a denial-shaped receipt without new event sig
        rd3 = asdict(rec_ok)
        rd3["executed"] = True
        rd3["execution_decision"] = "ALLOW"
        if rd3.get("execution_event"):
            rd3["execution_event"] = dict(rd3["execution_event"])
            rd3["execution_event"]["executed"] = True
            rd3["execution_event"]["decision"] = "ALLOW"
            # keep old signature
        rd3["receipt_hash"] = h({k: rd3[k] if k != "receipt_hash" else "" for k in rd3})
        v3 = verify_receipt(rd3, spec_d, asdict(r_ok), {k: getattr(c_ok, k) for k in c_ok.__dataclass_fields__}, pubs)
        # rec_ok was already executed so this is messy; separate never-executed below

    # two clients same path
    import tempfile, threading
    from ledger import LedgerStorageError
    tmp = Path(tempfile.mkdtemp()) / "led.json"
    results = []
    errs = []
    def worker(tag):
        try:
            L = ExecutionLedger(tmp)
            results.append((tag, L.try_consume("CID-SHARED")[0]))
        except Exception as e:
            errs.append(repr(e))
    t1 = threading.Thread(target=worker, args=("a",))
    t2 = threading.Thread(target=worker, args=("b",))
    t1.start(); t2.start(); t1.join(); t2.join()
    if errs:
        fails.append(f"worker_errors {errs}")
    if len(results) != 2:
        fails.append(f"missing_worker_result {results}")
    wins = sum(1 for _, w in results if w is True)
    losses = sum(1 for _, w in results if w is False)
    if wins != 1 or losses != 1:
        fails.append(f"atomic_try_consume {results}")
    L1 = ExecutionLedger(tmp)
    L2 = ExecutionLedger(tmp)
    w1 = L1.try_consume("CID-2")[0]
    w2 = L2.try_consume("CID-2")[0]
    if not (w1 and not w2):
        fails.append(f"two_preexisting_clients {w1}{w2}")
    # in-memory two threads — join every worker
    mem = ExecutionLedger()
    mres, merr = [], []
    def mworker(tag):
        try:
            mres.append(mem.try_consume("MEM")[0])
        except Exception as e:
            merr.append(repr(e))
    th = [threading.Thread(target=mworker, args=(x,)) for x in ("a", "b")]
    for x in th:
        x.start()
    for x in th:
        x.join()
    if merr or len(mres) != 2 or sum(1 for x in mres if x) != 1:
        fails.append(f"mem_threads {mres} {merr}")
    # corruption fail-closed
    good = Path(tempfile.mkdtemp()) / "c.json"
    G = ExecutionLedger(good)
    assert G.try_consume("Z")[0]
    for payload in ("{not json", "", "{}"):
        good.write_text(payload)
        threw = False
        try:
            ExecutionLedger(good).try_consume("Z2")
        except LedgerStorageError:
            threw = True
        if not threw:
            fails.append(f"corrupt_accepted:{payload!r}")

    # never-executed valid commit is authorization only
    s_n = spec(10, order)
    r_n = req(nonce="n-never")
    c_n = CommitGuard(clock, ISSUER).commit(s_n, r_n, st.version_hash("#W1"))
    if not isinstance(c_n, tuple):
        fake = {
            "executed": True, "execution_decision": "ALLOW", "decision_reason": "IN_SPEC",
            "processor_mode": "SIMULATED", "processor_event_id": None,
            "external_execution": False, "external_reconciliation": "N/A",
            "simulated_acceptance": True, "execution_event": None,
            "receipt_hash": "00", "execution_ts": 10,
        }
        fake["receipt_hash"] = sha256_hex({k: fake[k] if k != "receipt_hash" else "" for k in fake})
        pubs = {ISSUER.key_id: (
            ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
            ISSUER.fingerprint,
        )}
        vn = verify_receipt(fake, s_n.public_dict()|{"consumed": s_n.consumed}, asdict(r_n), {k: getattr(c_n,k) for k in c_n.__dataclass_fields__}, pubs)
        if vn["ok"] or vn.get("execution_evidence_valid"):
            fails.append("never_executed_accepted_as_execution")
        # event A must not evidence commit B
        s_b = spec(10, order)
        r_b = req(nonce="n-B")
        c_b = CommitGuard(Clock(11.0), ISSUER).commit(s_b, r_b, st.version_hash("#W1"))
        if not isinstance(c_ok, tuple) and not isinstance(c_b, tuple):
            rdA = asdict(rec_ok)
            vb = verify_receipt(rdA, spec_d, asdict(r_ok), {k: getattr(c_b, k) for k in c_b.__dataclass_fields__}, pubs)
            if vb["ok"] or vb.get("execution_evidence_valid"):
                fails.append("event_for_distinct_commit")
        if not vn.get("authorization_valid") and False:
            pass

    # ================================================================
    # V1.1.8 regression: absent-object denial summaries must reject fabrication
    # (closes the V1.1.7 finding: fabricated summary fields on a genuine denial
    # were previously accepted because `if commit is not None`/`if spec is not
    # None` had no corresponding fixed-value check for the absent case).
    # ================================================================
    pubs_abs = {ISSUER.key_id: (
        ISSUER.pub.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex(),
        ISSUER.fingerprint,
    )}

    # Case A: spec present, commit absent (DIRECT_EXECUTOR_BYPASS-style denial).
    s_nc = spec(10, order)
    r_nc = req(nonce="n-nocommit")
    rec_nc = ex.execute(run_id="u", corpus="unit", commit=None, spec=s_nc, req=r_nc, store=st, clock=clock)
    spec_nc_d = s_nc.public_dict() | {"consumed": s_nc.consumed}
    v_nc_base = verify_receipt(asdict(rec_nc), spec_nc_d, asdict(r_nc), None, pubs_abs)
    if not v_nc_base["ok"]:
        fails.append(f"absent_commit_genuine_denial_rejected {v_nc_base['mismatches']}")
    for field, val in (("commit_signature", "fake"), ("issuer_key_id", "fake-key")):
        rdx = asdict(rec_nc)
        rdx[field] = val
        rdx["receipt_hash"] = sha256_hex({k: rdx[k] if k != "receipt_hash" else "" for k in rdx})
        vx = verify_receipt(rdx, spec_nc_d, asdict(r_nc), None, pubs_abs)
        if vx["ok"]:
            fails.append(f"absent_commit_fabricated_{field}_still_accepted")

    # Case B: neither spec nor commit present (MISSING_AUTHORITY_SPEC denial).
    r_neither = req(nonce="n-neither")
    rec_neither = ex.execute(run_id="u", corpus="unit", commit=None, spec=None, req=r_neither, store=st, clock=clock)
    v_neither_base = verify_receipt(asdict(rec_neither), None, asdict(r_neither), None, pubs_abs)
    if not v_neither_base["ok"]:
        fails.append(f"absent_both_genuine_denial_rejected {v_neither_base['mismatches']}")
    fabrications = {
        "authority_id": "attacker-authority",
        "authorized_amount_or_ceiling": 999999.0,
        "authorized_destination": ["attacker_dest"],
        "authorized_payment_identity": "attacker_pm",
        "spec_expires_at": 999999.0,
        "commit_signature": "fake-sig",
        "issuer_key_id": "fake-key-2",
    }
    for field, val in fabrications.items():
        rdy = asdict(rec_neither)
        rdy[field] = val
        rdy["receipt_hash"] = sha256_hex({k: rdy[k] if k != "receipt_hash" else "" for k in rdy})
        vy = verify_receipt(rdy, None, asdict(r_neither), None, pubs_abs)
        if vy["ok"]:
            fails.append(f"absent_both_fabricated_{field}_still_accepted")

    # ================================================================
    # V1.1.8 regression: shared coordination is mandatory at the execution
    # boundary. A missing or mismatched coordinator across executor/registry/
    # store must DENY before the commit is consumed -- proven by re-running
    # the identical commit through correctly coordinated components afterward
    # and confirming it still executes (would fail with COMMIT_ALREADY_EXECUTED
    # if the rejected attempt had actually consumed it).
    # ================================================================
    s_co = spec(clock.now(), order)
    s_co.authority_id = "a-coord-1"
    reg.register("a-coord-1", 1)
    r_co = req(nonce="n-coord-1", authority_id="a-coord-1")
    c_co = CommitGuard(clock, ISSUER).commit(s_co, r_co, st.version_hash("#W1"))
    if isinstance(c_co, tuple):
        fails.append("coord_setup_commit_failed")
    else:
        # (1) missing coordinator entirely
        ex_missing = Executor(TRUSTED, reg, led, ISSUER, coordinator=None)
        rec_missing = ex_missing.execute(run_id="u", corpus="unit", commit=c_co, spec=s_co, req=r_co, store=st, clock=clock)
        if rec_missing.executed:
            fails.append("missing_coordinator_executed")
        if rec_missing.decision_reason != "MISSING_COORDINATOR":
            fails.append(f"missing_coordinator_wrong_reason:{rec_missing.decision_reason}")
        if led.contains(c_co.commit_id):
            fails.append("missing_coordinator_consumed_commit")

        # (2) mismatched coordinator: registry/store share one coordinator, executor holds another
        coord_other = AcceptanceCoordinator()
        ex_mismatched = Executor(TRUSTED, reg, led, ISSUER, coordinator=coord_other)
        rec_mismatched = ex_mismatched.execute(run_id="u", corpus="unit", commit=c_co, spec=s_co, req=r_co, store=st, clock=clock)
        if rec_mismatched.executed:
            fails.append("mismatched_coordinator_executed")
        if rec_mismatched.decision_reason != "MISMATCHED_COORDINATOR":
            fails.append(f"mismatched_coordinator_wrong_reason:{rec_mismatched.decision_reason}")
        if led.contains(c_co.commit_id):
            fails.append("mismatched_coordinator_consumed_commit")

        # (3) proof the commit was never consumed by either rejected attempt: the SAME
        # commit, run through the properly coordinated executor, must still succeed.
        rec_finally = ex.execute(run_id="u", corpus="unit", commit=c_co, spec=s_co, req=r_co, store=st, clock=clock)
        if not rec_finally.executed:
            fails.append(f"coordinated_execution_after_rejections_failed:{rec_finally.decision_reason}")

        # (4) a second attempt through the coordinated executor must now correctly
        # fail as an ordinary replay (COMMIT_ALREADY_EXECUTED) -- confirming rec_finally
        # really did consume it, so (1)/(2) truly left it unconsumed rather than the
        # ledger having ignored duplicate consumption for an unrelated reason.
        rec_replay = ex.execute(run_id="u", corpus="unit", commit=c_co, spec=s_co, req=r_co, store=st, clock=clock)
        if rec_replay.executed:
            fails.append("replay_after_legitimate_execution_succeeded")
        if rec_replay.decision_reason != "COMMIT_ALREADY_EXECUTED":
            fails.append(f"replay_after_legitimate_execution_wrong_reason:{rec_replay.decision_reason}")

    print("UNIT_FAILS", fails)
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
