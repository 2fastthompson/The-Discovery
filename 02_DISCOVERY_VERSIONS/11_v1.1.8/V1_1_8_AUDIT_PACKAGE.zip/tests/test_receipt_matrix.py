"""Table-driven receipt field contract for allow and deny."""
from __future__ import annotations
import copy
from dataclasses import asdict
from hashutil import sha256_hex

MUTATION_FIELDS = (
    "authority_id", "authorized_amount_or_ceiling", "authorized_destination",
    "authorized_payment_identity", "spec_expires_at", "commit_signature",
    "issuer_key_id", "actor_id", "commit_id", "executed_payment_identity",
    "executed_destination", "executed_amount", "reconciled_final_state",
    "action_type", "resource_id", "nonce", "execution_ts",
    "revocation_status_at_exec", "revocation_version_at_exec",
    "pre_state_hash", "post_state_hash", "authority_hash", "request_hash",
)

def _rehash(rd: dict) -> dict:
    out = copy.deepcopy(rd)
    out["receipt_hash"] = ""
    out["receipt_hash"] = sha256_hex(out)
    return out

def run_matrix_one(verify_receipt, rec, spec_d, req_d, commit_d, pubs, label) -> list[str]:
    fails = []
    rd0 = asdict(rec) if hasattr(rec, "__dataclass_fields__") else dict(rec)
    base = verify_receipt(rd0, spec_d, req_d, commit_d, pubs)
    if not base["ok"]:
        fails.append(f"{label}_authentic_rejected {base.get('mismatches')}")
        return fails
    for field in MUTATION_FIELDS:
        rd = _rehash({**rd0, field: "MUTATED"})
        if verify_receipt(rd, spec_d, req_d, commit_d, pubs)["ok"]:
            fails.append(f"{label}_mutated_{field}_accepted")
    rd = dict(rd0)
    rd.pop("processor_event_id", None)
    if verify_receipt(_rehash(rd), spec_d, req_d, commit_d, pubs)["ok"]:
        fails.append(f"{label}_deleted_processor_event_id_accepted")
    if verify_receipt(_rehash({**rd0, "external_execution": 0}), spec_d, req_d, commit_d, pubs)["ok"]:
        fails.append(f"{label}_external_execution_int_accepted")
    if verify_receipt(_rehash({**rd0, "simulated_acceptance": 1 if rd0.get("executed") else 0}), spec_d, req_d, commit_d, pubs)["ok"]:
        fails.append(f"{label}_simulated_acceptance_int_accepted")
    if label == "allow":
        if verify_receipt(_rehash({**rd0, "issuer_pubkey_fingerprint": None}), spec_d, req_d, commit_d, pubs)["ok"]:
            fails.append("allow_null_fingerprint_accepted")
    if verify_receipt(_rehash({**rd0, "unexpected_field": "x"}), spec_d, req_d, commit_d, pubs)["ok"]:
        fails.append(f"{label}_extra_key_accepted")
    return fails
