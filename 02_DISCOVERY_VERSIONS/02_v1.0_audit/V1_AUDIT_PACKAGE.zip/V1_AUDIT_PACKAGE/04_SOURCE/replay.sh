#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 replay.py --run-id "${1:-tau-retail-replay-2026-09-04}"
python3 - <<'PY'
import json
from pathlib import Path
from gate import reconstruct_receipt_hash
p = Path("results/receipts.jsonl")
bad = 0
n = 0
for line in p.read_text().splitlines():
    n += 1
    rec = json.loads(line)
    if reconstruct_receipt_hash(rec) != rec["receipt_hash"]:
        bad += 1
print(f"independent_receipt_recompute mismatches={bad} receipts={n}")
raise SystemExit(1 if bad else 0)
PY
