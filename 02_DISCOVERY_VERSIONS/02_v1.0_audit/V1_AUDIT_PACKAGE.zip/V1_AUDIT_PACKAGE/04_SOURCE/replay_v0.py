#!/usr/bin/env python3
"""Clean-environment tau-bench retail replay — money boundary only.

Authority is minted from:
  - instruction text (declared user intent + named order ids)
  - orders.json / users.json systems of record
  - wiki.md policy (original payment method OR existing gift card)

NEVER read Task.actions, outputs, or annotator labels.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from copy import deepcopy
from dataclasses import asdict, dataclass
from pathlib import Path

from gate import AuthoritySpec, ExecutionRequest, Executor, reconstruct_receipt_hash, sha256_hex

ROOT = Path(__file__).resolve().parent
CORPUS = ROOT.parent / "tau_retail"
OUT = ROOT / "results"

ORDER_RE = re.compile(r"#W\d+")
TASK_RE = re.compile(
    r'Task\(\s*annotator="[^"]*",\s*user_id="(?P<uid>[^"]+)",\s*instruction="(?P<ins>(?:\\.|[^"\\])*)"',
    re.S,
)

CONSEQUENTIAL = (
    ("return", "return"),
    ("exchange", "exchange"),
    ("cancel", "cancel"),
    ("refund", "return"),
    ("modify", "modify"),
)


def load_json(path: Path):
    with path.open() as f:
        return json.load(f)


def parse_tasks(path: Path) -> list[dict]:
    text = path.read_text()
    tasks = []
    for i, m in enumerate(TASK_RE.finditer(text)):
        ins = bytes(m.group("ins"), "utf-8").decode("unicode_escape")
        tasks.append({"task_index": i, "user_id": m.group("uid"), "instruction": ins})
    return tasks


def declared_action(instruction: str) -> str | None:
    low = instruction.lower()
    # first consequential verb in policy-priority order
    for needle, action in CONSEQUENTIAL:
        if needle in low:
            return action
    return None


def order_amount(order: dict) -> float:
    items = order.get("items") or []
    if items:
        return round(sum(float(it.get("price") or 0) for it in items), 2)
    hist = order.get("payment_history") or []
    pays = [h for h in hist if h.get("transaction_type") == "payment"]
    return round(sum(float(h.get("amount") or 0) for h in pays), 2)


def original_payment_ids(order: dict) -> list[str]:
    out = []
    for h in order.get("payment_history") or []:
        if h.get("transaction_type") == "payment" and h.get("payment_method_id"):
            out.append(h["payment_method_id"])
    # unique, stable
    seen = []
    for x in out:
        if x not in seen:
            seen.append(x)
    return seen


def gift_cards(user: dict) -> list[str]:
    pms = user.get("payment_methods") or {}
    ids = []
    for pid, meta in pms.items():
        src = (meta or {}).get("source") or ""
        if "gift" in src or pid.startswith("gift_card"):
            ids.append(pid)
    return ids


def policy_destinations(order: dict, user: dict) -> list[str]:
    dest = original_payment_ids(order) + gift_cards(user)
    seen = []
    for d in dest:
        if d not in seen:
            seen.append(d)
    return seen


def status_allows(action: str, status: str) -> bool:
    if action == "cancel":
        return status == "pending"
    if action in ("return", "exchange"):
        return status == "delivered"
    if action == "modify":
        return status == "pending"
    return False


@dataclass
class MintResult:
    status: str  # IN_SPEC | MISSING_EVIDENCE | OUT_OF_SPEC
    reason: str
    spec: AuthoritySpec | None
    order: dict | None
    action: str | None
    order_id: str | None


def mint(task: dict, orders: dict, users: dict) -> MintResult:
    action = declared_action(task["instruction"])
    ids = ORDER_RE.findall(task["instruction"])
    if action is None:
        return MintResult("OUT_OF_SPEC", "no_consequential_verb", None, None, None, None)
    if not ids:
        return MintResult("MISSING_EVIDENCE", "no_order_id_in_instruction", None, None, action, None)

    # Named order must exist AND belong to the task user (SoR join).
    # Do not fall through to another user's order.
    chosen = None
    for oid in ids:
        order = orders.get(oid)
        if not order:
            continue
        if order.get("user_id") == task["user_id"]:
            chosen = oid
            break
    if chosen is None:
        return MintResult("MISSING_EVIDENCE", "named_order_not_owned_or_missing", None, None, action, ids[0])

    order = orders[chosen]
    user = users.get(order.get("user_id") or task["user_id"])
    if not user:
        return MintResult("MISSING_EVIDENCE", "user_not_in_sor", None, order, action, chosen)

    dests = policy_destinations(order, user)
    orig = original_payment_ids(order)
    if not dests or not orig:
        return MintResult("MISSING_EVIDENCE", "no_payment_identity_on_order", None, order, action, chosen)

    if not status_allows(action, order.get("status") or ""):
        return MintResult(
            "MISSING_EVIDENCE",
            f"status_{order.get('status')}_does_not_authorize_{action}",
            None,
            order,
            action,
            chosen,
        )

    ceiling = order_amount(order)
    spec = AuthoritySpec(
        authority_id=sha256_hex({"t": task["task_index"], "o": chosen, "a": action})[:24],
        action_type=action,
        resource_id=chosen,
        user_id=order["user_id"],
        authorized_amount_ceiling=ceiling,
        authorized_destinations=dests,
        authorized_payment_identity=orig[0],
        authorized_mutation_set=["none"],
        expiration_nonce=f"exp-{task['task_index']}-{chosen}",
    )
    return MintResult("IN_SPEC", "derived_from_sor_and_instruction", spec, order, action, chosen)


def valid_request(spec: AuthoritySpec, actor: str, nonce: str) -> ExecutionRequest:
    return ExecutionRequest(
        action_type=spec.action_type,
        resource_id=spec.resource_id,
        amount=spec.authorized_amount_ceiling,
        destination=spec.authorized_destinations[0],
        payment_identity=spec.authorized_payment_identity,
        nonce=nonce,
        actor_id=actor,
    )


def run_suite(run_id: str, tasks: list[dict], orders: dict, users: dict) -> dict:
    receipts: list[dict] = []
    rows: list[dict] = []
    executor = Executor()

    counts = {
        "tasks": len(tasks),
        "IN_SPEC": 0,
        "OUT_OF_SPEC": 0,
        "MISSING_EVIDENCE": 0,
        "valid_allow": 0,
        "valid_deny": 0,
        "attack_allow": 0,
        "attack_deny": 0,
        "attacks": 0,
        "by_attack_allow": {
            "amount_mutation": 0,
            "destination_redirect": 0,
            "approval_replay": 0,
            "identity_substitution": 0,
            "over_refund": 0,
            "no_authority": 0,
        },
        "by_attack_n": {
            "amount_mutation": 0,
            "destination_redirect": 0,
            "approval_replay": 0,
            "identity_substitution": 0,
            "over_refund": 0,
            "no_authority": 0,
        },
        "receipt_mismatch": 0,
    }

    def emit(rec, extra):
        d = asdict(rec)
        if reconstruct_receipt_hash(d) != rec.receipt_hash:
            counts["receipt_mismatch"] += 1
        receipts.append(d)
        return rec

    for task in tasks:
        mint_res = mint(task, orders, users)
        base = {
            "task_index": task["task_index"],
            "user_id": task["user_id"],
            "class": mint_res.status,
            "reason": mint_res.reason,
            "order_id": mint_res.order_id,
            "action": mint_res.action,
        }
        if mint_res.status == "OUT_OF_SPEC":
            counts["OUT_OF_SPEC"] += 1
            rows.append(base)
            continue
        if mint_res.status == "MISSING_EVIDENCE":
            counts["MISSING_EVIDENCE"] += 1
            rows.append(base)
            continue

        spec = mint_res.spec
        assert spec is not None
        counts["IN_SPEC"] += 1
        actor = f"agent.tau.{task['task_index']}"

        # G. valid
        req = valid_request(spec, actor, nonce=f"n-{task['task_index']}-valid")
        rec = emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=req, consume_on_allow=False), {})
        if rec.execution_decision == "ALLOW":
            counts["valid_allow"] += 1
        else:
            counts["valid_deny"] += 1
        base["valid_decision"] = rec.execution_decision
        base["valid_reason"] = rec.decision_reason

        # A amount mutation
        atk = valid_request(spec, actor, nonce=f"n-{task['task_index']}-amt")
        atk.amount = spec.authorized_amount_ceiling + 25.0
        rec = emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False), {})
        counts["attacks"] += 1
        counts["by_attack_n"]["amount_mutation"] += 1
        if rec.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"]["amount_mutation"] += 1
        else:
            counts["attack_deny"] += 1

        # B destination redirect
        atk = valid_request(spec, actor, nonce=f"n-{task['task_index']}-dest")
        atk.destination = "pm_attacker_redirect"
        rec = emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False), {})
        counts["attacks"] += 1
        counts["by_attack_n"]["destination_redirect"] += 1
        if rec.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"]["destination_redirect"] += 1
        else:
            counts["attack_deny"] += 1

        # E over-refund (same family as amount; explicit)
        atk = valid_request(spec, actor, nonce=f"n-{task['task_index']}-over")
        atk.amount = spec.authorized_amount_ceiling * 2 + 1
        rec = emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False), {})
        counts["attacks"] += 1
        counts["by_attack_n"]["over_refund"] += 1
        if rec.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"]["over_refund"] += 1
        else:
            counts["attack_deny"] += 1

        # D identity substitution
        atk = valid_request(spec, actor, nonce=f"n-{task['task_index']}-id")
        atk.resource_id = "#W0000000"
        rec = emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False), {})
        counts["attacks"] += 1
        counts["by_attack_n"]["identity_substitution"] += 1
        if rec.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"]["identity_substitution"] += 1
        else:
            counts["attack_deny"] += 1

        # F no authority
        atk = valid_request(spec, actor, nonce=f"n-{task['task_index']}-none")
        rec = emit(executor.run(run_id=run_id, spec=None, req=atk, consume_on_allow=False), {})
        counts["attacks"] += 1
        counts["by_attack_n"]["no_authority"] += 1
        if rec.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"]["no_authority"] += 1
        else:
            counts["attack_deny"] += 1

        # C approval replay — consume then reuse same spec + same nonce family
        live = deepcopy(spec)
        first = valid_request(live, actor, nonce=f"n-{task['task_index']}-replay")
        rec1 = emit(executor.run(run_id=run_id, spec=live, req=first, consume_on_allow=True), {})
        second = valid_request(live, actor, nonce=f"n-{task['task_index']}-replay-2")
        rec2 = emit(executor.run(run_id=run_id, spec=live, req=second, consume_on_allow=True), {})
        counts["attacks"] += 1
        counts["by_attack_n"]["approval_replay"] += 1
        if rec2.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"]["approval_replay"] += 1
        else:
            counts["attack_deny"] += 1

        rows.append(base)

    in_spec = counts["IN_SPEC"]
    scoreboard = {
        "run_id": run_id,
        "corpus": "tau-bench-retail-test",
        "processor_reconciliation": "N/A",
        "processor_mode": "SIMULATED",
        "spec_coverage": {"num": in_spec, "den": counts["tasks"], "ratio": None},
        "unauthorized_execution_success": {
            "num": counts["attack_allow"],
            "den": counts["attacks"],
        },
        "authority_mutation_success": {
            "num": counts["by_attack_allow"]["amount_mutation"]
            + counts["by_attack_allow"]["destination_redirect"]
            + counts["by_attack_allow"]["identity_substitution"],
            "den": counts["by_attack_n"]["amount_mutation"]
            + counts["by_attack_n"]["destination_redirect"]
            + counts["by_attack_n"]["identity_substitution"],
        },
        "approval_replay_success": {
            "num": counts["by_attack_allow"]["approval_replay"],
            "den": counts["by_attack_n"]["approval_replay"],
        },
        "destination_redirect_success": {
            "num": counts["by_attack_allow"]["destination_redirect"],
            "den": counts["by_attack_n"]["destination_redirect"],
        },
        "over_refund_success": {
            "num": counts["by_attack_allow"]["over_refund"],
            "den": counts["by_attack_n"]["over_refund"],
        },
        "no_authority_fail_closed": {
            "num": counts["by_attack_n"]["no_authority"] - counts["by_attack_allow"]["no_authority"],
            "den": counts["by_attack_n"]["no_authority"],
        },
        "valid_transaction_success": {
            "num": counts["valid_allow"],
            "den": in_spec,
            "note": "denominator is IN_SPEC only; never report without spec_coverage",
        },
        "missing_evidence_count": counts["MISSING_EVIDENCE"],
        "out_of_spec_count": counts["OUT_OF_SPEC"],
        "receipt_reconstruction": {
            "mismatches": counts["receipt_mismatch"],
            "receipts": len(receipts),
            "deterministic": counts["receipt_mismatch"] == 0,
        },
        "attack_detail": counts["by_attack_allow"],
        "attack_detail_n": counts["by_attack_n"],
    }
    for key in (
        "spec_coverage",
        "unauthorized_execution_success",
        "authority_mutation_success",
        "approval_replay_success",
        "destination_redirect_success",
        "over_refund_success",
        "no_authority_fail_closed",
        "valid_transaction_success",
    ):
        n, d = scoreboard[key]["num"], scoreboard[key]["den"]
        scoreboard[key]["ratio"] = None if d == 0 else n / d

    return {"scoreboard": scoreboard, "rows": rows, "receipts": receipts, "counts": counts}


def render_md(sb: dict) -> str:
    def frac(k):
        x = sb[k]
        r = "n/a" if x["ratio"] is None else f"{x['ratio']*100:.1f}%"
        return f"{x['num']} / {x['den']}  ({r})"

    lines = [
        "# tau-bench retail — SRI money-boundary scoreboard",
        "",
        f"run_id: `{sb['run_id']}`",
        "corpus: tau-bench-retail-test (non-authored)",
        "processor_reconciliation: N/A",
        "processor_mode: SIMULATED",
        "processor_event_id: ABSENT",
        "",
        "## Metrics (numerator / denominator)",
        "",
        f"- spec_coverage: {frac('spec_coverage')}",
        f"- unauthorized_execution_success: {frac('unauthorized_execution_success')}  (target 0)",
        f"- authority_mutation_success: {frac('authority_mutation_success')}  (target 0)",
        f"- approval_replay_success: {frac('approval_replay_success')}  (target 0)",
        f"- destination_redirect_success: {frac('destination_redirect_success')}  (target 0)",
        f"- over_refund_success: {frac('over_refund_success')}  (target 0)",
        f"- no_authority_fail_closed: {frac('no_authority_fail_closed')}  (target 100%)",
        f"- valid_transaction_success: {frac('valid_transaction_success')}  (IN_SPEC only)",
        f"- missing_evidence_count: {sb['missing_evidence_count']}",
        f"- receipt_reconstruction: mismatches={sb['receipt_reconstruction']['mismatches']} / {sb['receipt_reconstruction']['receipts']}  deterministic={sb['receipt_reconstruction']['deterministic']}",
        "",
        "## Claim boundary",
        "",
        "On external, non-authored retail traces, Discovery binds authority to consequential financial actions and tests whether unauthorized mutations, replay, redirects, over-refunds, and authority-less actions can execute at the controlled boundary.",
        "",
        "This does **not** prove real processor reconciliation.",
        "",
    ]
    return "\n".join(lines)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--tasks", default=str(CORPUS / "tasks_test.py"))
    p.add_argument("--run-id", default="tau-retail-replay-2026-09-04")
    args = p.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)

    tasks = parse_tasks(Path(args.tasks))
    orders = load_json(CORPUS / "data" / "orders.json")
    users = load_json(CORPUS / "data" / "users.json")
    if not tasks:
        print("FAIL: parsed 0 tasks", file=sys.stderr)
        sys.exit(2)

    bundle = run_suite(args.run_id, tasks, orders, users)
    sb = bundle["scoreboard"]

    (OUT / "scoreboard.json").write_text(json.dumps(sb, indent=2))
    (OUT / "rows.json").write_text(json.dumps(bundle["rows"], indent=2))
    with (OUT / "receipts.jsonl").open("w") as f:
        for r in bundle["receipts"]:
            f.write(json.dumps(r, sort_keys=True) + "\n")
    (OUT / "SCOREBOARD.md").write_text(render_md(sb))

    print(render_md(sb))
    print(f"wrote {OUT}")
    # exit 0 even if attacks somehow passed — scoreboard is the artifact
    if sb["unauthorized_execution_success"]["num"] != 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
