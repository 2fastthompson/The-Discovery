"""Read-only pre-execution evidence resolution.

Never import or parse Task.actions / outputs / evaluation_criteria.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from gate import AuthoritySpec, sha256_hex

ORDER_RE = re.compile(r"#W\d+")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")
USER_ID_RE = re.compile(
    r"you are\s+([a-z]+_[a-z]+_\d+)\s*(?:\((?:zip(?:\s+code)?)\s+(\d{5})\))?",
    re.I,
)
NAME_ZIP_RE = re.compile(
    r"you are\s+([A-Z][a-z]+)\s+([A-Z][a-z]+)\s+in(?:\s+zip(?:\s+code)?)?\s+(\d{5})",
    re.I,
)
NAME_LIVE_ZIP_RE = re.compile(
    r"you are\s+([A-Z][a-z]+)\s+([A-Z][a-z]+)\b[^.]{0,80}?\b(\d{5})",
    re.I,
)
NAME_ZIP_RE2 = re.compile(
    r"([A-Z][a-z]+)\s+([A-Z][a-z]+).*?\b(?:zip(?:\s+code)?)\s+(\d{5})",
    re.I,
)
# "Your name is Daiki Sanchez, and you live in 46236"
# "You're Chen Smith, living in Jacksonville 32278"
# "called Noah Patel, living in the Big Apple in 10108"
NAME_ALT_RE = re.compile(
    r"(?:your name is|you(?:'| a)re|called)\s+([A-Z][a-z]+)\s+([A-Z][a-z]+)\b[^.]{0,120}?\b(\d{5})",
    re.I,
)

CONSEQUENTIAL = (
    ("return", "return"),
    ("exchange", "exchange"),
    ("cancel", "cancel"),
    ("refund", "return"),
    ("modify", "modify"),
)


def declared_action(instruction: str) -> str | None:
    low = instruction.lower()
    for needle, action in CONSEQUENTIAL:
        if needle in low:
            return action
    return None


def order_amount(order: dict) -> float:
    items = order.get("items") or []
    if items:
        return round(sum(float(it.get("price") or 0) for it in items), 2)
    hist = order.get("payment_history") or []
    pays = [h for h in hist if h.get("transaction_type") == "payment"]
    return round(sum(float(h.get("amount") or 0) for h in pays), 2)


def original_payment_ids(order: dict) -> list[str]:
    seen: list[str] = []
    for h in order.get("payment_history") or []:
        if h.get("transaction_type") == "payment" and h.get("payment_method_id"):
            pid = h["payment_method_id"]
            if pid not in seen:
                seen.append(pid)
    return seen


def gift_cards(user: dict) -> list[str]:
    ids = []
    for pid, meta in (user.get("payment_methods") or {}).items():
        src = (meta or {}).get("source") or ""
        if "gift" in src or pid.startswith("gift_card"):
            ids.append(pid)
    return ids


def policy_destinations(order: dict, user: dict) -> list[str]:
    seen: list[str] = []
    for d in original_payment_ids(order) + gift_cards(user):
        if d not in seen:
            seen.append(d)
    return seen


def status_allows(action: str, status: str) -> bool:
    if action == "cancel":
        return status == "pending"
    if action in ("return", "exchange"):
        return status == "delivered"
    if action == "modify":
        return status == "pending"
    return False


def _name_zip_hits(users: dict, first: str, last: str, zipc: str) -> list[str]:
    hits = []
    for uid, u in users.items():
        name = u.get("name") or {}
        z = (u.get("address") or {}).get("zip")
        if (
            (name.get("first_name") or "").lower() == first.lower()
            and (name.get("last_name") or "").lower() == last.lower()
            and str(z) == zipc
        ):
            hits.append(uid)
    return hits


def lookup_user_from_instruction(instruction: str, users: dict) -> tuple[str | None, str]:
    """Return (user_id, reason). Read-only SoR lookup from instruction text only."""
    uid_m = USER_ID_RE.search(instruction)
    if uid_m:
        uid = uid_m.group(1)
        zipc = uid_m.group(2)
        if uid in users:
            if zipc:
                z = str((users[uid].get("address") or {}).get("zip") or "")
                if z and z != zipc:
                    return None, "user_id_zip_mismatch"
            return uid, "user_id_in_instruction"
        return None, "user_id_not_in_sor"

    email = EMAIL_RE.search(instruction)
    if email:
        addr = email.group(0).lower()
        hits = [uid for uid, u in users.items() if (u.get("email") or "").lower() == addr]
        if len(hits) == 1:
            return hits[0], "email_lookup"
        if len(hits) > 1:
            return None, "ambiguous_email_lookup"

    m = (
        NAME_ZIP_RE.search(instruction)
        or NAME_LIVE_ZIP_RE.search(instruction)
        or NAME_ALT_RE.search(instruction)
        or NAME_ZIP_RE2.search(instruction)
    )
    if not m:
        return None, "no_user_identity_in_instruction"
    first, last, zipc = m.group(1), m.group(2), m.group(3)
    hits = _name_zip_hits(users, first, last, zipc)
    if len(hits) == 1:
        return hits[0], "name_zip_lookup"
    if len(hits) > 1:
        return None, "ambiguous_name_zip_lookup"
    return None, "name_zip_not_in_sor"


def item_names(order: dict) -> list[str]:
    return [str(it.get("name") or "") for it in (order.get("items") or []) if it.get("name")]


def mentioned_item_orders(instruction: str, candidate_orders: list[dict]) -> list[dict]:
    low = instruction.lower()
    scored = []
    for order in candidate_orders:
        hits = 0
        for name in item_names(order):
            if len(name) >= 4 and name.lower() in low:
                hits += 1
        scored.append((hits, order))
    if any(h > 0 for h, _ in scored):
        return [o for h, o in scored if h > 0]
    return candidate_orders


@dataclass
class MintResult:
    status: str  # IN_SPEC | MISSING_EVIDENCE | OUT_OF_SPEC | AMBIGUOUS_INTENT
    reason: str
    spec: AuthoritySpec | None
    order: dict | None
    action: str | None
    order_id: str | None
    evidence_path: list[str]


def mint(instruction: str, orders: dict, users: dict, task_index: int) -> MintResult:
    path: list[str] = ["instruction"]
    action = declared_action(instruction)
    if action is None:
        return MintResult("OUT_OF_SPEC", "no_consequential_verb", None, None, None, None, path)

    path.append(f"declared_action={action}")
    uid, how = lookup_user_from_instruction(instruction, users)
    named = ORDER_RE.findall(instruction)

    if uid:
        path.append(f"user_lookup:{how}:{uid}")
        user = users[uid]
        owned_ids = list(user.get("orders") or [])
        path.append(f"user_order_inventory:{len(owned_ids)}")
    else:
        path.append(f"user_lookup_failed:{how}")
        user = None
        owned_ids = []

    # Named order IDs are first-class instruction evidence.
    candidates: list[dict] = []
    if named:
        path.append(f"named_order_ids:{named}")
        for oid in named:
            order = orders.get(oid)
            if not order:
                continue
            if uid and order.get("user_id") != uid:
                path.append(f"reject_foreign_order:{oid}")
                continue
            if not uid:
                # order id present but user unresolved: bind only if unique owner exists in SoR
                uid = order.get("user_id")
                user = users.get(uid)
                path.append(f"user_from_owned_named_order:{uid}")
            candidates.append(order)
    elif uid:
        for oid in owned_ids:
            order = orders.get(oid)
            if order:
                candidates.append(order)
        path.append(f"candidates_from_inventory:{len(candidates)}")
    else:
        return MintResult(
            "MISSING_EVIDENCE",
            "no_user_and_no_named_order",
            None,
            None,
            action,
            named[0] if named else None,
            path,
        )

    if not candidates:
        return MintResult("MISSING_EVIDENCE", "no_candidate_orders", None, None, action, None, path)

    status_ok = [o for o in candidates if status_allows(action, o.get("status") or "")]
    path.append(f"status_filter:{len(status_ok)}/{len(candidates)}")
    if not status_ok:
        return MintResult(
            "MISSING_EVIDENCE",
            "no_order_status_authorizes_action",
            None,
            candidates[0],
            action,
            candidates[0].get("order_id"),
            path,
        )

    narrowed = mentioned_item_orders(instruction, status_ok)
    path.append(f"item_name_filter:{len(narrowed)}/{len(status_ok)}")

    if len(narrowed) > 1:
        return MintResult(
            "AMBIGUOUS_INTENT",
            "multiple_orders_match_action_and_items",
            None,
            None,
            action,
            None,
            path,
        )

    order = narrowed[0]
    oid = order.get("order_id")
    if user is None:
        user = users.get(order.get("user_id"))
    if not user:
        return MintResult("MISSING_EVIDENCE", "user_not_in_sor", None, order, action, oid, path)

    dests = policy_destinations(order, user)
    orig = original_payment_ids(order)
    if not dests or not orig:
        return MintResult(
            "MISSING_EVIDENCE",
            "no_payment_identity_on_order",
            None,
            order,
            action,
            oid,
            path,
        )

    spec = AuthoritySpec(
        authority_id=sha256_hex({"t": task_index, "o": oid, "a": action})[:24],
        action_type=action,
        resource_id=oid,
        user_id=order["user_id"],
        authorized_amount_ceiling=order_amount(order),
        authorized_destinations=dests,
        authorized_payment_identity=orig[0],
        authorized_mutation_set=["none"],
        expiration_nonce=f"exp-{task_index}-{oid}",
    )
    path.append("authority_minted")
    return MintResult("IN_SPEC", "derived_from_lookup_and_sor", spec, order, action, oid, path)
