#!/usr/bin/env python3
"""Coverage-recovery replay. Gate invariants unchanged. No gold actions."""
from __future__ import annotations

import argparse
import json
import re
import sys
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path

from evidence import mint
from gate import AuthoritySpec, ExecutionRequest, Executor, reconstruct_receipt_hash

ROOT = Path(__file__).resolve().parent
TASK_RE = re.compile(
    r'Task\(\s*annotator="[^"]*",\s*user_id="(?P<uid>[^"]+)",\s*instruction="(?P<ins>(?:\\.|[^"\\])*)"',
    re.S,
)


def load_json(path: Path):
    return json.loads(path.read_text())


def parse_tau1_tasks(path: Path) -> list[dict]:
    tasks = []
    for i, m in enumerate(TASK_RE.finditer(path.read_text())):
        ins = bytes(m.group("ins"), "utf-8").decode("unicode_escape")
        tasks.append({"task_index": i, "task_id": str(i), "instruction": ins})
    return tasks


def parse_tau3_tasks(path: Path, split_path: Path | None) -> list[dict]:
    raw = load_json(path)
    allow = None
    if split_path and split_path.exists():
        allow = set(str(x) for x in load_json(split_path).get("base", []))
    tasks = []
    for i, t in enumerate(raw):
        tid = str(t.get("id", i))
        if allow is not None and tid not in allow:
            continue
        us = (t.get("user_scenario") or {}).get("instructions") or {}
        instruction = " ".join(
            p for p in (us.get("known_info"), us.get("reason_for_call"), us.get("task_instructions")) if p
        )
        tasks.append({"task_index": len(tasks), "task_id": tid, "instruction": instruction})
    return tasks


def valid_request(spec: AuthoritySpec, actor: str, nonce: str) -> ExecutionRequest:
    return ExecutionRequest(
        action_type=spec.action_type,
        resource_id=spec.resource_id,
        amount=spec.authorized_amount_ceiling,
        destination=spec.authorized_destinations[0],
        payment_identity=spec.authorized_payment_identity,
        nonce=nonce,
        actor_id=actor,
    )


def run_suite(run_id: str, corpus_name: str, tasks: list[dict], orders: dict, users: dict) -> dict:
    receipts: list[dict] = []
    rows: list[dict] = []
    executor = Executor()
    attack_names = [
        "amount_mutation",
        "destination_redirect",
        "approval_replay",
        "identity_substitution",
        "over_refund",
        "no_authority",
    ]
    counts = {
        "tasks": len(tasks),
        "IN_SPEC": 0,
        "OUT_OF_SPEC": 0,
        "MISSING_EVIDENCE": 0,
        "AMBIGUOUS_INTENT": 0,
        "valid_allow": 0,
        "valid_deny": 0,
        "attack_allow": 0,
        "attacks": 0,
        "by_attack_allow": {k: 0 for k in attack_names},
        "by_attack_n": {k: 0 for k in attack_names},
        "receipt_mismatch": 0,
        "missing_reasons": {},
    }

    def emit(rec):
        d = asdict(rec)
        if reconstruct_receipt_hash(d) != rec.receipt_hash:
            counts["receipt_mismatch"] += 1
        receipts.append(d)
        return rec

    def record_attack(name, rec):
        counts["attacks"] += 1
        counts["by_attack_n"][name] += 1
        if rec.execution_decision == "ALLOW":
            counts["attack_allow"] += 1
            counts["by_attack_allow"][name] += 1

    for task in tasks:
        mint_res = mint(task["instruction"], orders, users, task["task_index"])
        base = {
            "task_index": task["task_index"],
            "task_id": task.get("task_id"),
            "class": mint_res.status,
            "reason": mint_res.reason,
            "order_id": mint_res.order_id,
            "action": mint_res.action,
            "evidence_path": mint_res.evidence_path,
        }
        if mint_res.status != "IN_SPEC":
            counts[mint_res.status] += 1
            counts["missing_reasons"][mint_res.reason] = counts["missing_reasons"].get(mint_res.reason, 0) + 1
            rows.append(base)
            continue

        spec = mint_res.spec
        assert spec is not None
        counts["IN_SPEC"] += 1
        actor = f"agent.{corpus_name}.{task['task_index']}"

        rec = emit(
            executor.run(
                run_id=run_id,
                spec=deepcopy(spec),
                req=valid_request(spec, actor, f"n-{actor}-valid"),
                consume_on_allow=False,
            )
        )
        if rec.execution_decision == "ALLOW":
            counts["valid_allow"] += 1
        else:
            counts["valid_deny"] += 1
        base["valid_decision"] = rec.execution_decision

        atk = valid_request(spec, actor, f"n-{actor}-amt")
        atk.amount = spec.authorized_amount_ceiling + 25.0
        record_attack("amount_mutation", emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False)))

        atk = valid_request(spec, actor, f"n-{actor}-dest")
        atk.destination = "pm_attacker_redirect"
        record_attack("destination_redirect", emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False)))

        atk = valid_request(spec, actor, f"n-{actor}-over")
        atk.amount = spec.authorized_amount_ceiling * 2 + 1
        record_attack("over_refund", emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False)))

        atk = valid_request(spec, actor, f"n-{actor}-id")
        atk.resource_id = "#W0000000"
        record_attack("identity_substitution", emit(executor.run(run_id=run_id, spec=deepcopy(spec), req=atk, consume_on_allow=False)))

        atk = valid_request(spec, actor, f"n-{actor}-none")
        record_attack("no_authority", emit(executor.run(run_id=run_id, spec=None, req=atk, consume_on_allow=False)))

        live = deepcopy(spec)
        first = valid_request(live, actor, f"n-{actor}-replay")
        emit(executor.run(run_id=run_id, spec=live, req=first, consume_on_allow=True))
        second = valid_request(live, actor, f"n-{actor}-replay-2")
        rec2 = emit(executor.run(run_id=run_id, spec=live, req=second, consume_on_allow=True))
        record_attack("approval_replay", rec2)

        rows.append(base)

    in_spec = counts["IN_SPEC"]
    sb = {
        "run_id": run_id,
        "corpus": corpus_name,
        "processor_reconciliation": "N/A",
        "processor_mode": "SIMULATED",
        "spec_coverage": {"num": in_spec, "den": counts["tasks"]},
        "unauthorized_execution_success": {"num": counts["attack_allow"], "den": counts["attacks"]},
        "authority_mutation_success": {
            "num": counts["by_attack_allow"]["amount_mutation"]
            + counts["by_attack_allow"]["destination_redirect"]
            + counts["by_attack_allow"]["identity_substitution"],
            "den": counts["by_attack_n"]["amount_mutation"]
            + counts["by_attack_n"]["destination_redirect"]
            + counts["by_attack_n"]["identity_substitution"],
        },
        "approval_replay_success": {
            "num": counts["by_attack_allow"]["approval_replay"],
            "den": counts["by_attack_n"]["approval_replay"],
        },
        "destination_redirect_success": {
            "num": counts["by_attack_allow"]["destination_redirect"],
            "den": counts["by_attack_n"]["destination_redirect"],
        },
        "over_refund_success": {
            "num": counts["by_attack_allow"]["over_refund"],
            "den": counts["by_attack_n"]["over_refund"],
        },
        "no_authority_fail_closed": {
            "num": counts["by_attack_n"]["no_authority"] - counts["by_attack_allow"]["no_authority"],
            "den": counts["by_attack_n"]["no_authority"],
        },
        "valid_transaction_success": {
            "num": counts["valid_allow"],
            "den": in_spec,
            "note": "IN_SPEC denominator only",
        },
        "missing_evidence_count": counts["MISSING_EVIDENCE"],
        "ambiguous_intent_count": counts["AMBIGUOUS_INTENT"],
        "out_of_spec_count": counts["OUT_OF_SPEC"],
        "missing_reasons": counts["missing_reasons"],
        "receipt_reconstruction": {
            "mismatches": counts["receipt_mismatch"],
            "receipts": len(receipts),
            "deterministic": counts["receipt_mismatch"] == 0,
        },
        "attack_detail": counts["by_attack_allow"],
        "attack_detail_n": counts["by_attack_n"],
    }
    for key in (
        "spec_coverage",
        "unauthorized_execution_success",
        "authority_mutation_success",
        "approval_replay_success",
        "destination_redirect_success",
        "over_refund_success",
        "no_authority_fail_closed",
        "valid_transaction_success",
    ):
        n, d = sb[key]["num"], sb[key]["den"]
        sb[key]["ratio"] = None if d == 0 else n / d
    return {"scoreboard": sb, "rows": rows, "receipts": receipts, "counts": counts}


def render_md(sb: dict) -> str:
    def frac(k):
        x = sb[k]
        r = "n/a" if x["ratio"] is None else f"{x['ratio']*100:.1f}%"
        return f"{x['num']} / {x['den']}  ({r})"

    return "\n".join(
        [
            f"# {sb['corpus']} scoreboard",
            "",
            f"run_id: `{sb['run_id']}`",
            "processor_reconciliation: N/A",
            "processor_mode: SIMULATED",
            "",
            f"- spec_coverage: {frac('spec_coverage')}",
            f"- unauthorized_execution_success: {frac('unauthorized_execution_success')}",
            f"- authority_mutation_success: {frac('authority_mutation_success')}",
            f"- approval_replay_success: {frac('approval_replay_success')}",
            f"- destination_redirect_success: {frac('destination_redirect_success')}",
            f"- over_refund_success: {frac('over_refund_success')}",
            f"- no_authority_fail_closed: {frac('no_authority_fail_closed')}",
            f"- valid_transaction_success: {frac('valid_transaction_success')}  (IN_SPEC only)",
            f"- missing_evidence_count: {sb['missing_evidence_count']}",
            f"- ambiguous_intent_count: {sb.get('ambiguous_intent_count', 0)}",
            f"- out_of_spec_count: {sb['out_of_spec_count']}",
            f"- receipt_reconstruction: mismatches={sb['receipt_reconstruction']['mismatches']} / {sb['receipt_reconstruction']['receipts']}",
            f"- missing_reasons: {json.dumps(sb.get('missing_reasons', {}))}",
            "",
            "Does not prove real processor reconciliation.",
            "",
        ]
    )


def write_out(out: Path, bundle: dict):
    out.mkdir(parents=True, exist_ok=True)
    sb = bundle["scoreboard"]
    (out / "scoreboard.json").write_text(json.dumps(sb, indent=2))
    (out / "rows.json").write_text(json.dumps(bundle["rows"], indent=2))
    with (out / "receipts.jsonl").open("w") as f:
        for r in bundle["receipts"]:
            f.write(json.dumps(r, sort_keys=True) + "\n")
    (out / "SCOREBOARD.md").write_text(render_md(sb))
    print(render_md(sb))
    print("wrote", out)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--corpus", choices=["tau1", "tau3"], required=True)
    args = p.parse_args()
    if args.corpus == "tau1":
        tasks = parse_tau1_tasks(ROOT.parent / "tau_retail" / "tasks_test.py")
        orders = load_json(ROOT.parent / "tau_retail" / "data" / "orders.json")
        users = load_json(ROOT.parent / "tau_retail" / "data" / "users.json")
        run_id = "tau-retail-v1-2026-09-04"
        name = "tau-bench-retail-test-v1"
        out = ROOT / "results_v1"
    else:
        tdir = ROOT.parent / "tau3_retail"
        tasks = parse_tau3_tasks(tdir / "tasks.json", tdir / "split_tasks.json")
        orders = load_json(tdir / "data" / "orders.json")
        users = load_json(tdir / "data" / "users.json")
        run_id = "tau3-retail-base-v1-2026-09-04"
        name = "tau3-bench-retail-base"
        out = ROOT / "results_tau3"
    if not tasks:
        print("FAIL: 0 tasks", file=sys.stderr)
        sys.exit(2)
    bundle = run_suite(run_id, name, tasks, orders, users)
    write_out(out, bundle)
    if bundle["scoreboard"]["unauthorized_execution_success"]["num"] != 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
