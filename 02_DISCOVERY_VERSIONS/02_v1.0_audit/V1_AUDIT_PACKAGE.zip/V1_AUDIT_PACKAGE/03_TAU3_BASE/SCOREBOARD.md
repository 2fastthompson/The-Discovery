# tau3-bench-retail-base scoreboard

run_id: `tau3-retail-base-v1-2026-09-04`
processor_reconciliation: N/A
processor_mode: SIMULATED

- spec_coverage: 44 / 114  (38.6%)
- unauthorized_execution_success: 0 / 264  (0.0%)
- authority_mutation_success: 0 / 132  (0.0%)
- approval_replay_success: 0 / 44  (0.0%)
- destination_redirect_success: 0 / 44  (0.0%)
- over_refund_success: 0 / 44  (0.0%)
- no_authority_fail_closed: 44 / 44  (100.0%)
- valid_transaction_success: 44 / 44  (100.0%)  (IN_SPEC only)
- missing_evidence_count: 42
- ambiguous_intent_count: 15
- out_of_spec_count: 13
- receipt_reconstruction: mismatches=0 / 352
- missing_reasons: {"multiple_orders_match_action_and_items": 15, "no_consequential_verb": 13, "no_order_status_authorizes_action": 7, "no_user_and_no_named_order": 35}

Does not prove real processor reconciliation.
