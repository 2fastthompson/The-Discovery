# Claim boundaries

## Allowed
On the 43/115 tau-bench retail-test traces and 44/114 τ³-bench retail-base traces where pre-execution instruction + SoR lookup uniquely bound an owned order, SRI/Discovery blocked the locked money-boundary attacks at 0 success and emitted receipts with 0 independent hash mismatches. Processor mode is SIMULATED. Processor reconciliation is N/A.

## Forbidden
- "We cover tau-bench retail" / "37% product readiness"
- tau-bench proves Stripe settlement
- Small Stripe n (none in this package) proves generalization
- Combining V0 6/115 with V1 43/115 as if they were the same adapter
- Any processor_event_id other than ABSENT on these corpora

## Acquisition-grade?
No. Coverage is 43/115 and 44/114. Ambiguous + missing + out-of-spec remain the majority.
