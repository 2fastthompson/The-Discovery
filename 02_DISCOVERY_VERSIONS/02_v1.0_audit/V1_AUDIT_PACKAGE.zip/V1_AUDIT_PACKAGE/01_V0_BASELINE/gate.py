"""SRI / Discovery execution gate — money boundary only. Corpus A (tau-bench)."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from typing import Any


RECEIPT_VERSION = "sri-exec-receipt-v1"
FORBIDDEN_KEYS = {
    "actions",
    "outputs",
    "annotator",
    "expected",
    "gold",
    "evaluation_criteria",
    "reward",
}


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def sha256_hex(obj: Any) -> str:
    if isinstance(obj, str):
        payload = obj.encode("utf-8")
    else:
        payload = canonical_json(obj).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


@dataclass
class AuthoritySpec:
    authority_id: str
    action_type: str
    resource_id: str
    user_id: str
    authorized_amount_ceiling: float
    authorized_destinations: list[str]
    authorized_payment_identity: str
    authorized_mutation_set: list[str]
    expiration_nonce: str
    consumed: bool = False

    def hash(self) -> str:
        d = asdict(self)
        d.pop("consumed", None)
        return sha256_hex(d)


@dataclass
class ExecutionRequest:
    action_type: str
    resource_id: str
    amount: float
    destination: str
    payment_identity: str
    nonce: str
    actor_id: str


@dataclass
class Receipt:
    receipt_version: str
    run_id: str
    corpus: str
    authority_id: str | None
    authority_hash: str | None
    agent_or_actor_id: str
    action_type: str
    resource_id: str
    authorized_amount_or_ceiling: float | None
    authorized_destination: list[str] | None
    authorized_payment_identity: str | None
    authorized_mutation_set: list[str] | None
    authority_expiration: str | None
    nonce: str
    idempotency_key: str
    intent_hash: str
    execution_request_hash: str
    executor_identity: str
    execution_decision: str
    decision_reason: str
    processor_mode: str
    processor_event_id: str | None
    processor_result_hash: str | None
    reconciled_final_state: str
    receipt_hash: str = ""

    def seal(self) -> "Receipt":
        body = asdict(self)
        body["receipt_hash"] = ""
        self.receipt_hash = sha256_hex(body)
        return self


class CommitGuard:
    def __init__(self) -> None:
        self._consumed: set[str] = set()
        self._nonces: set[str] = set()

    def decide(self, spec: AuthoritySpec | None, req: ExecutionRequest) -> tuple[str, str]:
        if spec is None:
            return "DENY", "NO_AUTHORITY"
        if spec.consumed or spec.authority_id in self._consumed:
            return "DENY", "REPLAYED_ONE_SHOT_AUTHORITY"
        if req.nonce in self._nonces:
            return "DENY", "REPLAYED_NONCE"
        if req.resource_id != spec.resource_id:
            return "DENY", "MUTATED_RESOURCE_IDENTITY"
        if req.action_type != spec.action_type:
            return "DENY", "MUTATED_ACTION_TYPE"
        if req.amount - spec.authorized_amount_ceiling > 1e-9:
            return "DENY", "MUTATED_AMOUNT_OR_OVER_REFUND"
        if req.destination not in spec.authorized_destinations:
            return "DENY", "MUTATED_DESTINATION"
        if req.payment_identity != spec.authorized_payment_identity:
            return "DENY", "MUTATED_PAYMENT_IDENTITY"
        return "ALLOW", "IN_SPEC"

    def commit(self, spec: AuthoritySpec, req: ExecutionRequest) -> None:
        spec.consumed = True
        self._consumed.add(spec.authority_id)
        self._nonces.add(req.nonce)


class Executor:
    identity = "sri-executor-sim-v1"

    def __init__(self) -> None:
        self.guard = CommitGuard()

    def run(
        self,
        *,
        run_id: str,
        spec: AuthoritySpec | None,
        req: ExecutionRequest,
        consume_on_allow: bool = True,
    ) -> Receipt:
        decision, reason = self.guard.decide(spec, req)
        if decision == "ALLOW" and consume_on_allow and spec is not None:
            self.guard.commit(spec, req)
        intent = {
            "action_type": req.action_type,
            "resource_id": req.resource_id,
            "amount": req.amount,
            "destination": req.destination,
            "payment_identity": req.payment_identity,
        }
        receipt = Receipt(
            receipt_version=RECEIPT_VERSION,
            run_id=run_id,
            corpus="tau-bench-retail",
            authority_id=None if spec is None else spec.authority_id,
            authority_hash=None if spec is None else spec.hash(),
            agent_or_actor_id=req.actor_id,
            action_type=req.action_type,
            resource_id=req.resource_id,
            authorized_amount_or_ceiling=None if spec is None else spec.authorized_amount_ceiling,
            authorized_destination=None if spec is None else list(spec.authorized_destinations),
            authorized_payment_identity=None if spec is None else spec.authorized_payment_identity,
            authorized_mutation_set=None if spec is None else list(spec.authorized_mutation_set),
            authority_expiration=None if spec is None else spec.expiration_nonce,
            nonce=req.nonce,
            idempotency_key=f"{req.resource_id}:{req.nonce}",
            intent_hash=sha256_hex(intent),
            execution_request_hash=sha256_hex(asdict(req)),
            executor_identity=self.identity,
            execution_decision=decision,
            decision_reason=reason,
            processor_mode="SIMULATED",
            processor_event_id=None,
            processor_result_hash=None,
            reconciled_final_state="N/A",
        ).seal()
        return receipt


def reconstruct_receipt_hash(receipt: dict) -> str:
    body = dict(receipt)
    body["receipt_hash"] = ""
    return sha256_hex(body)
