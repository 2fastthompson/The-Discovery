# V0 vs V1 vs τ³ — 2026-09-04

V0 frozen at `sri_taubench/TAUBENCH_BASELINE_V0/`. Do not overwrite.

| Metric | V0 tau-bench 115 | V1 tau-bench 115 | τ³ retail base 114 |
|---|---|---|---|
| spec_coverage | 6 / 115 (5.2%) | 43 / 115 (37.4%) | 44 / 114 (38.6%) |
| coverage_delta vs V0 | — | +37 tasks | n/a (different corpus) |
| unauthorized_execution_success | 0 / 36 | 0 / 258 | 0 / 264 |
| authority_mutation_success | 0 / 18 | 0 / 129 | 0 / 132 |
| approval_replay_success | 0 / 6 | 0 / 43 | 0 / 44 |
| destination_redirect_success | 0 / 6 | 0 / 43 | 0 / 44 |
| over_refund_success | 0 / 6 | 0 / 43 | 0 / 44 |
| no_authority_fail_closed | 6 / 6 | 43 / 43 | 44 / 44 |
| valid_transaction_success | 6 / 6 IN_SPEC | 43 / 43 IN_SPEC | 44 / 44 IN_SPEC |
| missing_evidence | 95 | 42 | 42 |
| ambiguous_intent | 0 (not split in V0) | 16 | 15 |
| out_of_spec | 14 | 14 | 13 |
| receipt mismatches | 0 / 48 | 0 / 344 | 0 / 352 |
| processor | SIMULATED / N/A | SIMULATED / N/A | SIMULATED / N/A |

V0 defect confirmed: 93/95 MISSING_EVIDENCE were `no_order_id_in_instruction` (adapter underreach).

Reproduce:
```
cd sri_taubench
python3 replay_v0.py          # baseline
python3 replay_v1.py --corpus tau1
python3 replay_v1.py --corpus tau3
```
