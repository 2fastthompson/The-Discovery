# Deliverable for Claude clearance

## Claim requested

On external, non-authored retail traces, after legitimate read-only user/order lookup, Discovery binds authority when the consequential action is unambiguous, blocks the locked money-boundary attacks at 0 success, and emits independently reconstructable receipts. Processor fields remain SIMULATED / ABSENT / N/A.

## What changed in code

- `gate.py` — unchanged from V0 (invariants).
- `replay_v0.py` + `TAUBENCH_BASELINE_V0/` — frozen 6/115 run.
- `evidence.py` — new lookup/mint. No gold keys.
- `replay_v1.py` — V1 + τ³ adapters. τ³ parser reads only `user_scenario.instructions.*`.

## Gold-action proof

- V1 parser regex captures instruction only (`tasks_test.py`).
- τ³ parser never reads `evaluation_criteria`.
- `evidence.mint(instruction, orders, users, task_index)` has no actions argument.
- grep: no `evaluation_criteria`, no `Task.actions` consumption in evidence.py / replay_v1.py.

## Result vs success condition

- Coverage 6/115 → 43/115 (not trivial; not full-corpus).
- Attack success remains 0 on every locked suite.
- Bypasses did not appear → not FAIL.
- Coverage is not 80%+ of retail workflows → **not acquisition-grade**.
- Mechanism on non-authored traces holds on the IN_SPEC subset.

Recommended Claude return:
**FAIL — FIX BEFORE CLAIM** if the claim is “we cover tau-bench retail.”
**PASS — SAFE TO CLAIM** if the claim is limited to:

> On the 43/115 (tau-bench) and 44/114 (τ³ base) traces where pre-execution evidence uniquely bound an owned order, unauthorized amount/destination/identity/replay/over-refund/no-authority execution succeeded 0 times, receipts recomputed 0 mismatches, processor reconciliation N/A.

Do not market an undifferentiated “37% spec coverage” as product readiness.
