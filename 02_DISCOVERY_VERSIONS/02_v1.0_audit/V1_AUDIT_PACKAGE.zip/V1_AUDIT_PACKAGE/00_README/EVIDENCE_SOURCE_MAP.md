# Evidence-source map — V1

## Admitted (pre-execution only)

| Source | Fields used | Tool analogue |
|---|---|---|
| Initial instruction text | consequential verb; `#W` order ids; email; `user_id` token if spoken; First+Last+ZIP phrasing | user utterance |
| users.json | email, name.first/last, address.zip, payment_methods, orders[] | find_user_id_by_email / find_user_id_by_name_zip / get_user_details |
| orders.json | order_id, user_id, status, items[].name, items[].price, payment_history.payment_method_id | get_order_details |
| wiki / policy destinations | original payment method ids + gift cards on the user | policy |

## Newly admitted vs V0

- user identity from instruction (`user_id (zip)`, `You are First Last in ZIP`, `Your name is … ZIP`, `You're First Last … ZIP`)
- that user's order inventory
- status filter vs declared action
- item-name substring filter when instruction names a product
- unambiguous bind only (exactly one remaining order)

## Never admitted

- Task.actions / evaluation_criteria.actions
- expected tool sequence / outputs / reward
- Task.user_id field on the Python object (V1 mint does not take it)
- post-execution DB state
- fabricated Stripe / processor ids

## MISSING_EVIDENCE after exhaustion

- no resolvable user and no owned named order
- no candidate with status that authorizes the action
- no payment identity on the order

## AMBIGUOUS_INTENT

- more than one owned order still matches action + item names

## OUT_OF_SPEC

- no consequential verb (return/exchange/cancel/refund/modify)
