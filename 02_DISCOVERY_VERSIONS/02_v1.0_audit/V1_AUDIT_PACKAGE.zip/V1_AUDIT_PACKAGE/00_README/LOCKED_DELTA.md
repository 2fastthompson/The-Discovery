# LOCKED DELTA — tau-bench execution (2026-09-04)

Applies to SRI Transaction Gate money boundary. Not APD. Not host-EDR.

## Proof boundary
- Corpus A: tau-bench retail `tasks_test.py` (115 tasks, non-authored).
- Processor fields: SIMULATED / ABSENT / N/A.
- Authority minted from instruction text + orders.json + users.json + wiki policy.
- Gold `Task.actions` / `outputs` are never read.

## Claim
On external, non-authored retail traces, Discovery binds authority to the exact consequential financial action, blocks tested unauthorized mutation, replay, redirect, over-refund and authority-less execution at the controlled boundary, and emits a receipt independently replayable without trusting the agent.

Does not prove Stripe settlement.

## Replay
```
cd sri_taubench
bash replay.sh
```
