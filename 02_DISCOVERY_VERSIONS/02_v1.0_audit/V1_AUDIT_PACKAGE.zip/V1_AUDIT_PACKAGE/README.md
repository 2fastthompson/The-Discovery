# V1_AUDIT_PACKAGE

Drop this folder at `SRI_DISCOVERY/external_replay_v2/V1_AUDIT_PACKAGE/`.

| Dir | Contents |
|---|---|
| `00_README` | evidence map, V0 vs V1, Claude clearance note, locked delta |
| `01_V0_BASELINE` | frozen 6/115 run — do not overwrite |
| `02_V1_TAU1` | 43/115 + 0-attack scoreboard, rows, receipts |
| `03_TAU3_BASE` | 44/114 τ³ retail base, separate corpus |
| `04_SOURCE` | gate.py (unchanged), evidence.py, replay_v0.py, replay_v1.py |
| `05_CLAIM_BOUNDARIES` | allowed / forbidden language |
| `MANIFEST.md` | sha256 of every file |

Reproduce from `04_SOURCE` with corpora `tau_retail/` and `tau3_retail/` adjacent to `sri_taubench`.

Claude decision target is in `00_README/CLAUDE_DELIVERABLE.md`.
