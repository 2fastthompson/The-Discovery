# V1.1.5 candidate

Fixes V1.1.4 F1–F4 in a bounded simulator.

- Exhaustive receipt↔signed-event field contract (RECEIPT_TO_EVENT).
- Ledger fail-closed on corrupt/empty/malformed existing state. First-time init is absence of the data file.
- Separate never-replaced .lock file. path+no-fcntl raises UnsupportedLedgerPlatform. Pathless uses threading.Lock.
- try_consume(predicate) is the acceptance linearization point: reload, uniqueness, revocation, expiry, resource state, then persist.
- Concurrency oracle requires two completed results, exactly one win, no worker exceptions.

authorization_valid is not execution evidence. Simulated acceptance only.
