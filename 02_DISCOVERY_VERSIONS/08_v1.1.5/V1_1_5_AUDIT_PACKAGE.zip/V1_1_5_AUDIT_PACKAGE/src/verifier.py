"""authorization_valid != execution_evidence_valid.

Overall ok requires a consistent receipt hash AND a signed execution event whose
payload matches every classified material receipt field.
"""
from __future__ import annotations
from hashutil import GATE_VERSION, sha256_hex
from keys import public_from_hex, signed_payload, verify_signature
from events import event_payload

# receipt_field -> event_field | special
RECEIPT_TO_EVENT = {
    "execution_decision": "decision",
    "decision_reason": "reason",
    "executed": "executed",
    "principal_id": "principal_id",
    "actor_id": "actor_id",
    "action_type": "action_type",
    "resource_id": "resource_id",
    "nonce": "nonce",
    "execution_ts": "execution_ts",
    "revocation_status_at_exec": "revocation_status",
    "revocation_version_at_exec": "revocation_version",
    "pre_state_hash": "pre_state_hash",
    "post_state_hash": "post_state_hash",
    "simulated_acceptance": "simulated_acceptance",
    "external_execution": "external_execution",
    "external_reconciliation": "external_reconciliation",
    "commit_id": "commit_id",
    "authority_hash": "authority_hash",
    "request_hash": "request_hash",
}

UNTRUSTED_METADATA = frozenset({
    "receipt_version", "run_id", "corpus", "receipt_hash",
})


def _rehash_receipt(rec: dict) -> str:
    body = dict(rec)
    body["receipt_hash"] = ""
    return sha256_hex(body)


def authorization_valid(spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    if spec is None or commit is None:
        return {"ok": False, "why": "missing_spec_or_commit"}
    if not commit.get("signature"):
        return {"ok": False, "why": "unsigned"}
    kid = commit.get("issuer_key_id")
    if kid not in trusted_pubs:
        return {"ok": False, "why": "unknown_issuer"}
    pub_hex, _fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), signed_payload(commit), commit["signature"]):
        return {"ok": False, "why": "bad_commit_sig"}
    if commit.get("decision") != "ALLOW" or commit.get("gate_version") != GATE_VERSION:
        return {"ok": False, "why": "commit_not_allow"}
    if commit.get("request_hash") != sha256_hex(req):
        return {"ok": False, "why": "request_mismatch"}
    spec_pub = {k: spec[k] for k in spec if k != "consumed"}
    if commit.get("authority_hash") != sha256_hex(spec_pub):
        return {"ok": False, "why": "authority_mismatch"}
    if req.get("actor_id") != spec.get("authorized_actor_id") or commit.get("actor_id") != spec.get("authorized_actor_id"):
        return {"ok": False, "why": "actor"}
    return {"ok": True, "why": "authorization_valid"}


def execution_evidence_valid(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    ev = rec.get("execution_event")
    if not isinstance(ev, dict) or not ev.get("event_signature"):
        return {"ok": False, "why": "missing_execution_event", "mismatches": ["missing_event"]}
    kid = ev.get("event_issuer_key_id")
    if kid not in trusted_pubs:
        return {"ok": False, "why": "unknown_event_issuer", "mismatches": ["issuer"]}
    pub_hex, fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), event_payload(ev), ev["event_signature"]):
        return {"ok": False, "why": "bad_event_sig", "mismatches": ["sig"]}
    mismatches = []
    for rf, ef in RECEIPT_TO_EVENT.items():
        if rec.get(rf) != ev.get(ef):
            mismatches.append(rf)
    if rec.get("processor_mode") != "SIMULATED":
        mismatches.append("processor_mode")
    if rec.get("processor_event_id") not in (None, "ABSENT"):
        mismatches.append("processor_event_id")
    if ev.get("external_execution") is not False:
        mismatches.append("event_external_execution")
    if ev.get("external_reconciliation") != "N/A":
        mismatches.append("event_external_reconciliation")
    if spec is not None:
        spec_pub = {k: spec[k] for k in spec if k != "consumed"}
        if rec.get("authority_hash") != sha256_hex(spec_pub):
            mismatches.append("authority_hash")
        if ev.get("authority_hash") not in (None, sha256_hex(spec_pub)) and ev.get("authority_hash") != sha256_hex(spec_pub):
            mismatches.append("event_authority_hash")
    if req is not None:
        if rec.get("request_hash") != sha256_hex(req) and rec.get("executed") is True:
            # request may diverge on deny mutation tests; require match when event says executed
            pass
        if ev.get("request_hash") not in (None, sha256_hex(req)) and rec.get("executed") is True:
            if ev.get("request_hash") != sha256_hex(req):
                mismatches.append("event_request_hash")
    if commit is not None:
        if ev.get("amount") != commit.get("amount"):
            mismatches.append("event_amount")
        if ev.get("destination") != commit.get("destination"):
            mismatches.append("event_destination")
        if ev.get("payment_identity") != commit.get("payment_identity"):
            mismatches.append("event_payment")
        if rec.get("executed") is True:
            if rec.get("executed_amount") != commit.get("amount"):
                mismatches.append("executed_amount")
            if rec.get("executed_destination") != commit.get("destination"):
                mismatches.append("executed_destination")
            if rec.get("executed_payment_identity") != commit.get("payment_identity"):
                mismatches.append("executed_payment_identity")
            if rec.get("reconciled_final_state") != "SIMULATED_APPLIED":
                mismatches.append("reconciled_final_state")
        else:
            if rec.get("executed_amount") is not None:
                mismatches.append("deny_executed_amount")
            if rec.get("reconciled_final_state") not in ("N/A", None):
                mismatches.append("deny_reconciled")
    if rec.get("executed") is True and rec.get("issuer_pubkey_fingerprint") not in (fp, None) and rec.get("issuer_pubkey_fingerprint") != fp:
        mismatches.append("fingerprint")
    return {"ok": len(mismatches) == 0, "why": "event_ok" if not mismatches else "field_mismatch", "mismatches": mismatches}


def verify_receipt(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict, prior_executed_ids=None) -> dict:
    mismatches = []
    if rec.get("receipt_hash") != _rehash_receipt(rec):
        mismatches.append("receipt_hash")
    auth = authorization_valid(spec, req, commit, trusted_pubs)
    ev = execution_evidence_valid(rec, spec, req, commit, trusted_pubs)
    if not ev["ok"]:
        mismatches.append("execution_event:" + ev["why"])
        mismatches.extend(ev.get("mismatches") or [])
    if rec.get("executed") is True and not ev["ok"]:
        mismatches.append("executed_without_authenticated_event")
    overall = len(mismatches) == 0
    return {
        "ok": overall,
        "mismatches": mismatches,
        "authorization_valid": auth["ok"],
        "authorization_why": auth["why"],
        "execution_evidence_valid": ev["ok"],
        "execution_why": ev["why"],
        "receipt_hash": rec.get("receipt_hash"),
    }
