from __future__ import annotations
import threading


class RevocationRegistry:
    def __init__(self) -> None:
        self._status: dict[str, str] = {}
        self._version: dict[str, int] = {}
        self.lock = threading.Lock()

    def register(self, authority_id: str, version: int = 1) -> None:
        with self.lock:
            self._status[authority_id] = "ACTIVE"
            self._version[authority_id] = version

    def revoke(self, authority_id: str) -> None:
        with self.lock:
            if authority_id in self._status:
                self._status[authority_id] = "REVOKED"
                self._version[authority_id] = self._version.get(authority_id, 1) + 1

    def bump_version(self, authority_id: str) -> None:
        with self.lock:
            if authority_id in self._version:
                self._version[authority_id] += 1

    def lookup(self, authority_id: str) -> tuple[str | None, int | None]:
        with self.lock:
            if authority_id not in self._status:
                return None, None
            return self._status[authority_id], self._version.get(authority_id)
