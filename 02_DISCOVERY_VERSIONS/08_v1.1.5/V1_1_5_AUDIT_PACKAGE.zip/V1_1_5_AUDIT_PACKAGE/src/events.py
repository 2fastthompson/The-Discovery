"""Signed execution events. Distinct from ValidatedCommit (authorization)."""
from __future__ import annotations
from hashutil import canonical_json, sha256_hex

EVENT_FIELDS = (
    "commit_id",
    "decision",
    "reason",
    "executed",
    "principal_id",
    "actor_id",
    "action_type",
    "resource_id",
    "amount",
    "destination",
    "payment_identity",
    "nonce",
    "execution_ts",
    "revocation_status",
    "revocation_version",
    "pre_state_hash",
    "post_state_hash",
    "authority_hash",
    "request_hash",
    "simulated_acceptance",
    "external_execution",
    "external_reconciliation",
)


def event_payload(d: dict) -> bytes:
    body = {k: d.get(k) for k in EVENT_FIELDS}
    return canonical_json(body).encode("utf-8")


def sign_event(issuer, d: dict) -> dict:
    out = dict(d)
    out["event_issuer_key_id"] = issuer.key_id
    out["event_signature"] = issuer.sign(event_payload(out))
    out["event_hash"] = sha256_hex(event_payload(out).decode("utf-8"))
    return out
