# V1.1.4 scoreboard
simulated_acceptance only; external_execution=false; external_reconciliation=N/A

## tau1
- spec 42/115
- valid 42/42
- unauthorized 0/1512
- verifier 0/1638

## tau3
- spec 43/114
- valid 43/43
- unauthorized 0/1548
- verifier 0/1677
