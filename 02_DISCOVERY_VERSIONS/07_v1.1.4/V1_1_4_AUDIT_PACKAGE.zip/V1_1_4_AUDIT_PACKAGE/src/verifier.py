"""Independent verifier.

authorization_valid: commit signature + spec/req binding. Not execution evidence.
execution_evidence_valid: trusted signed execution event matches receipt outcome.
"""
from __future__ import annotations
from hashutil import GATE_VERSION, sha256_hex
from keys import public_from_hex, signed_payload, verify_signature
from events import event_payload


MATERIAL = (
    "principal_id", "actor_id", "action_type", "resource_id", "nonce",
    "executed_amount", "executed_destination", "executed_payment_identity",
    "execution_decision", "executed", "processor_mode", "processor_event_id",
    "external_execution", "external_reconciliation", "simulated_acceptance",
    "commit_id",
)


def _rehash_receipt(rec: dict) -> str:
    body = dict(rec)
    body["receipt_hash"] = ""
    return sha256_hex(body)


def authorization_valid(spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    if spec is None or commit is None:
        return {"ok": False, "why": "missing_spec_or_commit"}
    if not commit.get("signature"):
        return {"ok": False, "why": "unsigned"}
    kid = commit.get("issuer_key_id")
    if kid not in trusted_pubs:
        return {"ok": False, "why": "unknown_issuer"}
    pub_hex, _fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), signed_payload(commit), commit["signature"]):
        return {"ok": False, "why": "bad_commit_sig"}
    if commit.get("decision") != "ALLOW" or commit.get("gate_version") != GATE_VERSION:
        return {"ok": False, "why": "commit_not_allow"}
    if commit.get("request_hash") != sha256_hex(req):
        return {"ok": False, "why": "request_mismatch"}
    spec_pub = {k: spec[k] for k in spec if k != "consumed"}
    if commit.get("authority_hash") != sha256_hex(spec_pub):
        return {"ok": False, "why": "authority_mismatch"}
    if req.get("actor_id") != spec.get("authorized_actor_id") or commit.get("actor_id") != spec.get("authorized_actor_id"):
        return {"ok": False, "why": "actor"}
    return {"ok": True, "why": "authorization_valid"}


def execution_evidence_valid(rec: dict, commit: dict | None, trusted_pubs: dict) -> dict:
    ev = rec.get("execution_event")
    if not isinstance(ev, dict) or not ev.get("event_signature"):
        return {"ok": False, "why": "missing_execution_event"}
    kid = ev.get("event_issuer_key_id")
    if kid not in trusted_pubs:
        return {"ok": False, "why": "unknown_event_issuer"}
    pub_hex, fp = trusted_pubs[kid]
    if not verify_signature(public_from_hex(pub_hex), event_payload(ev), ev["event_signature"]):
        return {"ok": False, "why": "bad_event_sig"}
    mismatches = []
    if ev.get("executed") is not rec.get("executed"):
        mismatches.append("executed")
    if ev.get("decision") != rec.get("execution_decision"):
        mismatches.append("decision")
    if ev.get("reason") != rec.get("decision_reason"):
        mismatches.append("reason")
    if ev.get("simulated_acceptance") is not rec.get("simulated_acceptance"):
        mismatches.append("simulated_acceptance")
    if ev.get("external_execution") is not False or rec.get("external_execution") is not False:
        mismatches.append("external_execution")
    if ev.get("external_reconciliation") != "N/A" or rec.get("external_reconciliation") != "N/A":
        mismatches.append("external_reconciliation")
    if rec.get("processor_mode") != "SIMULATED":
        mismatches.append("processor_mode")
    if rec.get("processor_event_id") not in (None, "ABSENT"):
        mismatches.append("processor_event")
    if commit is not None:
        if ev.get("commit_id") != commit.get("commit_id"):
            mismatches.append("commit_id")
        if ev.get("amount") != commit.get("amount"):
            mismatches.append("amount")
        if ev.get("destination") != commit.get("destination"):
            mismatches.append("destination")
        if ev.get("payment_identity") != commit.get("payment_identity"):
            mismatches.append("payment_identity")
        if ev.get("actor_id") != commit.get("actor_id"):
            mismatches.append("actor")
        if ev.get("principal_id") != commit.get("principal_id"):
            mismatches.append("principal")
        if ev.get("resource_id") != commit.get("resource_id"):
            mismatches.append("resource")
        if ev.get("nonce") != commit.get("nonce"):
            mismatches.append("nonce")
        if rec.get("executed") is True:
            if rec.get("executed_amount") != commit.get("amount"):
                mismatches.append("receipt_amount")
            if rec.get("executed_destination") != commit.get("destination"):
                mismatches.append("receipt_destination")
            if rec.get("executed_payment_identity") != commit.get("payment_identity"):
                mismatches.append("receipt_payment")
            if rec.get("commit_id") != commit.get("commit_id"):
                mismatches.append("receipt_commit_id")
        else:
            if rec.get("executed_amount") is not None:
                mismatches.append("deny_has_executed_amount")
    if rec.get("actor_id") not in (ev.get("actor_id"), None) and rec.get("actor_id") != ev.get("actor_id"):
        mismatches.append("receipt_actor")
    if rec.get("principal_id") not in (ev.get("principal_id"), None) and rec.get("principal_id") != ev.get("principal_id"):
        mismatches.append("receipt_principal")
    expected_recon = "SIMULATED_APPLIED" if rec.get("executed") else "N/A"
    if rec.get("reconciled_final_state") not in (expected_recon, "N/A") and rec.get("executed") is True:
        mismatches.append("reconciled_final_state")
    if rec.get("executed") is False and rec.get("reconciled_final_state") not in ("N/A", None):
        mismatches.append("deny_reconciled")
    if rec.get("actor_id") != ev.get("actor_id"):
        mismatches.append("actor_field")
    if rec.get("reconciled_final_state") == "MUTATED":
        mismatches.append("reconciled_mutated")
    if rec.get("issuer_pubkey_fingerprint") not in (fp, None) and rec.get("executed") is True:
        if rec.get("issuer_pubkey_fingerprint") != fp:
            mismatches.append("fingerprint")
    return {"ok": len(mismatches) == 0, "why": "event_ok" if not mismatches else "event_field", "mismatches": mismatches}


def verify_receipt(rec: dict, spec: dict | None, req: dict, commit: dict | None, trusted_pubs: dict, prior_executed_ids=None) -> dict:
    mismatches = []
    if rec.get("receipt_hash") != _rehash_receipt(rec):
        mismatches.append("receipt_hash")
    auth = authorization_valid(spec, req, commit, trusted_pubs)
    ev = execution_evidence_valid(rec, commit, trusted_pubs)
    if not ev["ok"]:
        mismatches.extend(["execution_event:" + ev["why"]] + (ev.get("mismatches") or []))
    # Never treat authorization_valid as execution.
    if rec.get("executed") is True and not ev["ok"]:
        mismatches.append("executed_without_authenticated_event")
    if rec.get("executed") is True and ev["ok"] and rec.get("execution_event", {}).get("executed") is not True:
        mismatches.append("executed_vs_event")
    return {
        "ok": len(mismatches) == 0,
        "mismatches": mismatches,
        "authorization_valid": auth["ok"],
        "authorization_why": auth["why"],
        "execution_evidence_valid": ev["ok"],
        "execution_why": ev["why"],
        "receipt_hash": rec.get("receipt_hash"),
    }
