"""Shared execution ledger. try_consume is uniqueness + linearization point.

TEST-ONLY JSON+flock fixture. Storage failure raises; do not report acceptance.
"""
from __future__ import annotations
import json
from pathlib import Path

try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None


class LedgerStorageError(Exception):
    pass


class ExecutionLedger:
    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path else None
        self._consumed: set[str] = set()
        if self.path and self.path.exists():
            self._reload_unlocked()

    def _reload_unlocked(self) -> None:
        if not self.path or not self.path.exists():
            return
        try:
            raw = self.path.read_text().strip()
            data = json.loads(raw) if raw else {"consumed_commit_ids": []}
        except OSError as e:
            raise LedgerStorageError(str(e)) from e
        except json.JSONDecodeError:
            data = {"consumed_commit_ids": []}
        self._consumed = set(data.get("consumed_commit_ids") or [])

    def _persist_unlocked(self) -> None:
        if not self.path:
            return
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(self.path.suffix + ".tmp")
            tmp.write_text(json.dumps({"consumed_commit_ids": sorted(self._consumed)}, indent=2))
            tmp.replace(self.path)
        except OSError as e:
            raise LedgerStorageError(str(e)) from e

    def _locked(self, fn):
        if not self.path or fcntl is None:
            return fn()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)
        with self.path.open("r+") as fh:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
            try:
                return fn()
            finally:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    def contains(self, commit_id: str | None) -> bool:
        if not commit_id:
            return False
        if self.path:
            self._locked(self._reload_unlocked)
        return commit_id in self._consumed

    def try_consume(self, commit_id: str) -> bool:
        def _op():
            if self.path:
                self._reload_unlocked()
            if commit_id in self._consumed:
                return False
            self._consumed.add(commit_id)
            self._persist_unlocked()
            return True

        if self.path and fcntl is not None:
            return self._locked(_op)
        return _op()

    def snapshot(self) -> list[str]:
        if self.path:
            self._locked(self._reload_unlocked)
        return sorted(self._consumed)
