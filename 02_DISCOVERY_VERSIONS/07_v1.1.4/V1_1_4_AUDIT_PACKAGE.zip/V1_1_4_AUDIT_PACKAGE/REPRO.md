cd V1_1_4_AUDIT_PACKAGE
python3 tests/test_attacks.py
python3 harness/run_replay.py --corpus both
CPython 3.12 + cryptography
