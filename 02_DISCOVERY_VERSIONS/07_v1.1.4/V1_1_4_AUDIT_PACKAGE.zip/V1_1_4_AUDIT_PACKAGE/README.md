# V1.1.4 candidate — atomic consume + signed execution events

Addresses V1.1.3 pressure-test F1–F4 in a bounded simulator.

1. ExecutionLedger.try_consume is the uniqueness and linearization point (reload + flock + persist before return).
2. authorization_valid is not execution evidence. Executor signs an execution event for allow and deny.
3. Verifier binds material receipt fields to the signed event and commit.
4. Authentic denials carry a signed executed=false event.
5. Revocation is re-read immediately before try_consume. After a winning consume, later revocation does not unwind acceptance.

simulated_acceptance only. external_execution=false. external_reconciliation=N/A.

Lineage: copied V1.1.3; frozen V1–V1.1.3 unchanged.
